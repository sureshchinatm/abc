package com.daas.core.dao.govern;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GET_GOVERN_SOURCE_DETAILS_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GET_GOVERN_STATUS_SQL;
import static com.daas.core.util.DaasConstants.GOVERN_APPROVED_STATUS;
import static com.daas.core.util.DaasConstants.GOVERN_REJECTED_STATUS;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.govern.Govern;
import com.daas.core.model.govern.GovernSourceDetails;
import com.daas.core.util.ErrorMessageConstants;


/**
 * This class provides the implementation methods for DataAcquisitionGovernDao.
 * 
 * @author snatti
 */

@Repository
public class DataAcquisitionGovernDaoImpl implements DataAcquisitionGovernDao{
	
	private Logger logger = LoggerFactory.getLogger(DataAcquisitionGovernDaoImpl.class);

		@Autowired
		JdbcTemplate jdbcTemplate;
		@Autowired
		NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	 /**
     * This method used to fetch govern source details for approval from data_acquisition_master_test ,project_master , project_system_details, govern table.
     */
	@Override
	public List<GovernSourceDetails> fetchGovernSourceInformation() {
		logger.info("Enter DataAcquisitionGovernDaoImpl fetchGovernSourceInformation");
		List<GovernSourceDetails> governSourceInfo = null;
		List<String> errorList;
		try {
			
			//SqlParameterSource namedParameters =new MapSqlParameterSource("guid", guId);
			governSourceInfo = this.namedParameterJdbcTemplate.query(GET_GOVERN_SOURCE_DETAILS_SQL,
					new BeanPropertyRowMapper<GovernSourceDetails>(GovernSourceDetails.class));

			if (governSourceInfo == null) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.NO_GOVERN_DETAILS_WITH_APPROVAL);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
			}
		} catch (DataAccessException e) {
			logger.error(
					"Error in fetching System Information , rolling back::::::: method fetchGovernSourceInformation() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCHING_FAILED_FOR_GOVERN);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList, null,null);
		}

		logger.info("Exit DataAcquisitionGovernDaoImpl fetchGovernSourceInformation");
		return governSourceInfo;
	}
	
	 /**
     * This method used to update Approve/Reject status in govern table.
     */
	@Override
	public List<Govern> update(List<Govern> governInfo) {
		logger.info("Enter DataAcquisitionGovernDaoImpl update");
		List<Govern> governStatusList = null;
		List<String> errorList;
		try {
			int[] count = bulkGovernStatusUpdate(governInfo);
			governStatusList = fetchGovernStatus(governInfo);
			
			
		} catch (DataAccessException e) {
			logger.error("Error in creating record, rolling back \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.CREATE_FAILED_FOR_GOVERN);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Enter DataAcquisitionGovernDaoImpl update");
		return governStatusList;
	}
	
	public int[] bulkGovernStatusUpdate(List<Govern> governInfo) {
		logger.info("Enter DataAcquisitionGovernDaoImpl bulkGovernStatusUpdate");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String stamp_updated = timestamp.toString();
		
		/*final String updateStatusSql = "update govern set status=:status,approved_by=:approved_by,stamp_updated='"+stamp_updated+"'"
				+ "where project_id=:project_id and approver_type =:approver_type";*/
		
		final String updateStatusSql = "update govern set status=:status,approved_by=:approved_by,comments=:comments,stamp_updated='"+stamp_updated+"'"
				+ "where project_id=:project_id and app_inst_id=:app_inst_id and approver_type =:approver_type";
				
		
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(governInfo.toArray());
		
		int[] updateCounts = this.namedParameterJdbcTemplate.batchUpdate(updateStatusSql, batch);
		
		logger.info("Exit DataAcquisitionGovernDaoImpl bulkGovernStatusUpdate");
		return updateCounts;
	}
	
	
	public List<Govern> fetchGovernStatus(List<Govern> governInputInfo) {
		logger.info("Enter DataAcquisitionGovernDaoImpl fetchGovernStatus");
		List<Govern> governStatusList = new ArrayList<>();
		Govern governStatusInfo = null;
		List<String> errorList;
		try {

			for(int i=0;i<governInputInfo.size();i++){
				governStatusInfo = new Govern();
				
				Govern governInput = (Govern)governInputInfo.get(i);
			
				Object[] inputs = new Object[] {governInput.getProject_id(),governInput.getApp_inst_id()};

				Integer count = this.jdbcTemplate.queryForObject(GET_GOVERN_STATUS_SQL,inputs,Integer.class);
				logger.info("count:::::::::::" + count);
				if(count == 3){
					governStatusInfo.setStatus(GOVERN_APPROVED_STATUS);
					governStatusInfo.setProject_id(governInput.getProject_id());
				}else{
					governStatusInfo.setStatus(GOVERN_REJECTED_STATUS);
					governStatusInfo.setProject_id(governInput.getProject_id());
				}
				governStatusList.add(governStatusInfo);
			}

			if (governStatusList!=null && governStatusList.size()==0) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.GOVERN_STATUS_LIST_SIZE_ZERO);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(),errorList, null,null);
			}
		} catch (DataAccessException e) {
			logger.error(
					"Error in fetching System Information , rolling back::::::: method fetchGovernSourceInformation() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCHING_FAILED_FOR_GOVERN);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}

		logger.info("Exit DataAcquisitionGovernDaoImpl fetchGovernStatus");
		return governStatusList;
	}
}
