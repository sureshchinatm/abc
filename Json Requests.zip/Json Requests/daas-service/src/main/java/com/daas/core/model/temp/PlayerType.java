package com.daas.core.model.temp;

import java.io.Serializable;

public class PlayerType implements Serializable{
	
	private static final long serialVersionUID = -8788619177798333712L;

	 
    protected int playerId;
    protected String name;
    protected int age;
    protected int matches;
 
    public int getPlayerId() {
        return playerId;
    }
    public void setPlayerId(int value) {
        this.playerId = value;
    }
    public String getName() {
        return name;
    }
    public void setName(String value) {
        this.name = value;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int value) {
        this.age = value;
    }
    public int getMatches() {
        return matches;
    }
    public void setMatches(int value) {
        this.matches = value;
    }
}