package com.daas.core.dao.login;



import com.daas.core.model.login.User;

/**
 * This interface contains the abstract methods to get the Data Acquisition User Information from
 * the database.
 * 
 * @author snatti
 */

public interface DataAcquisitionLoginDao {

	/**
     * Returns the User information corresponding to the
     * user.
     * 
     * @param User object.
     *          
     * @return User Information.
     */
	public User findUserDetails(User user);
	
}
