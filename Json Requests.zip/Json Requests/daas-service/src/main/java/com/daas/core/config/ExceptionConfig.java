package com.daas.core.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.daas.core.exception.DaasExceptionMapper;
import com.daas.core.exception.GlobalExceptionMapper;
import com.daas.core.exception.JsonMappingExceptionMapper;

/**
 * This class contains java configuration required for handling exceptions in
 * DaasService
 * 
 * @author snatti
 */
@Configuration
public class ExceptionConfig {
    
  
    /**
     * Creates new GlobalExceptionMapper object
     * 
     * @return {@link GlobalExceptionMapper}
     */
    @Bean
    public GlobalExceptionMapper globalExceptionMapper() {
        return new GlobalExceptionMapper();
    }
    
    /**
     * Creates new DaasExceptionMapper object
     * 
     * @return {@link DaasExceptionMapper}
     */
    @Bean
    public DaasExceptionMapper daasExcepMapper() {
        return new DaasExceptionMapper();
    }
    
    /**
     * Creates new JsonMappingExceptionMapper object
     * 
     * @return {@link JsonMappingExceptionMapper}
     */
    @Bean
    public JsonMappingExceptionMapper jsonMappingExceMapper() {
        return new JsonMappingExceptionMapper();
    }
}
