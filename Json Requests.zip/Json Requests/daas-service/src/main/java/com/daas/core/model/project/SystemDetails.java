package com.daas.core.model.project;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SystemDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2832110900697222203L;
	
	private Integer app_inst_id;
	private Integer project_system_id;
	private String app_inst_name;
	private String application_name;
	private Integer dataAcquisitionBatchRequestId;
	
	
	private String justify;
	private Integer data_retention;
	private String frequency;
	private String ingestion_type;
	private String system_name;
	
	public Integer getApp_inst_id() {
		return app_inst_id;
	}
	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}
	public String getApp_inst_name() {
		return app_inst_name;
	}
	public void setApp_inst_name(String app_inst_name) {
		this.app_inst_name = app_inst_name;
	}
	public String getApplication_name() {
		return application_name;
	}
	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	public Integer getDataAcquisitionBatchRequestId() {
		return dataAcquisitionBatchRequestId;
	}
	public void setDataAcquisitionBatchRequestId(Integer dataAcquisitionBatchRequestId) {
		this.dataAcquisitionBatchRequestId = dataAcquisitionBatchRequestId;
	}
	public String getJustify() {
		return justify;
	}
	public void setJustify(String justify) {
		this.justify = justify;
	}
	public Integer getData_retention() {
		return data_retention;
	}
	public void setData_retention(Integer data_retention) {
		this.data_retention = data_retention;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getIngestion_type() {
		return ingestion_type;
	}
	public void setIngestion_type(String ingestion_type) {
		this.ingestion_type = ingestion_type;
	}
	public String getSystem_name() {
		return system_name;
	}
	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}
	public Integer getProject_system_id() {
		return project_system_id;
	}
	public void setProject_system_id(Integer project_system_id) {
		this.project_system_id = project_system_id;
	}
}
