package com.daas.core.model.define;

import java.io.Serializable;

public class AbResponseData implements Serializable
{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 3145188152745755776L;
	
	private Integer request_id;
    private Integer guid;
	public Integer getRequest_id() {
		return request_id;
	}
	public void setRequest_id(Integer request_id) {
		this.request_id = request_id;
	}
	public Integer getGuid() {
		return guid;
	}
	public void setGuid(Integer guid) {
		this.guid = guid;
	}
    
    
    
}
	