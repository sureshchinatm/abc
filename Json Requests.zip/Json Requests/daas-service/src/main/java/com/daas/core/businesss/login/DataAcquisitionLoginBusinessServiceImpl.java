package com.daas.core.businesss.login;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.login.DataAcquisitionLoginDao;
import com.daas.core.model.login.User;

/**
 * This class provides implementation for DataAcquisitionLoginBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */
@Service
public class DataAcquisitionLoginBusinessServiceImpl implements DataAcquisitionLoginBusinessService{

	 /**
     * Logger object to log all the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionLoginBusinessServiceImpl.class);
    
    /**
     * Autowired DataAcquisitionLoginDao to perform CRUD operations.
     */
    @Autowired
    private DataAcquisitionLoginDao dataAcquisitionLoginDao;
	
    
    /**
     * Returns the User information from the database based on the UserId.
     * 
     * @param User
     *           
     * @return User Details.
     */
	@Override
	@Transactional(readOnly = true)
	public User findUserDetails(User user) {
		logger.info("Enter DataAcquisitionPlanBusinessServiceImpl getSystemInformation");
		User userInfo = this.dataAcquisitionLoginDao.findUserDetails(user);
		logger.info("Exit DataAcquisitionPlanBusinessServiceImpl getSystemInformation");
		return userInfo;
	}

}
