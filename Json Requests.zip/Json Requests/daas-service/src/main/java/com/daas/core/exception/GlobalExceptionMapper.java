package com.daas.core.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daas.core.exception.dto.ErrorDTO;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.util.LoggerConstants;


/**
 * This class will be used to catch all Runtime exceptions and log the Error
 * messages using the Error DTO object
 * 
 * @author snatti
 */
@Provider
public class GlobalExceptionMapper implements ExceptionMapper<RuntimeException> {
    
	private Logger logger=LoggerFactory.getLogger(GlobalExceptionMapper.class);
                    
    /**
     * This method is used to handle ConstraintViolationException and it forms
     * an Error DTO depending on the Exception message passed.
     * 
     * @return {@code Response} Returns the Response which the Exception Error
     *         Message DTO
     * @see javax.ws.rs.ext.ExceptionMapper#toResponse(java.lang.Throwable)
     */
    
    @Override
    public Response toResponse(RuntimeException runte) {
        
        logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, runte);
        StringWriter errors = new StringWriter();
        runte.printStackTrace(new PrintWriter(errors));
        ErrorDTO errorMessage = new ErrorDTO(ErrorConstants.SYS_RUNTIME_ERROR.getCode().toString());
        errorMessage.getErrorCodeList().add(runte.getMessage());
        Throwable exceptionCauseMessage = runte.getCause();
        if (exceptionCauseMessage != null && exceptionCauseMessage.getMessage() != null) {
            errorMessage.getErrorCodeList().add(errors.toString());
        }
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(errorMessage).type(MediaType.APPLICATION_JSON).build();
    }
}
