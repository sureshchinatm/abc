package com.daas.core.util;

public enum SourceTypeEnum {

	Oracle(7), // calls constructor with value 7
	DB2(8), // calls constructor with value 8
	FlatFile(9), // calls constructor with value 9
	Kafka(10)// calls constructor with value 10
	; // semicolon needed when fields / methods follow

	private int sourceTypeCode;

	private SourceTypeEnum(int sourceTypeCode) {
		this.sourceTypeCode = sourceTypeCode;
	}

	public int getSourceTypeCode() {
		return sourceTypeCode;
	}

	public static String getStringValueFromInt(int i) {
		for (SourceTypeEnum sourceType : SourceTypeEnum.values()) {
			if (sourceType.getSourceTypeCode() == i) {
				return sourceType.toString();
			}
		}
		throw new IllegalArgumentException("the given number doesn't match any Source.");
	}
}
