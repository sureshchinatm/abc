package com.daas.core.exception.dto;

import java.util.ArrayList;
import java.util.List;

import com.daas.core.exception.util.BusinessContext;

/**
 * This class represents the overall summary of the
 * exception.
 * 
 * @author snatti
 *         
 */
public class ErrorDTO {
    
    @Override
	public String toString() {
		return "ErrorDTO [errorCode=" + errorCode + ", errorDescription=" + errorDescription + ", errorCodeList="
				+ errorCodeList + ", errorTimestamp=" + errorTimestamp + ", loggedInUser=" + loggedInUser + "]";
	}

	private String errorCode;
    private String errorDescription;
    private BusinessContext businessContext;
    private List<String> errorCodeList = new ArrayList<>();
    private String errorTimestamp;
    private String loggedInUser;
    
    /**
     * Constructs new errorDTO with the given errorCode.
     * 
     * @param errorCode
     *            The error code value
     */
    public ErrorDTO(String errorCode) {
        this.errorCode = errorCode;
    }
    
    public ErrorDTO() {
        super();
    }
    
    /**
     * Constructs new ErrorDTO with errorCode,
     * businessContext,errorCodeList,errorTimestamp,loggedInUser.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception.
     * @param businessContext
     *            - context that contains parameters.
     * @param errorCodeList
     *            - list of errors.
     * @param errorTimestamp
     *            -Time stamp at the time of error occurance.
     * @param loggedInUser
     *            -user loggedin.
     */
/*    public ErrorDTO(String errorCode, BusinessContext businessContext, List<String> errorCodeList,
                    String errorTimestamp, String loggedInUser) {
        this.errorCode = errorCode;
        this.businessContext = businessContext;
        this.errorCodeList = errorCodeList;
        this.errorTimestamp = errorTimestamp;
        this.loggedInUser = loggedInUser;
    }*/
    
    /**
     * Constructs new ErrorDTO with
     * errorCode,errorCodeList,errorTimestamp,loggedInUser.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception.
     * @param errorCodeList
     *            - list of errors.
     * @param errorTimestamp
     *            -Time stamp at the time of error occurance.
     * @param loggedInUser
     *            -user loggedin.
     */
    public ErrorDTO(String errorCode, List<String> errorCodeList, String errorTimestamp,
                    String loggedInUser) {
    	System.out.println("Error DTO:::::::"+loggedInUser+","+errorCodeList.toString());
        this.errorCode = errorCode;
        this.errorCodeList = errorCodeList;
        this.errorTimestamp = errorTimestamp;
        this.loggedInUser = loggedInUser;
    }
    
    /**
     * Constructs new ErrorDTO with errorCode,
     * businessContext,errorDesc,errorTimestamp,loggedInUser.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception.
     * @param errorDesc
     *              -description corresponding to the error code.
     * @param businessContext
     *            - context that contains parameters.
     * @param errorTimestamp
     *            -Time stamp at the time of error occurrence.
     */
   /* public ErrorDTO(String errorCode, String errorTimestamp) {
        this.errorCode = errorCode;
        this.errorTimestamp = errorTimestamp;
    }*/
    
    public ErrorDTO(String errorCode, BusinessContext businessContext, String errorTimestamp) {
        this.errorCode = errorCode;
        this.businessContext = businessContext;
        this.errorTimestamp = errorTimestamp;
    }
    
    public String getErrorCode() {
        return this.errorCode;
    }
    
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    
   /* public BusinessContext getBusinessContext() {
        return this.businessContext;
    }
    
    public void setBusinessContext(BusinessContext businessContext) {
        this.businessContext = businessContext;
    }*/
    
    public List<String> getErrorCodeList() {
        return this.errorCodeList;
    }
    
    public void setErrorCodeList(List<String> errorCodeList) {
        this.errorCodeList = errorCodeList;
    }
    
    public String getErrorTimestamp() {
        return this.errorTimestamp;
    }
    
    public void setErrorTimestamp(String errorTimestamp) {
        this.errorTimestamp = errorTimestamp;
    }
    
    public String getLoggedInUser() {
        return this.loggedInUser;
    }
    
    public void setLoggedInUser(String loggedInUser) {
        this.loggedInUser = loggedInUser;
    }
    
    /**
     * @return the errorDescription
     */
    public String getErrorDescription() {
        return errorDescription;
    }

    /**
     * @param errorDescription the errorDescription to set
     */
    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
}
