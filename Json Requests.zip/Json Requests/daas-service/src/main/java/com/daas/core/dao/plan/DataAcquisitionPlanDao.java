package com.daas.core.dao.plan;

import java.util.List;

import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;

/**
 * This interface contains the abstract methods to get the Data Acquisition Plan Relationship
 * related information to the database and retrieve the information from the
 * database.
 * 
 * @author snatti
 */
public interface DataAcquisitionPlanDao {
	

    /**
     * Returns the System information corresponding to the
     * dataAcquisitionBatchRequestId.
     * 
     * @param dataAcquisitionBatchRequestId
     *          
     * @return System information  corresponding to dataAcquisitionBatchRequestId.
     */
	public List<SystemDetails>  fetchSystemInformation(Integer dataAcquisitionBatchRequestId);
	
	 /**
     * Saves the Project and System information to the database 
     * 
     * @param projectMasterInfo
     *            Project and System Info to be saved to the DB
     */
	public ProjectMaster save(ProjectMaster projectMasterInfo);

}
