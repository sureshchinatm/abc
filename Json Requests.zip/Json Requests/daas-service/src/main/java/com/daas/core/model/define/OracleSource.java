package com.daas.core.model.define;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OracleSource implements Serializable{
	
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 5811584419164768340L;
	
		private String driver;
		private String databaseServer;
		private String databasePort;
		private String databaseUserName;
		private String databasePassword;
		private String databaseName;
		
		public String getDriver() {
			return driver;
		}
		public void setDriver(String driver) {
			this.driver = driver;
		}
		public String getDatabaseServer() {
			return databaseServer;
		}
		public void setDatabaseServer(String databaseServer) {
			this.databaseServer = databaseServer;
		}
		public String getDatabasePort() {
			return databasePort;
		}
		public void setDatabasePort(String databasePort) {
			this.databasePort = databasePort;
		}
		public String getDatabaseUserName() {
			return databaseUserName;
		}
		public void setDatabaseUserName(String databaseUserName) {
			this.databaseUserName = databaseUserName;
		}
		public String getDatabasePassword() {
			return databasePassword;
		}
		public void setDatabasePassword(String databasePassword) {
			this.databasePassword = databasePassword;
		}
		public String getDatabaseName() {
			return databaseName;
		}
		public void setDatabaseName(String databaseName) {
			this.databaseName = databaseName;
		}
		
		

}
