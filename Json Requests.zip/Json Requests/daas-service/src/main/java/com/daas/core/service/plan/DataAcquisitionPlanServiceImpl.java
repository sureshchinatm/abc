package com.daas.core.service.plan;

import java.util.List;

import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daas.core.businesss.plan.DataAcquisitionPlanBusinessService;
import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;

/**
 * This class provides the implementation for DataAcquisitionPlanService methods to invoke
 * the corresponding business methods of DataAcquisitionPlanBusinessService interface.
 * 
 * @author snatti
 */

@Path("/plan/")
@Service
public class DataAcquisitionPlanServiceImpl implements DataAcquisitionPlanService{
	
	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionPlanServiceImpl.class);
	

    /**
     * Autowired businessService implementation class to perform business
     * validations and to access DAO layer.
     */
	@Autowired
	DataAcquisitionPlanBusinessService dataAcquisitionPlanBusinessService;
	
	/**
	 *  Method to be fetch submitted System Information of the Acquisition Request
	 * @param dataAcquisitionBatchRequestId
	 * 
	 * @return List of  SystemDetails with all the systems information.
	 */
	@Override
	public List<SystemDetails> getSystemInformation(Integer dataAcquisitionBatchRequestId) {
		logger.info("Enter DataAcquisitionPlanServiceImpl getSystemInformation");
		List<SystemDetails> systemDetails = this.dataAcquisitionPlanBusinessService.getSystemInformation(dataAcquisitionBatchRequestId);
		logger.info("Exit DataAcquisitionPlanServiceImpl getSystemInformation");

		return systemDetails;
	}

	 /**
     * Method to  save/submit the project information of a user.
     * 
     * @param projectMasterInfo
     *            ProjectMaster to save the information to DB.
     */ 
	@Override
	public ProjectMaster saveProjectInformation(ProjectMaster projectMasterInfo) {
		logger.info("Enter DataAcquisitionPlanServiceImpl saveProjectInformation");
		ProjectMaster projectMaster = this.dataAcquisitionPlanBusinessService.saveProjectInformation(projectMasterInfo);
		logger.info("Exit DataAcquisitionPlanServiceImpl saveProjectInformation");
		return projectMaster;
	}
}
