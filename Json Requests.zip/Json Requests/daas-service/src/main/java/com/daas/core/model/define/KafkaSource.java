package com.daas.core.model.define;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaSource implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -225662129920433485L;


	private String listofServers;
	private String clusterID;
	private String compressionType;
	private String producerType;
	private String batchSize;
	private String producerMaxMessageSize;
	private String acknowledgement;
	private String noOfReplicationFetchers;
	private String replicationFactorOffset;
	private String maxPartitions;
	private String consumerMaxMessageSize;
	
	public String getListofServers() {
		return listofServers;
	}
	public void setListofServers(String listofServers) {
		this.listofServers = listofServers;
	}
	public String getClusterID() {
		return clusterID;
	}
	public void setClusterID(String clusterID) {
		this.clusterID = clusterID;
	}
	public String getCompressionType() {
		return compressionType;
	}
	public void setCompressionType(String compressionType) {
		this.compressionType = compressionType;
	}
	public String getProducerType() {
		return producerType;
	}
	public void setProducerType(String producerType) {
		this.producerType = producerType;
	}
	public String getBatchSize() {
		return batchSize;
	}
	public void setBatchSize(String batchSize) {
		this.batchSize = batchSize;
	}
	public String getProducerMaxMessageSize() {
		return producerMaxMessageSize;
	}
	public void setProducerMaxMessageSize(String producerMaxMessageSize) {
		this.producerMaxMessageSize = producerMaxMessageSize;
	}
	public String getAcknowledgement() {
		return acknowledgement;
	}
	public void setAcknowledgement(String acknowledgement) {
		this.acknowledgement = acknowledgement;
	}
	public String getNoOfReplicationFetchers() {
		return noOfReplicationFetchers;
	}
	public void setNoOfReplicationFetchers(String noOfReplicationFetchers) {
		this.noOfReplicationFetchers = noOfReplicationFetchers;
	}
	public String getReplicationFactorOffset() {
		return replicationFactorOffset;
	}
	public void setReplicationFactorOffset(String replicationFactorOffset) {
		this.replicationFactorOffset = replicationFactorOffset;
	}
	public String getMaxPartitions() {
		return maxPartitions;
	}
	public void setMaxPartitions(String maxPartitions) {
		this.maxPartitions = maxPartitions;
	}
	public String getConsumerMaxMessageSize() {
		return consumerMaxMessageSize;
	}
	public void setConsumerMaxMessageSize(String consumerMaxMessageSize) {
		this.consumerMaxMessageSize = consumerMaxMessageSize;
	}
}
