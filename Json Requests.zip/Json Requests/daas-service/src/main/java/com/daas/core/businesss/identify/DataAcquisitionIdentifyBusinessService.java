package com.daas.core.businesss.identify;

import java.util.List;

import javax.ws.rs.PathParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.model.identify.DataAcquisitionCriteria;
import com.daas.core.model.identify.DataAcquisitionInfo;
import com.daas.core.model.identify.DataAcquisitionRequest;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition identify flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */
public interface DataAcquisitionIdentifyBusinessService {
   
	
	public DataAcquisitionCriteria getSearchInformation();
	
	 /**
     *  Method to get List of  DataAcquisitionInfo with all the grid data information from the database.
     * 
     * @param dataAcquisitionInfoRequest
     *           DataAcquisitionInfo POJO to get the grid information with all the EIM data.
     * @return List DataAcquisitionInfo List of EIM  extract that matches the
     *        		search criteria.
     */
	public List<DataAcquisitionInfo> search(DataAcquisitionInfo dataAcquisitionInfoRequest);
	
	
	/**
	 * Method to be used to fetch Application Information 
	 * 
	 * @param appInstId
	 * 
	 * @return DataAcquisition object
	 */
	public DataAcquisition getApplicationInformation(Integer appInstId);
	
	/**
     * Method to save/submit the data acquisition request.
     * 
     * @param dataAcquisitionRequestInfo
     *            DataAcquisitionRequest POJO to pass the acquisition request information.
     *            
     *@return dataAcquisitionBatchRequestId
     */
	public Integer saveAcquisitionRequest(List<DataAcquisitionRequest> dataAcquisitionRequestInfo);
	
	
	/**
     * Method to update the application details.
     * 
     * @param dataAcquisition
     *               
     */
	public void updateApplicationInformation (DataAcquisition dataAcquisition);
	
	//**************************************************************************************************************************************************************//
	public void create(@RequestBody DataAcquisitionRequest request);

	
	public List<DataAcquisitionRequest> trackRequest(@PathParam("requestedUser") String requestedUser,
			@PathParam("requestType") String requestType);
	
	public List<DataAcquisitionRequest> getRequestDetails(@PathParam("acquisitionReqId") Integer acquisitionReqId);
	
	public void update(@RequestBody DataAcquisitionRequest request);
	
	public void updateBulk(@RequestBody List<DataAcquisitionRequest> request);

	
	
}
	

