package com.daas.core.dao;

import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.daas.core.dao.identify.DataAcquisitionIdentifyDaoImpl;
import com.daas.core.dao.query.constants.DataAcquisitionQueryConstants;
import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.model.identify.DataAcquisitionRequest;
import com.daas.core.model.temp.Employee;
import com.daas.core.model.temp.User;
import com.google.gson.Gson;

public class DaoImplTest {

	private Logger logger=LoggerFactory.getLogger(DataAcquisitionIdentifyDaoImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	

	public Employee getEmployee(Integer empid) {
		//logger.debug(arg0);
	   this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);
	  // String sql = "SELECT * FROM Employee WHERE id = :id";
	   SqlParameterSource namedParameters = new MapSqlParameterSource("id", empid);
	   
	   Employee employee = null;
			   //namedParameterJdbcTemplate.queryForObject(DataAcquisitionQueryConstants.EMPLOYEE_FETCH_SQL_BY_ID, namedParameters, new BeanPropertyRowMapper<Employee>(Employee.class));
	   return employee;
	}
	
	
	public void create(List<Employee> employee) {
	  
	try {
		   this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);

	 String SQL = "INSERT INTO Employee (id,name, dept, salary) VALUES (:id,:name,:dept,:salary)";
	   SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(employee);

	 namedParameterJdbcTemplate.update(SQL, namedParameters );
	 // to simulate the exception.
	// throw new RuntimeException("simulate Error condition") ;
	  } catch (DataAccessException e) {
	       System.out.println("Error in creating record, rolling back");
	       throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),
                   e, null);
	    }
	}
	



	 public List<Employee> listEmployees() {
	  this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);

	  String SQL = "SELECT * FROM Employee";
	  List<Employee> employees =  namedParameterJdbcTemplate.query(SQL, new BeanPropertyRowMapper<Employee>(Employee.class));
	     return employees;
	 }


	 public void delete(Integer empid) {
		  this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);

	  String SQL = "DELETE FROM Employee WHERE empid = :id";
	   SqlParameterSource namedParameters = new MapSqlParameterSource("id", empid);

	  namedParameterJdbcTemplate.update(SQL, namedParameters);
	 }

	
	 public void update(Employee employee) {
		  this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);

	   String SQL = "UPDATE Employee SET salary = :salary WHERE id = :id";
	   SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(employee);
	 
	   namedParameterJdbcTemplate.update(SQL,namedParameters );
	 }


	public void jsonCreate(String empJson) {
		try {

			String SQL = "INSERT INTO json_employee (employee_json) VALUES ('"+empJson+"')";
			this.jdbcTemplate.update(SQL);
		} catch (DataAccessException e) {
			System.out.println("Error in creating record, rolling back");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
		
	}
	
	
	public void createDataAcquisitionRequest(DataAcquisitionRequest request) {
		try {

			Gson gson = new Gson();
			String jsonString = gson.toJson(request);
			//request.setData_acquisition_request_json(jsonString);
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		//	request.setStamp_created(timestamp);
			this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);

			String SQL = "INSERT INTO data_acquisition_request (status,requested_user,app_inst_id,app_inst_name,app_inst_short_name,app_inst_description,application_type,"
					+ " app_inst_status,app_inst_strategic_status,app_inst_reviewer_email,app_inst_reviewer_name,app_inst_lvl_4_bus_org,app_inst_lvl_4_bus_org_owner,"
					+ " app_inst_lvl_5_bus_org,app_inst_lvl_4_it_dir,app_inst_lvl_4_it_dir_owner,app_inst_lvl_5_it_dir,app_inst_lvl_5_it_dir_owner,"
					+ " app_inst_dev_manager_primary,app_inst_dev_manager_secondary,application_id,application_name,app_it_owner,app_bus_owner,app_inst_pri_data_centre,"
					+ " app_inst_pri_data_centre_type,app_inst_sec_data_centre,app_inst_supporting_region,app_inst_supporting_country,app_inst_dev_region,"
					+ " app_inst_dev_country,stamp_created,data_acquisition_request_json)"
					+ " VALUES (:status,:requested_user,:app_inst_id,:app_inst_name,:app_inst_short_name,:app_inst_description,:application_type,:app_inst_status,"
					+ ":app_inst_strategic_status,:app_inst_reviewer_email,:app_inst_reviewer_name,:app_inst_lvl_4_bus_org,:app_inst_lvl_4_bus_org_owner,:app_inst_lvl_5_bus_org,"
					+ ":app_inst_lvl_4_it_dir,:app_inst_lvl_4_it_dir_owner,:app_inst_lvl_5_it_dir,:app_inst_lvl_5_it_dir_owner,:app_inst_dev_manager_primary,"
					+ ":app_inst_dev_manager_secondary,:application_id,:application_name,:app_it_owner,:app_bus_owner,:app_inst_pri_data_centre,"
					+ ":app_inst_pri_data_centre_type,:app_inst_sec_data_centre,:app_inst_supporting_region,:app_inst_supporting_country,"
					+ ":app_inst_dev_region,:app_inst_dev_country,:stamp_created,:data_acquisition_request_json)";
			SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(request);
			namedParameterJdbcTemplate.update(SQL, namedParameters);
		} catch (DataAccessException e) {
			logger.error("Error in creating record, rolling back");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
	}

	
	public List<DataAcquisition> getUserDetails(User user) {
		List<DataAcquisition> dataAcquisition = null;
		String sql = "SELECT count(*) FROM user WHERE username = ? ";
		Object[] inputs = new Object[] { user.getUsername() };

		Integer count = this.jdbcTemplate.queryForObject(sql, inputs, Integer.class);
		System.out.println("count:::::::::::" + count);
		if (count != 0) {
			dataAcquisition = getDataAcquisitionDetails();
		} else {
			throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), user.getUsername(),
					new Exception("Invalid User Credentials"));
		}
		return dataAcquisition;
	}
	
	private List<DataAcquisition> getDataAcquisitionDetails(){
		String SQL = "SELECT * FROM data_acquisition_master";
		List<DataAcquisition> dataAcquisition =  this.namedParameterJdbcTemplate.query(SQL, new BeanPropertyRowMapper<DataAcquisition>(DataAcquisition.class));
		return dataAcquisition;
	}

}
