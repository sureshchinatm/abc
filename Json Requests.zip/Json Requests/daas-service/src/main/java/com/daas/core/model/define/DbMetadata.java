package com.daas.core.model.define;

import java.io.Serializable;

public class DbMetadata implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 574124209788740631L;

	private Scheduling scheduling;
	
	private String request_id;
	
	private SourceProperties source_properties;
	
	private Classification classification;

	public Scheduling getScheduling ()
	{
	return scheduling;
	}
	
	public void setScheduling (Scheduling scheduling)
	{
	this.scheduling = scheduling;
	}
	
	public String getRequest_id ()
	{
	return request_id;
	}
	
	public void setRequest_id (String request_id)
	{
	this.request_id = request_id;
	}
	
	public SourceProperties getSource_properties() {
		return source_properties;
	}

	public void setSource_properties(SourceProperties source_properties) {
		this.source_properties = source_properties;
	}

	public Classification getClassification ()
	{
	return classification;
	}
	
	public void setClassification (Classification classification)
	{
	this.classification = classification;
	}

	
}
