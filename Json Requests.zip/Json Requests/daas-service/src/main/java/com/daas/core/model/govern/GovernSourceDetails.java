package com.daas.core.model.govern;

import java.io.Serializable;
import java.security.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GovernSourceDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2251462240411568034L;
	
	private Integer project_id;
	private Integer data_clinic_approval_id;
	private String app_inst_name;
	private String data_group;
	private Integer app_inst_id;
	private String application_name;
	private String app_inst_lvl_4_bus_org_owner;
	private String app_inst_lvl_4_bus_org;
	private String app_inst_dev_country;
	private String status;
	private Timestamp stamp_created; 
	
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public String getApp_inst_name() {
		return app_inst_name;
	}
	public void setApp_inst_name(String app_inst_name) {
		this.app_inst_name = app_inst_name;
	}
	public String getData_group() {
		return data_group;
	}
	public void setData_group(String data_group) {
		this.data_group = data_group;
	}
	public Integer getApp_inst_id() {
		return app_inst_id;
	}
	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}
	public String getApplication_name() {
		return application_name;
	}
	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	public String getApp_inst_lvl_4_bus_org_owner() {
		return app_inst_lvl_4_bus_org_owner;
	}
	public void setApp_inst_lvl_4_bus_org_owner(String app_inst_lvl_4_bus_org_owner) {
		this.app_inst_lvl_4_bus_org_owner = app_inst_lvl_4_bus_org_owner;
	}
	public String getApp_inst_lvl_4_bus_org() {
		return app_inst_lvl_4_bus_org;
	}
	public void setApp_inst_lvl_4_bus_org(String app_inst_lvl_4_bus_org) {
		this.app_inst_lvl_4_bus_org = app_inst_lvl_4_bus_org;
	}
	public String getApp_inst_dev_country() {
		return app_inst_dev_country;
	}
	public void setApp_inst_dev_country(String app_inst_dev_country) {
		this.app_inst_dev_country = app_inst_dev_country;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getData_clinic_approval_id() {
		return data_clinic_approval_id;
	}
	public void setData_clinic_approval_id(Integer data_clinic_approval_id) {
		this.data_clinic_approval_id = data_clinic_approval_id;
	}
	public Timestamp getStamp_created() {
		return stamp_created;
	}
	public void setStamp_created(Timestamp stamp_created) {
		this.stamp_created = stamp_created;
	}
}
