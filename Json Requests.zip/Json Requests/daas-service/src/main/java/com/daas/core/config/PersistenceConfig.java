package com.daas.core.config;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.util.LoggerConstants;
import com.mchange.v2.c3p0.ComboPooledDataSource;


/**
 * This class is java based configuration of data source and entity manager
 * using the Spring JDBC Template, JNDI look ups and the database connections configurations.
 * The Daas application uses the JNDI lookup and the ComboPooledDataSource
 * 
 * @author snatti
 */
@Configuration
@PropertySource(value = "classpath:db.properties")
@EnableTransactionManagement
public class PersistenceConfig {

	private static Logger logger=LoggerFactory.getLogger(PersistenceConfig.class);
	
	 /**
     * Create new Environment object
     */
    @Autowired
    private Environment env;
    
    /**
     * 
     * @return The Place holder configurer is returned.
     */
    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0001);
        return new PropertySourcesPlaceholderConfigurer();
    }
    
	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource){
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0001);
		return new JdbcTemplate(dataSource);
	}

	@Bean
	public PlatformTransactionManager transactionManager(DataSource dataSource)	{
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0001);
		return new DataSourceTransactionManager(dataSource);
	}

    /**
     * This method Creates the new instance of Data source object 
     * 
     * @return {@link DataSource} Returns new Data source.
     */
    @Bean
    public DataSource dataSource() {
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0001);
        DataSource dataSource = null;
       // Context context = null;
            try {
         //       context = new InitialContext();
                dataSource = this.getConnectionPool();
                		//(DataSource) context.lookup(Constants.DATA_SOURCE_NAME);
            } catch (Exception e) { // catch(NamingException) - if using lookup and JNDI add this and remove Exception
              //  logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, e);
                throw new DaasBusinessException(
                                ErrorConstants.SYS_NAMING_EXCEPTION_ERROR.getCode().toString(),
                                null, e);
            }
            logger.debug(LoggerConstants.COMMON_LOG_MSG_0002);
            return dataSource;
        }
    
    /**
     * This method created the Data source connection using
     * ComboPooledDataSource for the connection pool.
     * 
     * @return {@link DataSource} Returns new DataSource.
     */
    private DataSource getConnectionPool() {
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0001);
        DataSource dataSource = null;
        try {
        	ComboPooledDataSource dataSourcePool = new ComboPooledDataSource();
            dataSourcePool.setDriverClass(this.env.getProperty("mysql.jdbc.driverClassName"));
            dataSourcePool.setJdbcUrl(this.env.getProperty("mysql.jdbc.url"));
            dataSourcePool.setUser(this.env.getProperty("mysql.jdbc.username"));
            dataSourcePool.setPassword(this.env.getProperty("mysql.jdbc.password"));
            dataSourcePool.setAcquireIncrement(5);
            dataSourcePool.setIdleConnectionTestPeriod(60);
            dataSourcePool.setMaxPoolSize(10);
            dataSourcePool.setMaxStatements(5);
            dataSourcePool.setMinPoolSize(3);
            dataSource = dataSourcePool;
        } catch (PropertyVetoException e) {
          //  logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, e);
            throw new DaasBusinessException(
                            ErrorConstants.SYS_PROP_VETO_ERROR.getCode().toString(), null, e);
        }
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0002);
        return dataSource;
    }
    
    
    /**
     * This class Creates new DataSourceInitializer object instance.
     * 
     * @param dataSource
     *            the data source value.
     * @return {@link DataSourceInitializer} Returns new DataSourceInitializer.
     */
    @Bean
    public DataSourceInitializer dataSourceInitializer(DataSource dataSource) {
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0001);
        DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(dataSource);
        logger.debug(LoggerConstants.COMMON_LOG_MSG_0002);
        return dataSourceInitializer;
    }
}
