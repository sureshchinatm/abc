package com.daas.core.service.prepare;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.daas.core.model.prepare.ScanDetails;

/**
 * This interface is the service class for Data Acquisition Prepare module which
 * consumes the JSON data from the rest call and returns the response in the
 * form of JSON.
 * 
 * @author snatti
 */

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface DataAcquisitionPrepareService {

	/**
	 * Entry point method to fetch Scanning Status Details
	 * 
	 * @param requestId
	 * 
	 * @return List<ScanDetails> with all the Scanning Status information.
	 */
	@GET
	@Path("/getScanInfo/{requestId}")
	public List<ScanDetails> getScanInformation(@PathParam("requestId") Integer requestId);

}
