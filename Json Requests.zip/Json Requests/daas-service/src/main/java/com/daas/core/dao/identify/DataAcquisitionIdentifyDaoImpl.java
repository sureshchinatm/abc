package com.daas.core.dao.identify;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.APPLICATION_NAME_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.DATA_GROUP_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GENERATE_BATCH_ID;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.LOB_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.REGION_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GET_APPLICATION_DETAILS_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.UPDATE_APPLICATION_DETAILS_SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.daas.core.dao.mapper.identify.ApplicationNamesExtractor;
import com.daas.core.dao.mapper.identify.DataGroupsExtractor;
import com.daas.core.dao.mapper.identify.LobsExtractor;
import com.daas.core.dao.mapper.identify.RegionsExtractor;
import com.daas.core.dao.util.DbUtil;
import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.model.identify.DataAcquisitionCriteria;
import com.daas.core.model.identify.DataAcquisitionInfo;
import com.daas.core.model.identify.DataAcquisitionRequest;
import com.daas.core.model.temp.ApplicationDataSource;
import com.daas.core.model.temp.SourceDetails;
import com.daas.core.util.ErrorMessageConstants;
import com.google.gson.Gson;


/**
 * This class provides the implementation methods for DataAcquisitionIdentifyDao.
 * 
 * @author snatti
 */
@Repository
public class DataAcquisitionIdentifyDaoImpl implements DataAcquisitionIdentifyDao {

	private Logger logger = LoggerFactory.getLogger(DataAcquisitionIdentifyDaoImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	
	@Override
	public DataAcquisitionCriteria fetchSearchInformation() {
		logger.info("Enter DataAcquisitionIdentifyDaoImpl fetchSearchInformation");

		DataAcquisitionCriteria dataAcquisitionCriteria = new DataAcquisitionCriteria();
		dataAcquisitionCriteria = getDataAcquisitionCriteriaInfoDetails();
			
		logger.info("Exit DataAcquisitionIdentifyDaoImpl fetchSearchInformation");
		return dataAcquisitionCriteria;
	}

	private DataAcquisitionCriteria getDataAcquisitionCriteriaInfoDetails() {
		DataAcquisitionCriteria dataAcquisitionCriteria = null;
		List<String> errorList;
		// try{

		List<String> dataGroups = this.jdbcTemplate.query(DATA_GROUP_SQL, new DataGroupsExtractor() {
		});
		List<String> applicationNames = this.jdbcTemplate.query(APPLICATION_NAME_SQL, new ApplicationNamesExtractor() {
		});
		List<String> lobs = this.jdbcTemplate.query(LOB_SQL, new LobsExtractor() {
		});
		List<String> regions = this.jdbcTemplate.query(REGION_SQL, new RegionsExtractor() {
		});

		if (dataGroups != null && applicationNames != null && lobs != null && regions != null) {
			dataAcquisitionCriteria = new DataAcquisitionCriteria();
			dataAcquisitionCriteria.setDataGroups(dataGroups);
			dataAcquisitionCriteria.setApplicationNames(applicationNames);
			dataAcquisitionCriteria.setLobs(lobs);
			dataAcquisitionCriteria.setRegions(regions);
		}
		if (dataAcquisitionCriteria == null) {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.NO_DATA_FOUND);
			throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
		}

		
		return dataAcquisitionCriteria;
	}

	@Override
	public List<DataAcquisitionInfo> getSearchCriteria(DataAcquisitionInfo dataAcquisitionInforequest) {

		List<String> errorList;
		logger.info("Enter DataAcquisitionIdentifyDaoImpl getSearchCriteria");
		List<DataAcquisitionInfo> dataAcquisitionInfo = null;
		try {
			String searchQuery = DbUtil.getSearchSql(dataAcquisitionInforequest);
			logger.info("getSearchCriteria SQL::::::::::" +searchQuery);
			SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(dataAcquisitionInforequest);
			dataAcquisitionInfo = this.namedParameterJdbcTemplate.query(searchQuery, namedParameters,
					new BeanPropertyRowMapper<DataAcquisitionInfo>(DataAcquisitionInfo.class));
			if (dataAcquisitionInfo == null) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.NO_DATA_FOUND_FOR_REQUEST);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
			}
		} catch (DataAccessException e) {
			logger.error(
					"Error in fetching Acquisition Search Request Details , rolling back::::::: method getSearchCriteria() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_REQUEST);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList, null,null);
		}
		logger.info("Exit DataAcquisitionIdentifyDaoImpl getSearchCriteria");
		return dataAcquisitionInfo;
	}

	@Override
	public DataAcquisition fetchApplicationInformation(Integer appInstId) {
		List<String> errorList;
		logger.info("Enter DataAcquisitionIdentifyDaoImpl fetchApplicationInformation");
		DataAcquisition dataAcquisition = null;
		try {
			SqlParameterSource namedParameters =new MapSqlParameterSource("app_inst_id", appInstId);

			dataAcquisition = this.namedParameterJdbcTemplate.queryForObject(GET_APPLICATION_DETAILS_SQL, namedParameters,
					new BeanPropertyRowMapper<DataAcquisition>(DataAcquisition.class));
			
			if (dataAcquisition == null) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.NO_DATA_FOUND_FOR_REQUEST);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
			}
		} catch (DataAccessException e) {
			logger.error(
					"Error in fetching Application Details, rolling back::::::: method fetchApplicationInformation() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_REQUEST);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList, null,null);
		}
		logger.info("Exit DataAcquisitionIdentifyDaoImpl fetchApplicationInformation");
		return dataAcquisition;
	}

	
	@Override
	public Integer save(List<DataAcquisitionRequest> dataAcquisitionRequestInfo) {
		List<String> errorList;
		logger.info("Exit DataAcquisitionIdentifyDaoImpl save");
		Integer batchId;
		try {

			batchId = createBatchId();

			int[] count = bulkInsertIntoDataAcquisitionRequestTable(dataAcquisitionRequestInfo, batchId);

			logger.info("batch update count:::::::" + count);

			if (!(count.length != 0)) {
				logger.error(
						"Error in creating DataAcquisition Request, rolling back :::: methodName bulkInsertIntoDataAcquisitionRequestTable()");
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.CREATE_FAILED_FOR_REQUEST);
				throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,null, null);
			}
		}catch (DataAccessException e) {
			logger.error("Error in saving/submitting record, rolling back \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.SAVE_FAILED_FOR_REQUEST);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionIdentifyDaoImpl save");
		
		return batchId;
	}

	private Integer createBatchId() {
		logger.info("Enter DataAcquisitionIdentifyDaoImpl createBatchId");

		KeyHolder keyHolder = new GeneratedKeyHolder();

		Integer batchId = 0;

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		int row = this.jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement statement = con.prepareStatement(GENERATE_BATCH_ID, Statement.RETURN_GENERATED_KEYS);
				statement.setString(1, timestamp.toString());

				return statement;
			}
		}, keyHolder);

		logger.info("row:::::" + row);

		if (row > 0) {
			batchId = keyHolder.getKey().intValue();
		}
		logger.info("batchId:::::: " + batchId);
		logger.info("Exit DataAcquisitionIdentifyDaoImpl createBatchId");

		return batchId;
	}

	public int[] bulkInsertIntoDataAcquisitionRequestTable(List<DataAcquisitionRequest> request, Integer batchId) {
		logger.info("Enter DataAcquisitionDaoImpl bulkInsertIntoDataAcquisitionRequestTable");

		final String SQL = "INSERT INTO data_acquisition_request (data_acquisition_batch_request_id,status, app_inst_id, application_name,data_group,app_inst_name,"
				+ "app_inst_reviewer_name, app_inst_lvl_4_bus_org,app_inst_lvl_4_bus_org_owner, app_inst_dev_country)"
				+ " VALUES (" + batchId + ",:status,:app_inst_id,:application_name,:data_group,:app_inst_name,"
				+ ":app_inst_reviewer_name,:app_inst_lvl_4_bus_org,:app_inst_lvl_4_bus_org_owner,:app_inst_dev_country)";
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(request.toArray());
		int[] insertCounts = this.namedParameterJdbcTemplate.batchUpdate(SQL, batch);
		logger.info("Exit DataAcquisitionDaoImpl bulkInsertIntoDataAcquisitionRequestTable");
		return insertCounts;
	}
	
	@Override
	public void update(DataAcquisition request) {
		List<String> errorList;
		try {
			SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(request);
			this.namedParameterJdbcTemplate.update(UPDATE_APPLICATION_DETAILS_SQL, namedParameters);
		} catch (DataAccessException e) {
			logger.error("Error in updating application details, rolling back \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.UPDATE_FAILED_FOR_AQUISTIONID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}

	}
	//********************** To be removed later **************************///
	private List<ApplicationDataSource> getApplicationDetails(String roleName, String userName) {
		List<ApplicationDataSource> applicationData = null;
		List<String> errorList;
		// try{
		// select * from newtrable where newtable n , users u where u.lobid =
		// newtable.lobid
		String SQL = "SELECT *,'" + roleName
				+ "' as rolename FROM data_acquisition_master_test where app_inst_reviewer_name='" + userName + "'";
		applicationData = this.namedParameterJdbcTemplate.query(SQL,
				new BeanPropertyRowMapper<ApplicationDataSource>(ApplicationDataSource.class));
		if (applicationData != null && applicationData.size() != 0) {
			return applicationData;
		} else {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.NO_DATA_FOUND);
			throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,userName,null);
		}
		/*
		 * }catch(DaasBaseException e){ logger.
		 * error("Error in fetching Data Acquisition Prepopulated Form Details:::::::method getDataAcquisitionDetails()"
		 * ); throw new
		 * DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),
		 * e, null); }
		 */
		// return dataAcquisition;
	}

	@Override
	public List<DataAcquisitionRequest> getRequestedUserDetails(String requestedUser, String requestType) {
		List<DataAcquisitionRequest> dataAcquisitionRequestInfo = null;
		List<String> errorList;
		try {
			String SQL = null;

			String roleName = null; //getUserRole(requestedUser);
			if ("Requestor".equalsIgnoreCase(roleName)) {
				SQL = "select * from data_acquisition_request where requested_user='" + requestedUser
						+ "' and request_type='" + requestType + "' order by status DESC";
			} else if ("Approver".equalsIgnoreCase(roleName)) {
				SQL = "select * from data_acquisition_request where app_inst_lvl_4_bus_org_owner='" + requestedUser
						+ "' and request_type='" + requestType + "' order by status DESC";
			}

			logger.debug("getRequestDetails SQL::::::::::" + SQL);
			dataAcquisitionRequestInfo = this.namedParameterJdbcTemplate.query(SQL,
					new BeanPropertyRowMapper<DataAcquisitionRequest>(DataAcquisitionRequest.class));
		} catch (DataAccessException e) {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_USER);
			logger.error("Error in fetching Request Details , rolling back::::::: method getRequestDetails() \n " + e);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		return dataAcquisitionRequestInfo;
	}

	@Override
	public List<DataAcquisitionRequest> getAcquisitionRequestDetails(Integer acquisitionReqId) {
		List<DataAcquisitionRequest> dataAcquisitionRequestInfo = null;
		List<String> errorList;
		try {
			String SQL = "select * from data_acquisition_request where data_acquisition_request_id='" + acquisitionReqId
					+ "'";
			logger.debug("getAcquisitionRequestDetails SQL::::::::::" + SQL);
			dataAcquisitionRequestInfo = this.namedParameterJdbcTemplate.query(SQL,
					new BeanPropertyRowMapper<DataAcquisitionRequest>(DataAcquisitionRequest.class));
		} catch (DataAccessException e) {
			logger.error(
					"Error in fetching AcquisitionId Request Details , rolling back::::::: method getAcquisitionRequestDetails() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_AQUISTIONID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		return dataAcquisitionRequestInfo;
	}

	

	@Override
	public void updateBulk(List<DataAcquisitionRequest> request) {
		List<String> errorList;
		try {

			/*
			 * Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			 * request.setStamp_created(timestamp.toString()); Integer
			 * dataAcquisitionReqId = request.getData_acquisition_request_id();
			 */

			int[] count = bulkUpdateIntoDataAcquisitionRequestTable(request);
			System.out.println("batch update count:::::::" + count);

			// int dsapcount = bulkUpdateIntoDsapRequestTable(request);
			if (!(count.length != 0)) {
				logger.error(
						"Error in updating DataAcquisitionRequest status , rolling back :::: methodName bulkUpdateIntoDataAcquisitionRequestTable()");
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.UPDATE_FAILED_FOR_AQUISTIONID);
				throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,null, null);
			}

		} catch (DataAccessException e) {
			logger.error("Error in creating record, rolling back \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.UPDATE_FAILED_FOR_AQUISTIONID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}

	}

	/*public int[] bulkUpdateIntoDataAcquisitionRequestTable(List<DataAcquisitionRequest> request) {
		System.out.println("Enter dao impl bulkUpdateIntoEmployeeTable::::::::::");
		String SQL = "UPDATE data_acquisition_request SET status=:status ,dsap_approval_id=:dsap_approval_id where data_acquisition_request_id=:data_acquisition_request_id";
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(request.toArray());
		int[] updateCounts = this.namedParameterJdbcTemplate.batchUpdate(SQL, batch);
		return updateCounts;
	}*/

	public SourceDetails getSourceDetails(String sourcename) {
		List<String> errorList;
		try {
		
			String SQL = "select source_value from source_values sv,source_keys sk where sk.source_id = sv.parent_source_id "
					+ "and sk.source_name = ?";
			logger.info("getSourceDetails SQL::::::::::" + SQL);
		
			return this.jdbcTemplate.query(SQL, new ResultSetExtractor<SourceDetails>() {
				public SourceDetails extractData(ResultSet rs) throws SQLException, DataAccessException {
					SourceDetails sourceDataInfo = new SourceDetails();
					List<String> sourceValues = new ArrayList<String>();
				//	int row = 0;
					while (rs.next()) {
						sourceValues.add(rs.getString("source_value"));
						//row++;
					}
					//logger.info("rowCount::::::::" + row);
					sourceDataInfo.setSourceValues(sourceValues);
					logger.info("Size::::::" + sourceDataInfo.getSourceValues().size());
					sourceDataInfo.setSourceName(sourcename);
					return sourceDataInfo;
				}
			}, sourcename);
		} catch (DataAccessException e) {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_SOURCENAME);
			logger.error("Error in fetching Source Details , rolling back::::::: method getSourceDetails() \n " + e);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		// return sourceDataInfo;
	}


	public int[] bulkUpdateIntoDataAcquisitionRequestTable(List<DataAcquisitionRequest> request) {
		System.out.println("Enter DataAcquisitionDaoImpl bulkUpdateIntoDataAcquisitionRequestTable");
		String SQL = "UPDATE data_acquisition_request SET status=:status,app_inst_id=:app_inst_id,application_name=:application_name,"
				+ "data_group=:data_group,app_inst_name=:app_inst_name,app_inst_reviewer_name=:app_inst_reviewer_name,"
				+ "app_inst_lvl_4_bus_org=:app_inst_lvl_4_bus_org,app_inst_lvl_4_bus_org_owner=:app_inst_lvl_4_bus_org_owner,"
				+ "app_inst_dev_country=:app_inst_dev_country"
				+ " where data_acquisition_request_id=:data_acquisition_request_id";
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(request.toArray());
		int[] updateCounts = this.namedParameterJdbcTemplate.batchUpdate(SQL, batch);
		logger.info("Exit DataAcquisitionDaoImpl bulkUpdateIntoDataAcquisitionRequestTable");
		return updateCounts;
	}
	
	@Override
	public void createDataAcquisitionRequest(DataAcquisitionRequest request) {
		List<String> errorList;
		try {

			Gson gson = new Gson();
			String jsonString = gson.toJson(request);
			//request.setData_acquisition_request_json(jsonString);
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			request.setStamp_created(timestamp.toString());
			this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);

			String SQL = "INSERT INTO data_acquisition_request (status,requested_user,request_type,app_inst_id,app_inst_name,app_inst_short_name,app_inst_description,application_type,"
					+ " app_inst_status,app_inst_strategic_status,app_inst_reviewer_email,app_inst_reviewer_name,app_inst_lvl_4_bus_org,app_inst_lvl_4_bus_org_owner,"
					+ " app_inst_lvl_5_bus_org,app_inst_lvl_4_it_dir,app_inst_lvl_4_it_dir_owner,app_inst_lvl_5_it_dir,app_inst_lvl_5_it_dir_owner,"
					+ " app_inst_dev_manager_primary,app_inst_dev_manager_secondary,application_id,application_name,app_it_owner,app_bus_owner,app_inst_pri_data_centre,"
					+ " app_inst_pri_data_centre_type,app_inst_sec_data_centre,app_inst_supporting_region,app_inst_supporting_country,app_inst_dev_region,"
					+ " app_inst_dev_country,stamp_created,data_acquisition_request_json)"
					+ " VALUES (:status,:requested_user,:request_type,:app_inst_id,:app_inst_name,:app_inst_short_name,:app_inst_description,:application_type,:app_inst_status,"
					+ ":app_inst_strategic_status,:app_inst_reviewer_email,:app_inst_reviewer_name,:app_inst_lvl_4_bus_org,:app_inst_lvl_4_bus_org_owner,:app_inst_lvl_5_bus_org,"
					+ ":app_inst_lvl_4_it_dir,:app_inst_lvl_4_it_dir_owner,:app_inst_lvl_5_it_dir,:app_inst_lvl_5_it_dir_owner,:app_inst_dev_manager_primary,"
					+ ":app_inst_dev_manager_secondary,:application_id,:application_name,:app_it_owner,:app_bus_owner,:app_inst_pri_data_centre,"
					+ ":app_inst_pri_data_centre_type,:app_inst_sec_data_centre,:app_inst_supporting_region,:app_inst_supporting_country,"
					+ ":app_inst_dev_region,:app_inst_dev_country,:stamp_created,:data_acquisition_request_json)";
			SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(request);
			namedParameterJdbcTemplate.update(SQL, namedParameters);
		} catch (DataAccessException e) {
			logger.error("Error in creating record, rolling back \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.CREATE_FAILED_FOR_REQUEST);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
	}

	@Override
	public void update(DataAcquisitionRequest request) {
		// TODO Auto-generated method stub
		
	}
}
