package com.daas.core.model.define;

import java.io.Serializable;

public class SourceProperties implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8192786264348624580L;

	private Db db;

	public Db getDb() {
		return db;
	}

	public void setDb(Db db) {
		this.db = db;
	}

}
