package com.daas.core.businesss.prepare;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.prepare.DataAcquisitionPrepareDao;
import com.daas.core.model.prepare.ScanDetails;

/**
 * This class provides implementation for DataAcquisitionPrepareBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */

@Service
public class DataAcquisitionPrepareBusinessServiceImpl implements DataAcquisitionPrepareBusinessService{

	 
    /**
     * Logger object to log all the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionPrepareBusinessServiceImpl.class);
    
    /**
     * Autowired DataAcquisitionPlanDao to perform CRUD operations.
     */
    @Autowired
    private DataAcquisitionPrepareDao dataAcquisitionPrepareDao;
	
    /**
     * Returns the Scanning Status information from the database based on the requestId.
     * 
     * @param requestId
     *           
     * @return List of  Scanning Status Details matching the requestId.
     */
	@Override
	@Transactional(readOnly = true)
	public List<ScanDetails> getScanInformation(Integer requestId) {
		logger.info("Enter DataAcquisitionPrepareBusinessServiceImpl getScanInformation");
		List<ScanDetails> scanDetails = this.dataAcquisitionPrepareDao.fetchScanInformation(requestId);
		logger.info("Exit DataAcquisitionPrepareBusinessServiceImpl getScanInformation");
		return scanDetails;
	}

	
}
