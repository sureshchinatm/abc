package com.daas.core.util;

public enum ApproverType {

	SourceOwner(0), // calls constructor with value 0
	DataClinicApprover(1), // calls constructor with value 1
	GBDSManager(2) // calls constructor with value 2
	; // semicolon needed when fields / methods follow

	private int approverCode;

	private ApproverType(int approverCode) {
		this.approverCode = approverCode;
	}

	public int getApproverCode() {
		return approverCode;
	}

	public static String getStringValueFromInt(int i) {
		for (ApproverType approverType : ApproverType.values()) {
			if (approverType.getApproverCode() == i) {
				return approverType.toString();
			}
		}
		throw new IllegalArgumentException("the given number doesn't match any Approver Type.");
	}
}
