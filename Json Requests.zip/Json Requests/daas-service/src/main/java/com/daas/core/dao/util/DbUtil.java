package com.daas.core.dao.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daas.core.model.identify.DataAcquisitionInfo;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GET_IDENTIFY_SEARCH_CRITERIA_SQL;

public class DbUtil {
	

	private static Logger logger = LoggerFactory.getLogger(DbUtil.class);

	public static String getSearchSql(DataAcquisitionInfo dataAcquisitionInforequest) {

		logger.info("Enter DbUtil getSearchCriteria");
		StringBuilder sb = new StringBuilder();

		String data_group, application_name, app_inst_lvl_4_bus_org, app_inst_dev_country;
		data_group = dataAcquisitionInforequest.getData_group();
		application_name = dataAcquisitionInforequest.getApplication_name();
		app_inst_lvl_4_bus_org = dataAcquisitionInforequest.getApp_inst_lvl_4_bus_org();
		app_inst_dev_country = dataAcquisitionInforequest.getApp_inst_dev_country();

		sb.append(GET_IDENTIFY_SEARCH_CRITERIA_SQL);

		if (data_group != null || application_name != null || app_inst_lvl_4_bus_org != null
				|| app_inst_dev_country != null) {
			sb.append(" where ");

			int i = 0;

			if (data_group != null) {
				sb.append(getConditionStr("data_group", data_group));
				i++;
			}

			if (application_name != null) {
				if (i > 0) {
					sb.append(getConditionStrWithAnd("application_name", application_name));
				} else {
					sb.append(getConditionStr("application_name", application_name));
					i++;
				}
			}

			if (app_inst_lvl_4_bus_org != null) {
				if (i > 0) {
					sb.append(getConditionStrWithAnd("app_inst_lvl_4_bus_org", app_inst_lvl_4_bus_org));
				} else {
					sb.append(getConditionStr("app_inst_lvl_4_bus_org", app_inst_lvl_4_bus_org));
					i++;
				}
			}

			if (app_inst_dev_country != null) {
				if (i > 0) {
					sb.append(getConditionStrWithAnd("app_inst_dev_country", app_inst_dev_country));
				} else {
					sb.append(getConditionStr("app_inst_dev_country", app_inst_dev_country));
				}
			}
		}
		logger.info("GET_IDENTIFY_SEARCH_CRITERIA_SQL --" + sb.toString());
		logger.info("Exit DbUtil getSearchCriteria");

		return sb.toString();
	}
	
	private static String getConditionStr(String attrName, String attrVal) {
		return " " + attrName + "='" + attrVal + "' ";
	}
	private static String getConditionStrWithAnd(String attrName, String attrVal) {
		return " and " + attrName + "='" + attrVal + "' ";
	}
	
	/*private static String getConditionStr(String attrName, String attrVal) {
		return " " + attrName + "=" + attrVal + " ";
	}

	private static String getConditionStrWithAnd(String attrName, String attrVal) {
		return " and " + attrName + "=" + attrVal + " ";
	}*/

}
