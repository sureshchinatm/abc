package com.daas.core.businesss.project;

import java.util.List;

import com.daas.core.model.project.ProjectMaster;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition define flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */
public interface DataAcquisitionProjectBusinessService {
	
	 /**
     *  Returns ProjectMaster with all the Project and System information from the database.
     * 
     * @param projectId
     *          
     * @return ProjectMaster that matches the
     *        		projectId.
     */
	public ProjectMaster getProjectInformation(Integer projectId);

	 /**
     * Method to fetch  Projects Info with all the Projects grid data information from the database.
     * 
     * @param userId
     *          
     * @return List ProjectMaster to extract Projects  that matches the
     *        		user.
     */
	public List<ProjectMaster> getProjects(Integer userId);
	
	 /**
     * Method to update Project stage information.
     * 
     * @param projectMaster
     *          
     */
	public void updateProjectStage(ProjectMaster projectMaster);
}


