package com.daas.core.exception.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * This class contains methods to log the errors and to get the time stamp based
 * on the specific time format
 * 
 * @author snatti
 *         
 */
public final class ExceptionUtils{
    
	private Logger logger=LoggerFactory.getLogger(ExceptionUtils.class);
    
   
    private ExceptionUtils() {
        // Empty private constructor used to avoid unnecessary creation of
        // objects
    }
    
    /**
     * This method generates the time format in the requested format
     * 
     * @return {@code SimpleDateFormat}
     */
    public static String getCurrentTimeStamp() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(new Date());
    }
}
