package com.daas.core.businesss.plan;

import java.util.List;

import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition plan flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */
public interface DataAcquisitionPlanBusinessService {
	
	 /**
     *  Returns System Information from the database.
     * 
     * @param dataAcquisitionBatchRequestId
     *          
     * @return  List of  SystemDetails that matches the
     *        		dataAcquisitionBatchRequestId.
     */
	public List<SystemDetails> getSystemInformation(Integer dataAcquisitionBatchRequestId);

	 /**
     * Method to  save/submit the project information of a user.
     * 
     * @param projectMasterInfo
     *            ProjectMaster to save the information to DB.
     */ 
	public ProjectMaster saveProjectInformation(ProjectMaster projectMasterInfo) ;
}
