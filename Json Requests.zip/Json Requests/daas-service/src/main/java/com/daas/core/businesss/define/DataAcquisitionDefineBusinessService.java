package com.daas.core.businesss.define;

import java.util.List;

import com.daas.core.model.define.DbSchemaInfo;
import com.daas.core.model.define.DbSourceNameInfo;
import com.daas.core.model.define.Sources;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition define flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */
public interface DataAcquisitionDefineBusinessService {
	
	 /**
     *  Method to fetch All Sources Related to the System.
     * 
     * @param systemId
     *          
     * @return List<DbSourceNameInfo>  with all the Sources related to the selected System.
     *        		
     */
	public List<DbSourceNameInfo> getSourceInformation(Integer systemId);
	
	 /**
     *  Method to get All Source related Schemas and Its Attribute Information.
     * 
     * @param systemId
     * @param sourceId
     *          
     * @return  List of Sources  with all the Source related Schemas and Its Attribute Information.
     *        		
     */
	public List<Sources> getSchemaInformation(Integer systemId, Integer sourceId,String frequency);
	
	 /**
     * Method to  save/submit the project information of a user.
     * 
     * @param projectSourceInfo
     *            ProjectSourceInfo to save the information to DB.
     */ 
	public void saveSchemaInformation(DbSchemaInfo dbSchemaInfo) ;
}
