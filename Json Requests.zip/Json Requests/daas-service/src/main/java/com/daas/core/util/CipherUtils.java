package com.daas.core.util;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 *	This class given peforms AES-128 bit Encryption in Java. The below class needs Java version 8 or above
 *  because there was no Base64 encoder in older java versions
 *	and you had to use some external libraries. 
 * 
 * @author snatti
 */
public class CipherUtils {

	/*
	 * We first initialize a 16 character (128 bit) secret key for the
	 * encryption.
	 * 
	 */
	
	//private static String algo ="AES/ECB/PKCS5Padding";
	
	private static String algo ="AES";

	private static byte[] key = { 0x2d, 0x2a, 0x2d, 0x42, 0x55, 0x49, 0x4c, 0x44, 0x41, 0x43, 0x4f, 0x44, 0x45, 0x2d,
			0x2a, 0x2d };

	/*public Key generateKey() throws Exception {
		Key key = new SecretKeySpec(key, algo);
	}*/
	
	public static String encrypt(String plainText) {
		try {
			Cipher cipher = Cipher.getInstance(algo);
			SecretKeySpec secretKey = new SecretKeySpec(key, algo);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			byte[] cipherText = cipher.doFinal(plainText.getBytes("UTF8"));
			String encryptedString = new String(Base64.getEncoder().encode(cipherText), "UTF-8");
			return encryptedString;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String decrypt(String encryptedText) {
		try {
			Cipher cipher = Cipher.getInstance(algo);
			SecretKeySpec secretKey = new SecretKeySpec(key, algo);
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			byte[] cipherText = Base64.getDecoder().decode(encryptedText.getBytes("UTF8"));
			String decryptedString = new String(cipher.doFinal(cipherText), "UTF-8");
			return decryptedString;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
	public static void main(String[] args) { 
	 /*
		  String filePath = "src\\main\\resources\\SecurityKeys.properties";
		  File keyFile = new File(filePath);
		  
		  AesEncryptionKeyGeneration encryption = new AesEncryptionKeyGeneration();*/
		
		  String filePath = "src\\main\\resources\\SecurityKeys.properties";
		  File keyFile = new File(filePath);
		AesEncryption encryption = new AesEncryption();
		
		 String encrypted;
		 String decrypted;
		 
		try {
			encrypted = encryption.encrypt("password@123", keyFile);
			 System.out.println("Encrypted String : " + encrypted);
			 
			 decrypted = encryption.decrypt(encrypted, keyFile);
			 System.out.println("Decrypted String : " + decrypted);
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	 
	  }
	 
}
