package com.daas.core.dao.project;

import java.util.List;

import com.daas.core.model.project.ProjectMaster;

/**
 * This interface contains the abstract methods to get the Data Acquisition Project Relationship
 * related information to the database and retrieve the information from the
 * database.
 * 
 * @author snatti
 */
public interface DataAcquisitionProjectDao {
	

    /**
     * Returns the Project and System information corresponding to the
     * project.
     * 
     * @param projectId
     *          
     * @return Project and Source information  corresponding to project.
     */
	public ProjectMaster fetchProjectInformation(Integer projectId);
	
	/**
     * Method to fetch ProjectMaster entities.
     * 
     * @param userId
     *            
     *            
     * @return list of ProjectMaster of user.
     */
	public List<ProjectMaster> fetchProjects(Integer userId);
	 
	/**
     * Method to update Project stage information.
     * 
     * @param projectMaster
     *          
     */
	public void update(ProjectMaster projectMaster);

}
