package com.daas.core.service.define;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.model.define.DbSchemaInfo;
import com.daas.core.model.define.DbSourceNameInfo;
import com.daas.core.model.define.Sources;

/**
 * This interface is the service class for Data Acquisition Define module which consumes the
 * JSON data from the rest call and returns the response in the form of JSON.
 * 
 * @author snatti
 */

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface DataAcquisitionDefineService {
	
	
	/**
	 *  Entry point method to get All Sources related to the System
	 * @param systemId
	 * 
	 * @return  List<DbSourceNameInfo>  with all the Sources related to the selected System
	 */
	@GET
	@Path("/getSourceInfo/{systemId}")
	public List<DbSourceNameInfo> getSourceInformation(@PathParam("systemId")Integer systemId);
	
	
	/**
	 *  Entry point method to get All Source related Shcemas and Its Attribute Information
	 * @param systemId
	 * @param sourceId
	 * 
	 * @return  List<Sources>  with all the Source related Shcemas and Its Attribute Information
	 */
	@GET
	@Path("/getSchemaInfo/{systemId}/{sourceId}/{frequency}")
	public List<Sources> getSchemaInformation(@PathParam("systemId")Integer systemId,@PathParam("sourceId")Integer sourceId,@PathParam("frequency")String frequency);
	
	
	/**
	 *  Entry point method to be fetch GuId by calling Ab Initio Rest Service 
	 * @param dbMetadata
	 * 
	 * @return AbResponseData with GuId information.
	 *//*
	@POST
	@Path("/getMetadata")
	public AbResponseData getMetadata(@RequestBody DbMetadata dbMetadata);*/
	
	
	
	 /**
     * Entry point method to save/submit the project information of a user.
     * 
     * @param projectSourceInfo
     *            ProjectSourceInfo to save the information to DB.
     */
	@POST
	@Path("/save")
	public void saveSchemaInformation(@RequestBody DbSchemaInfo dbSchemaInfo);
}
