package com.daas.core.service.identify;

import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.businesss.identify.DataAcquisitionIdentifyBusinessService;
import com.daas.core.dao.identify.DataAcquisitionIdentifyDao;
import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.model.identify.DataAcquisitionCriteria;
import com.daas.core.model.identify.DataAcquisitionInfo;
import com.daas.core.model.identify.DataAcquisitionRequest;
import com.daas.core.model.temp.SourceDetails;

/**
 * This class provides the implementation for DataAcquisitionIdentifyService methods to invoke
 * the corresponding business methods of DataAcquisitionBusinessService interface.
 * 
 * @author snatti
 */

@Path("/identify/")
@Service
public class DataAcquisitionIdentifyServiceImpl implements DataAcquisitionIdentifyService {
	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionIdentifyServiceImpl.class);
	

    /**
     * Autowired businessService implementation class to perform business
     * validations and to access DAO layer.
     */
	@Autowired
	DataAcquisitionIdentifyBusinessService dataAcquisitionBusinessService;
	@Autowired
	DataAcquisitionIdentifyDao dao;
	

	/**
	 *	Method to be used to validate user login and return
	 * 	drop down information from EIM extract 
	 *  @param dataAcquisitionInfo
	 *  
	 *  @return List of  DataAcquisitionCriteria with List of all drop down information.
	 */
	@Override
	public DataAcquisitionCriteria getSearchInformation() {
		logger.info("Enter DataAcquisitionIdentifyServiceImpl getSearchInformation");
		DataAcquisitionCriteria dataAcquisitionCriteria = this.dataAcquisitionBusinessService.getSearchInformation();
		logger.info("Exit DataAcquisitionIdentifyServiceImpl getSearchInformation");
		return dataAcquisitionCriteria;
	}

	/**
	 *  Method to be search based on the filter criteria 
	 * @param dataAcquisitionInfo
	 * 
	 * @return List of  DataAcquisitionInfo with all the grid data information.
	 */
	
	@Override
	public List<DataAcquisitionInfo> search(DataAcquisitionInfo dataAcquisitionInfoRequest) {
		logger.info("Enter DataAcquisitionIdentifyServiceImpl search");
		List<DataAcquisitionInfo> dataAcquisitionInfo = this.dataAcquisitionBusinessService.search(dataAcquisitionInfoRequest);
		logger.info("Exit DataAcquisitionIdentifyServiceImpl search");
		return dataAcquisitionInfo;
	}
	

	/**
	 * Method to be used to fetch Application Information 
	 * 
	 * @param appInstId
	 * 
	 * @return DataAcquisition object
	 */
	@Override
	public DataAcquisition getApplicationInformation(Integer appInstId) {
		logger.info("Enter DataAcquisitionIdentifyServiceImpl getApplicationInformation");
		DataAcquisition dataAcquisition = this.dataAcquisitionBusinessService.getApplicationInformation(appInstId);
		logger.info("Exit DataAcquisitionIdentifyServiceImpl getApplicationInformation");
		return dataAcquisition;
	}
	/**
     * Method to  save/submit the data acquisition request information.
     * 
     * @param dataAcquisitionRequestInfo
     *            list of DataAcquisitionRequest to save the information to DB.
     * 
     * @return dataAcquisitionBatchRequestId
     */ 
 	@Override
	public Integer saveAcquisitionRequest(List<DataAcquisitionRequest> dataAcquisitionRequestInfo) {
 		logger.info("Enter DataAcquisitionIdentifyServiceImpl saveAcquisitionRequest");
 		Integer dataAcquisitionBatchRequestId = this.dataAcquisitionBusinessService.saveAcquisitionRequest(dataAcquisitionRequestInfo);
		logger.info("Exit DataAcquisitionIdentifyServiceImpl saveAcquisitionRequest");
		return dataAcquisitionBatchRequestId;
	}
	
 	/**
     * Method to update the application details.
     * 
     * @param dataAcquisition
     *               
     */
	public void updateApplicationInformation(DataAcquisition dataAcquisition){
		logger.info("Enter DataAcquisitionIdentifyServiceImpl updateApplicationInformation");
		this.dataAcquisitionBusinessService.updateApplicationInformation(dataAcquisition);
		logger.info("Exit DataAcquisitionIdentifyServiceImpl updateApplicationInformation");
	}
	//****************************************************************************************************************************************************************//
	@Override
	public void create(DataAcquisitionRequest request) {
		logger.info("Enter DataAcquisitionServiceImpl save");
		this.dataAcquisitionBusinessService.create(request);
		logger.info("Exit DataAcquisitionServiceImpl save");
	}

	@Override
	public List<DataAcquisitionRequest> trackRequest(String requestedUser, String requestType) {
		List<DataAcquisitionRequest> dataAcquisitionRequest = this.dataAcquisitionBusinessService.trackRequest(requestedUser,requestType);
		return dataAcquisitionRequest;
	}

	@Override
	public List<DataAcquisitionRequest> getRequestDetails(Integer acquisitionReqId) {
		List<DataAcquisitionRequest> dataAcquisitionRequest = this.dataAcquisitionBusinessService.getRequestDetails(acquisitionReqId);
		return dataAcquisitionRequest;
	}

	@Override
	public void updateBulk(List<DataAcquisitionRequest> request) {
		this.dataAcquisitionBusinessService.updateBulk(request);
	
	}

	/*@Override
	public void update(DataAcquisitionRequest request) {
		this.dataAcquisitionBusinessService.update(request);
		
	}*/

	@Override
	public SourceDetails getSourceDetails(String sourcename) {
		SourceDetails sourceDetails = this.dao.getSourceDetails(sourcename);
		return sourceDetails;
	}
}
