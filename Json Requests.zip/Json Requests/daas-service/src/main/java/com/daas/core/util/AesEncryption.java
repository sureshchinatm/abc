package com.daas.core.util;



import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Base64;
import java.util.Scanner;
import java.util.Arrays; // #NL - new class to help with padding

import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.SecretKeySpec;

/**
 *      This class given peforms AES-128 bit Encryption in Java. We first initialize a 16 character (128 bit) secret key for the encryption.
 *      The below class needs Java version 8 or above because there was no Base64 encoder in older java versions
 *      and you had to use some external libraries.
 *
 * @author snatti
 */
public class AesEncryption {

        private static final String ALGORITHM = "AES"; // #NL - small typo change
        private static final String CIPHER_TYPE = "AES/ECB/NoPadding"; // #NL - represents the specific cipher mechanism

        private static final int KEYSZ = 128;// 128 default; 192 and 256 also possible

        /**
         * Encrypt a value and generate a keyfile.
         * If the keyfile is not found, then a new one will be created.
         *
         * @throws GeneralSecurityException
         * @throws IOException if an I/O error occurs
         */
        public static String encrypt(String value, File keyFile) throws GeneralSecurityException, IOException {

            String encryptedString = null;
            try {

                byte[] plainTextByte = value.getBytes();  // #NL - pad to 16 bytes

                // pad to multiple of 16 bytes
                int padLength = 16 - (plainTextByte.length % 16); 
                int totalLength = plainTextByte.length + padLength; 
                byte[] paddedPlainTextByte = new byte[totalLength]; 
                Arrays.fill( paddedPlainTextByte, (byte)0 );
                for( int i=0; i<plainTextByte.length; i++ )
                    paddedPlainTextByte[i] = plainTextByte[i]; 

                SecretKeySpec secretKey = getSecretKeySpec(keyFile);
                Cipher cipher = Cipher.getInstance(CIPHER_TYPE); // #NL - use specific cipher type
                cipher.init(Cipher.ENCRYPT_MODE, secretKey, cipher.getParameters());
                byte[] cipherText = cipher.doFinal(paddedPlainTextByte); // #NL - use padded value instead of original
                encryptedString = new String(Base64.getEncoder().encode(cipherText), "UTF-8");
            } catch (IllegalBlockSizeException ex) {
                throw new AssertionError(ex);
            }
            return encryptedString;
        }

        /**
         * Decrypt a value.
         *
         * @throws GeneralSecurityException
         * @throws IOException if an I/O error occurs
         */
        public static String decrypt(String encryptedText, File keyFile)
        throws GeneralSecurityException, IOException {

            SecretKeySpec secretKey = getSecretKeySpec(keyFile);
            Cipher cipher = Cipher.getInstance(CIPHER_TYPE); // #NL - use specific algorithm
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] cipherText = Base64.getDecoder().decode(encryptedText.getBytes("UTF8"));
            String decryptedString = new String(cipher.doFinal(cipherText), "UTF-8");
            return decryptedString;
        }

        private static SecretKeySpec getSecretKeySpec(File keyFile) throws IOException, GeneralSecurityException {

            byte[] key;
            SecretKeySpec sks = null;
            try {
                key = readKeyFile(keyFile);
                sks = new SecretKeySpec(key, ALGORITHM);// #NL - typo fix
            } catch (IllegalArgumentException | GeneralSecurityException e) {
                throw new GeneralSecurityException("Stored key is incorrect or corrupt.");
            }

            return sks;
        }

        private static byte[] readKeyFile(File keyFile) throws GeneralSecurityException {
            Scanner scanner = null;
            String keyValue = null;
            try {
                scanner = new Scanner(keyFile).useDelimiter("\\Z");
                keyValue = scanner.next();
                scanner.close();
            } catch (IOException ex) {
                throw new IllegalArgumentException("Unable to load " + keyFile, ex);
            } finally {
                if(scanner!=null){
                    scanner.close();
                }
            }
            return hexStringToByteArray(keyValue);
        }

        private static byte[] hexStringToByteArray(String s) {
            byte[] b = new byte[s.length() / 2];
            for (int i = 0; i < b.length; i++) {
                int index = i * 2;
                int v = Integer.parseInt(s.substring(index, index + 2), 16);
                b[i] = (byte) v;
            }
            return b;
        }
    }

    