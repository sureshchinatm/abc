package com.daas.core.model.temp;

public class ApplicationDataSource {
	
	
	private String lobId;
	private String application_name;
	private String source_name;
	private String table_name;
	private String column_name;
	public String getLobId() {
		return lobId;
	}
	public void setLobId(String lobId) {
		this.lobId = lobId;
	}
	public String getApplication_name() {
		return application_name;
	}
	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	public String getSource_name() {
		return source_name;
	}
	public void setSource_name(String source_name) {
		this.source_name = source_name;
	}
	public String getTable_name() {
		return table_name;
	}
	public void setTable_name(String table_name) {
		this.table_name = table_name;
	}
	public String getColumn_name() {
		return column_name;
	}
	public void setColumn_name(String column_name) {
		this.column_name = column_name;
	}
	@Override
	public String toString() {
		return "ApplicationDataSource [lobId=" + lobId + ", application_name=" + application_name + ", source_name="
				+ source_name + ", table_name=" + table_name + ", column_name=" + column_name + "]";
	}
	
	

}
