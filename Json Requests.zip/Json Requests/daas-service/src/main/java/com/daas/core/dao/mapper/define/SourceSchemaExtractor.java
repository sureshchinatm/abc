package com.daas.core.dao.mapper.define;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.define.Db2Source;
import com.daas.core.model.define.FlatFileSource;
import com.daas.core.model.define.OracleSource;
import com.daas.core.model.define.Sources;
import com.daas.core.util.SourceTypeEnum;
import com.google.gson.Gson;

public class SourceSchemaExtractor implements ResultSetExtractor<List<Sources>> {

	private Logger logger = LoggerFactory.getLogger(SourceSchemaExtractor.class);
	
	private int sourceId;
	
	public SourceSchemaExtractor(int sourceId) {
		super();
		this.sourceId=sourceId;
	}

	@Override
	public List<Sources> extractData(ResultSet rs) throws SQLException, DataAccessException {
		logger.info("Enter  SourceSchemaExtractor");
		logger.info("sourceId:::::::::"+sourceId);
		List<Sources> sourceSchemaList = new ArrayList<Sources>();
		Sources sourceDetails = null;
	//	SourceAttributeNameValue sourceAttributeNameValue = null;
		Gson gson = new Gson();
		OracleSource oracleSource = null;
		Db2Source db2Source = null;
		FlatFileSource flatFileSource =null;
		try {
			while (rs.next()) {
				sourceDetails = new Sources();
			//	sourceAttributeNameValue = new SourceAttributeNameValue();
				sourceDetails.setSource_schema_name(rs.getString("source_schema_name"));
				
				if("Oracle".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
					oracleSource = gson.fromJson(rs.getString("source_attribute_name_value"),OracleSource.class);
					sourceDetails.setOracleSource(oracleSource);
				}else if("DB2".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
					db2Source = gson.fromJson(rs.getString("source_attribute_name_value"),Db2Source.class);
					sourceDetails.setDb2Source(db2Source);
				}else if("FlatFile".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
					flatFileSource = gson.fromJson(rs.getString("source_attribute_name_value"),FlatFileSource.class);
					sourceDetails.setFlatFileSource(flatFileSource);
				}
				//sourceAttributeNameValue=	gson.fromJson(rs.getString("source_attribute_name_value"),SourceAttributeNameValue.class);
				//sourceDetails.setSource_attribute_name_value(sourceAttributeNameValue);
				sourceSchemaList.add(sourceDetails);
			}
			
		}catch (DataAccessException e) {
			logger.error(
					"Error in fetching Project Source Details , rolling back::::::: method fetchSystemInformation()");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
		return sourceSchemaList;
	}
}
