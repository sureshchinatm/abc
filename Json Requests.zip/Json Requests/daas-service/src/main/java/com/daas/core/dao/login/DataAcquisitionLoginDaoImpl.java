package com.daas.core.dao.login;



import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.daas.core.dao.mapper.login.LoginExtractor;
import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.login.User;
import com.daas.core.util.ErrorMessageConstants;

@Repository
public class DataAcquisitionLoginDaoImpl implements DataAcquisitionLoginDao{

	private Logger logger = LoggerFactory.getLogger(DataAcquisitionLoginDaoImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;	
	/*@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;*/
	
	public User findUserDetails(User user) {
		logger.info("Enter DataAcquisitionLoginDaoImpl getUserDetails");
		List<String> errorList;
		User userDetails = new User();
		String sql = "SELECT count(*) FROM users WHERE username = ? ";
		Object[] inputs = new Object[] { user.getUsername() };
		logger.info("loggedInUser:::::::::::" + user.getUsername());
		Integer count = this.jdbcTemplate.queryForObject(sql, inputs, Integer.class);
		logger.info("count:::::::::::" + count);

		if (count != 0) {
			// if user is valid fetch user role from user_role table
			userDetails = getUserDetails(user.getUsername());			
			
		}
		else {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.INVALID_USER);
			throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList, user.getUsername(),
					null);
		}
		
		logger.info("Exit DataAcquisitionLoginDaoImpl getUserDetails");
		return userDetails;
		
	}	
	
	private User getUserDetails(String username) {
		
		List<String> errorList;
		
		//User userDetails = new User();
		String sql = "select r.role, u.id from roles r , users u , user_role ur where r.id = ur.role_id  and ur.user_id = u.id and u.username =?";
	
		Object[] inputs = new Object[] { username };
		User userDetails = this.jdbcTemplate.query(sql,inputs, new LoginExtractor());
	
		if (userDetails != null ) {
			userDetails.setUsername(username);
			return userDetails;
		} else {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.USER_ROLE_NOT_EXIST);
			throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,username,null);
		}
	}
}
