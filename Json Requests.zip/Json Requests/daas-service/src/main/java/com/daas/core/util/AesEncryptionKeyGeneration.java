package com.daas.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Scanner;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 *	This class given peforms AES-128 bit Encryption in Java. We first initialize a 16 character (128 bit) secret key for the encryption.
 *	The below class needs Java version 8 or above because there was no Base64 encoder in older java versions
 *	and you had to use some external libraries. 
 * 
 * @author snatti
 */
public class AesEncryptionKeyGeneration {
	
	private static final String ALGORTIHM = "AES";
	private static final int KEYSZ = 128;// 128 default; 192 and 256 also possible
	
	/**
	 * Encrypt a value and generate a keyfile.
	 * If the keyfile is not found, then a new one will be created.
	 * 
	 * @throws GeneralSecurityException
	 * @throws IOException if an I/O error occurs
	 */
	public static String encrypt(String value, File keyFile)
	        throws GeneralSecurityException, IOException {
	    if (!keyFile.exists()) {
	        KeyGenerator keyGen = KeyGenerator.getInstance(ALGORTIHM);
	        keyGen.init(KEYSZ);
	        SecretKey sk = keyGen.generateKey();
	        FileWriter fw = new FileWriter(keyFile);
	        fw.write(byteArrayToHexString(sk.getEncoded()));
	        fw.flush();
	        fw.close();
	    }
	   	
	    SecretKeySpec secretKey = getSecretKeySpec(keyFile);
	    Cipher cipher = Cipher.getInstance(ALGORTIHM);
	    cipher.init(Cipher.ENCRYPT_MODE, secretKey, cipher.getParameters());
	    byte[] cipherText = cipher.doFinal(value.getBytes("UTF8"));
	    String encryptedString = new String(Base64.getEncoder().encode(cipherText), "UTF-8");
	    return encryptedString;
	   // return byteArrayToHexString(encrypted);
	}
	
	/**
	 * Decrypt a value.
	 * 
	 * @throws GeneralSecurityException
	 * @throws IOException if an I/O error occurs
	 */
	public static String decrypt(String encryptedText, File keyFile)
	        throws GeneralSecurityException, IOException {
		
		SecretKeySpec secretKey = getSecretKeySpec(keyFile);
	    Cipher cipher = Cipher.getInstance(ALGORTIHM);
	    cipher.init(Cipher.DECRYPT_MODE, secretKey);
	    //byte[] decrypted = cipher.doFinal(hexStringToByteArray(message));
	    byte[] cipherText = Base64.getDecoder().decode(encryptedText.getBytes("UTF8"));
		String decryptedString = new String(cipher.doFinal(cipherText), "UTF-8");
		
	    return decryptedString;
	}
	
	private static SecretKeySpec getSecretKeySpec(File keyFile)
	        throws NoSuchAlgorithmException, IOException {
	    byte[] key = readKeyFile(keyFile);
	    SecretKeySpec sks = new SecretKeySpec(key, ALGORTIHM);
	    return sks;
	}
	
	private static byte[] readKeyFile(File keyFile)
	        throws FileNotFoundException {
	    Scanner scanner = new Scanner(keyFile).useDelimiter("\\Z");
	    String keyValue = scanner.next();
	    scanner.close();
	    return hexStringToByteArray(keyValue);
	}
	
	private static String byteArrayToHexString(byte[] b) {
	    StringBuffer sb = new StringBuffer(b.length * 2);
	    for (int i = 0; i < b.length; i++) {
	        int v = b[i] & 0xff;
	        if (v < 16) {
	            sb.append('0');
	        }
	        sb.append(Integer.toHexString(v));
	    }
	    return sb.toString().toUpperCase();
	}
	
	private static byte[] hexStringToByteArray(String s) {
	    byte[] b = new byte[s.length() / 2];
	    for (int i = 0; i < b.length; i++) {
	        int index = i * 2;
	        int v = Integer.parseInt(s.substring(index, index + 2), 16);
	        b[i] = (byte) v;
	    }
	    return b;
	}
}

