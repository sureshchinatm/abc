package com.daas.core.dao.define;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.SCHEMA_ATTRIBUTE_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.SOURCE_NAME_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GET_APPLICATION_DETAILS_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.SCHEMA_ATTRIBUTE_REALTIME_SQL;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.daas.core.dao.mapper.define.RealTimeSchemaExtractor;
import com.daas.core.dao.mapper.define.SourceSchemaExtractor;
import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.define.DbSchemaInfo;
import com.daas.core.model.define.DbSourceNameInfo;
import com.daas.core.model.define.Sources;
import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.util.AesEncryption;
import com.daas.core.util.ErrorMessageConstants;
import com.daas.core.util.SourceTypeEnum;
import com.google.gson.Gson;

/**
 * This class provides the implementation methods for DataAcquisitionDefineDao.
 * 
 * @author snatti
 */

@Repository
public class DataAcquisitionDefineDaoImpl implements DataAcquisitionDefineDao{
	
	private Logger logger = LoggerFactory.getLogger(DataAcquisitionDefineDaoImpl.class);

		@Autowired
		JdbcTemplate jdbcTemplate;
		@Autowired
		NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	 /**
     * This method used to fetch Source Information from source_type table.
     */
	public List<DbSourceNameInfo> fetchSourceInformation(Integer systemId) {
		logger.info("Enter DataAcquisitionDefineDaoImpl fetchSourceInformation");
		List<DbSourceNameInfo> dbSourceNameInfo = null;
		List<String> errorList;
	 
		try {
			SqlParameterSource namedParameters = new MapSqlParameterSource("app_inst_id", systemId);
			dbSourceNameInfo = this.namedParameterJdbcTemplate.query(SOURCE_NAME_SQL, namedParameters,
					new BeanPropertyRowMapper<DbSourceNameInfo>(DbSourceNameInfo.class));

			if (dbSourceNameInfo == null) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.NO_SOURCE_INFO_FOUND_WITH_SYSTEM_ID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(),errorList, null,null);
			}

		}catch (DataAccessException e) {
			logger.error("Error in fetching Source Type Details , rolling back::::::: method fetchSourceInformation() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_SOURCE_DETAILS_WITH_SYSTEM_ID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionDefineDaoImpl fetchSourceInformation");
		return dbSourceNameInfo;
	}

	
	 /**
     * This method used to fetch Schema Information from source_schema_details table.
     */
	public List<Sources> fetchSchemaInformation(Integer systemId, Integer sourceId,String frequency) {
		logger.info("Enter DataAcquisitionDefineDaoImpl fetchSchemaInformation");
		List<Sources> sourceSchemaInfo = new ArrayList<>();
		List<String> errorList;
	 
		try {
			SqlParameterSource namedParameters = new MapSqlParameterSource("app_inst_id", systemId)
				    .addValue("parent_source_id", sourceId);
			
		/*	SqlParameterSource namedParametersRealTime = new MapSqlParameterSource("app_inst_id", systemId)
				    .addValue("parent_source_id", 10);
			*/
			/*if("RealTime".equals(frequency)){
				
				sourceSchemaInfo = this.namedParameterJdbcTemplate.query(SCHEMA_ATTRIBUTE_SQL,
						namedParameters, new SourceSchemaExtractor(sourceId) {
						});
			

			
				
			}else{
				sourceSchemaInfo = this.namedParameterJdbcTemplate.query(SCHEMA_ATTRIBUTE_SQL,
						namedParameters, new SourceSchemaExtractor(sourceId) {
						});
			}*/
	
			sourceSchemaInfo = this.namedParameterJdbcTemplate.query(SCHEMA_ATTRIBUTE_SQL,
					namedParameters, new SourceSchemaExtractor(sourceId) {
					});
			
			if (sourceSchemaInfo == null) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.NO_SCHEMA_INFO_FOUND_WITH_SOURCE_ID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(),errorList, null,null);
			}

		}catch (DataAccessException e) {
			logger.error("Error in fetching Source Type Details , rolling back::::::: method fetchSourceInformation() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_SOURCE_DETAILS_WITH_SOURCE_ID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionDefineDaoImpl fetchSchemaInformation");
		return sourceSchemaInfo;
	}

	/**
	 * This method used to save data to project table.
	 */
	@Override
	public void save(DbSchemaInfo dbSchemaInfo) {
		
		List<String> errorList;

		logger.info("Enter DbSchemaInfo save ");

		try {

			List<Sources> sourceList = dbSchemaInfo.getSources();
			bulkUpdateIntoSourceSchemaDetails(dbSchemaInfo, sourceList);

		} catch (DataAccessException e) {
			errorList = new ArrayList<>();
			errorList.add("Error in creating saving Project Source Information with given dbSchemaInfo \n " + e);
			logger.error(ErrorMessageConstants.CREATE_FAILED_FOR_SOURCE_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, e);
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl save ");
	}
	
	public void bulkUpdateIntoSourceSchemaDetails(DbSchemaInfo dbSchemaInfo, List<Sources> sourceList) throws GeneralSecurityException, IOException {
		logger.info("Enter DataAcquisitionDaoImpl bulkUpdateIntoSourceSchemaDetails");
	
		Gson gson = new Gson();
		
		String jsonString = null;
		String dbPassword = null;
		
		
		Integer projectId = dbSchemaInfo.getProject_id();
		Integer appInstId = dbSchemaInfo.getApp_inst_id();
		
		Integer sourceId = null;
		
		String filePath = "src\\main\\resources\\SecurityKeys.properties";
		File keyFile = new File(filePath);

		logger.info("sourceList size:::::::" + sourceList.size());
		int counter = 0;

		for (int i = 0; i < sourceList.size(); i++) {

			Sources source = (Sources) sourceList.get(i);

			logger.info("schema Name::::::::" + source.getSource_schema_name());

			String sql = "select count(*) from source_schema_details where app_inst_id ='" + appInstId + "'"
					+ " and source_schema_name='" + source.getSource_schema_name() + "'";

			logger.info("sql::::::::" + sql);

			Integer count = this.jdbcTemplate.queryForObject(sql, Integer.class);
			logger.info("count:::::::::::" + count);
			
			sourceId = source.getParent_source_id();
			//encrypt the database password before saving 
			if("Oracle".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
				dbPassword = source.getOracleSource().getDatabasePassword();
				dbPassword = AesEncryption.encrypt(dbPassword, keyFile);
				source.getOracleSource().setDatabasePassword(dbPassword);
				jsonString = gson.toJson(source.getOracleSource());
			}else if("DB2".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
				dbPassword = source.getDb2Source().getDatabasePassword();
				dbPassword = AesEncryption.encrypt(dbPassword, keyFile);
				source.getDb2Source().setDatabasePassword(dbPassword);
				jsonString = gson.toJson(source.getDb2Source());
			}else if("FlatFile".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
				jsonString = gson.toJson(source.getFlatFileSource());
			}else if("Kafka".equals(SourceTypeEnum.getStringValueFromInt(sourceId))){
				jsonString = gson.toJson(source.getKafkaSource());
			}

		//	jsonString = gson.toJson(source.getSource_attribute_name_value());
		/*	logger.info("source.getSource_attribute_name_value():::::::::" + source.getSource_attribute_name_value());
			logger.info("source.getSource_attribute_name_value() GSON COnversion:::::::::"
					+ gson.toJson(source.getSource_attribute_name_value()));*/

			if (count > 0) {

				StringBuffer updateQuery = new StringBuffer(
						"update source_schema_details SET project_id='" + projectId + "'");
				updateQuery.append(" ,app_inst_id='" + appInstId + "'");
				updateQuery.append(" ,parent_source_id='" + source.getParent_source_id() + "'");
				updateQuery.append(" ,source_schema_name='" + source.getSource_schema_name() + "'");
				updateQuery.append(" ,source_attribute_name_value='" + jsonString + "'");
				updateQuery.append(" where app_inst_id='" + appInstId + "'");
				updateQuery.append(" and source_schema_name='" + source.getSource_schema_name() + "'");

				logger.info("SQL:::::::::::" + updateQuery.toString());

				this.jdbcTemplate.update(updateQuery.toString());
				updateQuery = null;
			} else {
				StringBuffer insertQuery = new StringBuffer(
						"INSERT INTO source_schema_details (project_id,app_inst_id,parent_source_id,source_schema_name,source_attribute_name_value)");
				insertQuery.append(" VALUES ('" + projectId + "'");
				insertQuery.append(" , '" + appInstId + "'");
				insertQuery.append(" , '" + source.getParent_source_id() + "'");
				insertQuery.append(" , '" + source.getSource_schema_name() + "'");
				insertQuery.append(" , '" + jsonString + "' )");

				logger.info("SQL:::::::::::" + insertQuery.toString());

				this.jdbcTemplate.update(insertQuery.toString());
				insertQuery = null;
			}
			counter++;
		}
		logger.info("counter::::::::" + counter);
		logger.info("Exit DataAcquisitionDaoImpl bulkUpdateIntoSourceSchemaDetails");
	}
}
