package com.daas.core.dao;

import java.util.List;

import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.model.identify.DataAcquisitionRequest;
import com.daas.core.model.temp.Employee;
import com.daas.core.model.temp.User;

public interface DaoOld {
	
//	public void insert(User usr);
	
	public Employee getEmployee(Integer id);
	
	 public void create(List<Employee> employee);
	
	public List<Employee> listEmployees();
	
	public void delete(Integer empid);
	 
	public void update(List<Employee> employee);
	
	 public void jsonCreate(String  empJson);

	 public List<DataAcquisition> getUserDetails(User user);
	 

	 public void createDataAcquisitionRequest(DataAcquisitionRequest request);
	/*public void deposit(Account fromAccount,Account toAccount,Double amount);
	public void withdraw(Account fromAccount,Account toAccount,Double amount) ;*/

}
