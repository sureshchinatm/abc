package com.daas.core.model.plan;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectSystemDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5389264466946514120L;

	
	private Integer project_id;
	private Integer app_inst_id;
   	private String justify;
	private Integer data_retention;
	private String frequency;
	private String application_name;
	private String ingestion_type;

	
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public String getJustify() {
		return justify;
	}
	public void setJustify(String justify) {
		this.justify = justify;
	}
	public Integer getData_retention() {
		return data_retention;
	}
	public void setData_retention(Integer data_retention) {
		this.data_retention = data_retention;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public Integer getApp_inst_id() {
		return app_inst_id;
	}
	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}
	public String getApplication_name() {
		return application_name;
	}
	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	public String getIngestion_type() {
		return ingestion_type;
	}
	public void setIngestion_type(String ingestion_type) {
		this.ingestion_type = ingestion_type;
	}
}
