package com.daas.core.dao.project;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.PROJECT_MASTER_FETCH_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.PROJECT_STAGE_UPDATE_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.PROJECT_SYSTEMS_FETCH_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.USER_PROJECT_MASTER_FETCH_SQL;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.daas.core.dao.mapper.project.ProjectMasterExtractor;
import com.daas.core.dao.mapper.project.SystemDetailsExtractor;
import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;
import com.daas.core.util.ErrorMessageConstants;

/**
 * This class provides the implementation methods for DataAcquisitionProjectDao.
 * 
 * @author snatti
 */

@Repository
public class DataAcquisitionProjectDaoImpl implements DataAcquisitionProjectDao{
	
	private Logger logger = LoggerFactory.getLogger(DataAcquisitionProjectDaoImpl.class);

		@Autowired
		JdbcTemplate jdbcTemplate;
		@Autowired
		NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	 /**
     * This method used to fetch project and source information from project table.
     */
	@Override
	public ProjectMaster fetchProjectInformation(Integer projectId) {
		logger.info("Enter DataAcquisitionProjectDaoImpl fetchProjectInformation");

		ProjectMaster projectSystemDetails = null;
		List<SystemDetails> systemDetails = null;
		List<String> errorList;

		try {
			SqlParameterSource projectNamedParameters = new MapSqlParameterSource("project_id", projectId);
			projectSystemDetails = this.namedParameterJdbcTemplate.query(PROJECT_MASTER_FETCH_SQL,
					projectNamedParameters, new ProjectMasterExtractor() {
					});


			if (projectSystemDetails == null) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.PROJECT_MASTER_DETAILS_NOT_FOUND_FOR_PROJECTID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null, null);
			}
			
		    logger.info("projectId:::::"+projectId);
		   // Integer projectId = projectSystemDetails.getProject_id();
			SqlParameterSource systemNamedParameters = new MapSqlParameterSource("project_id", projectId);

			systemDetails = this.namedParameterJdbcTemplate.query(PROJECT_SYSTEMS_FETCH_SQL, systemNamedParameters,
					new SystemDetailsExtractor() {
					});

			if (systemDetails == null || systemDetails.isEmpty()) {
				
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.PROJECT_SYSTEM_DETAILS_NOT_FOUND_FOR_PROJECTID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null, null);
			}

			if (systemDetails != null && systemDetails.size() > 0) {
				projectSystemDetails.setSystemDetails(systemDetails);
			}
		} catch (DataAccessException e) {
			logger.error("Error in fetching project Information , rolling back::::::: method fetchProjectInformation() \n" + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_PROJECTID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionProjectDaoImpl fetchProjectInformation");

		return projectSystemDetails;
	}
	
	/**
     * Method to fetch ProjectMaster entities.
     * 
     * @param userId
     *            
     *            
     * @return list of ProjectMaster of user.
     */
	public List<ProjectMaster> fetchProjects(Integer userId){
		
		logger.info("Enter DataAcquisitionProjectDaoImpl fetchProjects");

		List<ProjectMaster> projectDetails = null;
		List<String> errorList;

		try {
			SqlParameterSource namedParameters = new MapSqlParameterSource("user_id", userId);
			
			projectDetails = this.namedParameterJdbcTemplate.query(USER_PROJECT_MASTER_FETCH_SQL,
					namedParameters, new BeanPropertyRowMapper<ProjectMaster>(ProjectMaster.class));

			if (projectDetails == null || projectDetails.isEmpty()) {
				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.PROJECT_MASTER_DETAILS_NOT_FOUND_FOR_USERID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
			}
		} catch (DataAccessException e) {
			logger.error("Error in fetching System Information , rolling back::::::: method fetchProjects() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_USERID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionProjectDaoImpl fetchProjects");
		return projectDetails;
	}


	/**
    * This method used to update Project stage information on project_master table.
    */
	@Override
	public void update(ProjectMaster projectMasterRequest) {
		List<String> errorList;
		logger.info("Enter DataAcquisitionProjectDaoImpl update");

		try {
				SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(projectMasterRequest);
				int rows = this.namedParameterJdbcTemplate.update(PROJECT_STAGE_UPDATE_SQL, namedParameters);
				if (rows == 0) {
					errorList = new ArrayList<>();
					errorList.add(ErrorMessageConstants.PROJECT_MASTER_DETAILS_NOT_FOUND_FOR_PROJECTID);
					throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
				}
				
		} catch (DataAccessException e) {
			logger.error("Error in fetching System Information , rolling back::::::: method fetchProjects() \n " + e);
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.UPDATE_FAILED_FOR_PROJECTID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionProjectDaoImpl update");
	}
}
