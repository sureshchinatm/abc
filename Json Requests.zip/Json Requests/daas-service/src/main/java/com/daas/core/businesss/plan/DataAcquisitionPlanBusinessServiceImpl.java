package com.daas.core.businesss.plan;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.plan.DataAcquisitionPlanDao;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;

/**
 * This class provides implementation for DataAcquisitionPlanBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */

@Service
public class DataAcquisitionPlanBusinessServiceImpl implements DataAcquisitionPlanBusinessService{

	 
    /**
     * Logger object to log all the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionPlanBusinessServiceImpl.class);
    
    /**
     * Autowired DataAcquisitionPlanDao to perform CRUD operations.
     */
    @Autowired
    private DataAcquisitionPlanDao dataAcquisitionPlanDao;
	
    /**
     * Returns the system information from the database based on the dataAcquisitionBatchRequestId.
     * 
     * @param dataAcquisitionBatchRequestId
     *           
     * @return List of  SystemDetails matching the dataAcquisitionBatchRequestId.
     */
	@Override
	@Transactional(readOnly = true)
	public List<SystemDetails> getSystemInformation(Integer dataAcquisitionBatchRequestId) {
		logger.info("Enter DataAcquisitionPlanBusinessServiceImpl getSystemInformation");
		List<SystemDetails> systemDetails = this.dataAcquisitionPlanDao.fetchSystemInformation(dataAcquisitionBatchRequestId);
		logger.info("Exit DataAcquisitionPlanBusinessServiceImpl getSystemInformation");
		return systemDetails;
	}

	/**
     * Saves project and system information to the database.
     * 
     * @param projectMasterInfo 
     *            ProjectMaster and System Information to DB.
    */
	@Override
	@Transactional ( propagation = Propagation.REQUIRES_NEW,rollbackFor = { 
            DaasSystemException.class } ) 
	public ProjectMaster saveProjectInformation(ProjectMaster projectMasterInfo) {
		logger.info("Enter DataAcquisitionPlanBusinessServiceImpl saveProjectInformation");
		ProjectMaster projectMaster = this.dataAcquisitionPlanDao.save(projectMasterInfo);
		logger.info("Exit DataAcquisitionPlanBusinessServiceImpl saveProjectInformation");
		return projectMaster;
	}
}
