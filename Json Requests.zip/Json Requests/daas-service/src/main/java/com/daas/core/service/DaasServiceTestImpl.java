package com.daas.core.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.temp.Account;
import com.daas.core.model.temp.Employee;
import com.daas.core.model.temp.JsonModel;
import com.daas.core.model.temp.PlayerListType;
import com.daas.core.model.temp.PlayerType;

public class DaasServiceTestImpl {
    Map<Integer, Account> accounts = new HashMap<Integer, Account>();

	
/*	@Override
	public String getMessage() {
        String message = this.dataAcquisitionBusinessService.getMessage();

		return message;
	}
	
	@Override
	 public String getJsondata(@RequestBody JsonModel jsonModel){
		
		return "Successfully tested json exception message";
	}
	
	
	
	@Override
    public Account getAccount(Integer id) {
		logger.info("Enter getAccount");

		init();
	
        Account c = accounts.get(id);
        return c;
    }

	@Override
    public List<Account> getAllAccounts() {
		logger.info("Enter getAllAccounts");

		init();

        List<Account> accountList = new ArrayList<Account>();
        logger.info("AccountList size::::::::"+accounts.size());
        for (int i = 1; i <=accounts.size(); i++) {
    		logger.info("Enter getAllAccounts::::::"+accounts.get(i));

            accountList.add((Account) accounts.get(i));
        }
       
        return accountList;
    }
	
	public void init(){
		logger.info("Enter init");
		
         Account newAccount1 = new Account();
 
         newAccount1.setId(1);
 
         newAccount1.setName("Alvin Reyes");
 
         Account newAccount2 = new Account();
 
         newAccount2.setId(2);
 
         newAccount2.setName("Rachelle Ann de Guzman Reyes");
 
  
 
         accounts.put(1, newAccount1);
 
         accounts.put(2, newAccount2);
	}

	@Override
	public String createOrSaveNewPLayerInfo(PlayerType playerType) {
		//get the player information from formal arguments and inserts into database & return playerId (primary_key)
		return "Player information saved successfully with PLAYER_ID " + 238;
	}

	@Override
	public PlayerType getPlayerInfo(Integer playerId) {
		 // retrieve player based on the id supplied in the formal argument
		try{
			 	//PlayerType getplayer = new PlayerType();
				PlayerType getplayer = null;
		        getplayer.setPlayerId(playerId);
		        getplayer.setName("Allan Donald");
		        getplayer.setAge(47);
		        getplayer.setMatches(72);
		        return getplayer;
		}catch(Exception dae){
			 logger.error("Error occured while fetching playerInfo");
	            throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.getCode().toString(),
	                            dae, null);
		}
	}

	@Override
	public PlayerListType getAllPlayerInfo() {
		// create a object of type PlayerType which takes player objects in its list
        PlayerListType playerListType = new PlayerListType();
 
        // player 1 info
        PlayerType playerOne = new PlayerType();
        playerOne.setPlayerId(237);
        playerOne.setName("Hansie Cronje");
        playerOne.setAge(33);
        playerOne.setMatches(68);
        playerListType.getPlayerType().add(playerOne); // add to playerListType
 
        // player 2 info
        PlayerType playerTwo = new PlayerType();
        playerTwo.setPlayerId(265);
        playerTwo.setName("Lance Klusener");
        playerTwo.setAge(42);
        playerTwo.setMatches(49);
        playerListType.getPlayerType().add(playerTwo); // add to playerListType
 
        return playerListType;
	}

	@Override
	public Employee getEmployee(Integer employeeId) {
		Employee employee = this.dataAcquisitionBusinessService.getEmployee(employeeId);
		
		return employee;
	}

	@Override
	public void create(Employee employee) {
		
		this.dataAcquisitionBusinessService.create(employee);
	}

	@Override
	public void jsonCreate(String employeeJson) {
		
		this.dao.jsonCreate(employeeJson);
	}
	
	@Override
	public List<Employee> listEmployees() {
		List<Employee> employeeList =	this.dataAcquisitionBusinessService.listEmployees();

		return employeeList;
	}

	@Override
	public void delete(Integer employeeId) {
		this.dataAcquisitionBusinessService.delete(employeeId);
		
	}

	@Override
	public void update(Employee employee) {
		this.dataAcquisitionBusinessService.update(employee);
		
	}*/

}
