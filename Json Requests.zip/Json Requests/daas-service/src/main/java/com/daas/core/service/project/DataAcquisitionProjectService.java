package com.daas.core.service.project;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.model.project.ProjectMaster;

/**
 * This interface is the service class for Data Acquisition Project which consumes the
 * JSON data from the rest call and returns the response in the form of JSON.
 * 
 * @author snatti
 */

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface DataAcquisitionProjectService {
	
	
	/**
	 *  Entry point method to fetch Project and System Information
	 * @param projectId
	 * 
	 * @return ProjectMaster with all the project and its system information.
	 */
	@GET
	@Path("/getProjectInfo/{projectId}")
	public ProjectMaster getProjectInformation(@PathParam("projectId")Integer projectId);

	
	/**
	 *  Entry point method to fetch all Projects Information 
	 * @param userId
	 * 
	 * @return List of ProjectMaster with all the Projects grid data information.
	 */
	@GET
	@Path("/getProjects/{userId}")
	public List<ProjectMaster> getProjects(@PathParam("userId")Integer userId);
	
	/**
	 *  Entry point method to update Project Stage information
	 *  
	 * @param projectMaster
	 *  
    */
	@POST
	@Path("/update")
	public void updateProjectStage(@RequestBody ProjectMaster projectMaster);
}
