package com.daas.core.dao.identify;

import java.util.List;

import com.daas.core.model.identify.DataAcquisition;
import com.daas.core.model.identify.DataAcquisitionCriteria;
import com.daas.core.model.identify.DataAcquisitionInfo;
import com.daas.core.model.identify.DataAcquisitionRequest;
import com.daas.core.model.temp.SourceDetails;


/**
 * This interface contains the abstract methods to get the DataAcquisition Identify Relationship
 * related information to the database and retrieve the information from the
 * database.
 * 
 * @author snatti
 */
public interface DataAcquisitionIdentifyDao {

	
	public DataAcquisitionCriteria fetchSearchInformation();


    /**
     * Returns the list of DataAcquisitionInfo entities.
     * 
     * @param dataAcquisitionInfo
     *            DataAcquisitionInfo entity
     *            
     * @return list of DataAcquisitionInfo search data
     */
	public List<DataAcquisitionInfo> getSearchCriteria(DataAcquisitionInfo dataAcquisitionInfo);
	
	
	 /**
     * Returns the application information from the database based on the appInstId.
     * 
     * @param appInstId
     *            
     *            
     * @return DataAcquisition dataAcquisition entity
     */
	public DataAcquisition fetchApplicationInformation(Integer appInstId);
	
	/**
     * Method to save the data acquisition request information to the database.
     * 
     * @param dataAcquisitionRequestInfo
     *            List<DataAcquisitionRequest> information to save into data acquisition request table
     *            
     *@return dataAcquisitionBatchRequestId
     */
	public Integer save(List<DataAcquisitionRequest> dataAcquisitionRequestInfo);
	
	/**
     * Method to update the data acquisition application information to the database.
     * 
     * @param dataAcquisition
     *          
     */
	public void update (DataAcquisition dataAcquisition);
		
	//*******************************************************************************************************//
	
	public void createDataAcquisitionRequest(DataAcquisitionRequest request);

	public List<DataAcquisitionRequest> getRequestedUserDetails(String requestedUser, String requestType);
	
	public List<DataAcquisitionRequest> getAcquisitionRequestDetails(Integer acquisitionReqId);
	
	public void updateBulk(List<DataAcquisitionRequest> request);
	
	public void update(DataAcquisitionRequest request);
	
	public SourceDetails getSourceDetails(String sourcename);


}
