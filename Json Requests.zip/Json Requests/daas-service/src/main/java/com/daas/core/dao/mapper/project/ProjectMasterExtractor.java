package com.daas.core.dao.mapper.project;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.project.ProjectMaster;

public class ProjectMasterExtractor implements ResultSetExtractor<ProjectMaster> {

	private Logger logger = LoggerFactory.getLogger(ProjectMasterExtractor.class);

	@Override
	public ProjectMaster extractData(ResultSet rs) throws SQLException, DataAccessException {
		ProjectMaster projectMasterInfo = null;
		try {
			while (rs.next()) {
				projectMasterInfo = new ProjectMaster();
				projectMasterInfo.setProject_id(Integer.parseInt(rs.getString("project_id")));
				projectMasterInfo.setProject_name(rs.getString("project_name"));
				projectMasterInfo.setDescription(rs.getString("description"));
				projectMasterInfo.setPurpose(rs.getString("purpose"));
				projectMasterInfo.setClarity_code(Integer.parseInt(rs.getString("clarity_code")));
				projectMasterInfo.setKey_contacts(rs.getString("key_contacts"));
				projectMasterInfo.setEstimated_hours(Integer.parseInt(rs.getString("estimated_hours")));
				projectMasterInfo.setStage(rs.getString("stage"));
				projectMasterInfo.setUser_id(Integer.parseInt(rs.getString("user_id")));
				projectMasterInfo.setStamp_created(rs.getTimestamp("stamp_created").toString());
			}
		}catch (DataAccessException e) {
			logger.error(
					"Error in fetching Project Source Details , rolling back::::::: method fetchProjectInformation()");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
		return projectMasterInfo;
	}
}
