package com.daas.core.model.govern;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Govern implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3573883392482952720L;
	
	private Integer project_id ;
	private Integer app_inst_id;
	private Integer data_clinic_approval_id ;
    private String status ;
	private String approved_by ;
    private String approver_type ;
    private String comments;
	private String stamp_created ;
	private String stamp_updated ;
	
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public Integer getData_clinic_approval_id() {
		return data_clinic_approval_id;
	}
	public void setData_clinic_approval_id(Integer data_clinic_approval_id) {
		this.data_clinic_approval_id = data_clinic_approval_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getApproved_by() {
		return approved_by;
	}
	public void setApproved_by(String approved_by) {
		this.approved_by = approved_by;
	}
	public String getApprover_type() {
		return approver_type;
	}
	public void setApprover_type(String approver_type) {
		this.approver_type = approver_type;
	}
	public String getStamp_created() {
		return stamp_created;
	}
	public void setStamp_created(String stamp_created) {
		this.stamp_created = stamp_created;
	}
	public String getStamp_updated() {
		return stamp_updated;
	}
	public void setStamp_updated(String stamp_updated) {
		this.stamp_updated = stamp_updated;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getApp_inst_id() {
		return app_inst_id;
	}
	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}
}
