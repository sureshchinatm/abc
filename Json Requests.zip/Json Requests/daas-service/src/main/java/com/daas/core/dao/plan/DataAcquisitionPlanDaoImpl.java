package com.daas.core.dao.plan;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GENERATE_DATA_CLINIC_APPROVAL_ID;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GOVERN_INSERT_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.PROJECT_MASTER_SAVE_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.SYSTEM_DETAILS_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.UPDATE_PROJECT_MASTER_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.UPDATE_PROJECT_SYSTEM_DETAILS_SQL;
import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.PROJECT_SYSTEM_SAVE_SQL;
import static com.daas.core.util.DaasConstants.GOVERN_COUNTER;
import static com.daas.core.util.DaasConstants.GOVERN_PENDING_STATUS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.govern.Govern;
import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;
import com.daas.core.util.ApproverType;
import com.daas.core.util.ErrorMessageConstants;

/**
 * This class provides the implementation methods for DataAcquisitionPlanDao.
 * 
 * @author snatti
 */

@Repository
public class DataAcquisitionPlanDaoImpl implements DataAcquisitionPlanDao{
	
	private Logger logger = LoggerFactory.getLogger(DataAcquisitionPlanDaoImpl.class);

		@Autowired
		JdbcTemplate jdbcTemplate;
		@Autowired
		NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	 /**
     * This method used to fetch system information from data_acquisition_request table.
     */
	@Override
	public List<SystemDetails> fetchSystemInformation(Integer dataAcquisitionBatchRequestId) {
		logger.info("Enter DataAcquisitionPlanDaoImpl fetchSystemInformation");
		List<SystemDetails> systemDetails = null;
		List<String> errorList;
		try {
			
			SqlParameterSource namedParameters =new MapSqlParameterSource("dataAcquisitionBatchRequestId", dataAcquisitionBatchRequestId);
			systemDetails = this.namedParameterJdbcTemplate.query(SYSTEM_DETAILS_SQL,namedParameters,
					new BeanPropertyRowMapper<SystemDetails>(SystemDetails.class));

			if (systemDetails == null || systemDetails.isEmpty()) {

				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.SYSTEM_DETAILS_NOT_FOUND_FOR_REQUESTID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(),errorList, null,
						null);
			}
		} catch (DataAccessException e) {
			errorList = new ArrayList<>();
			logger.error(
					"Error in fetching System Information , rolling back::::::: method fetchSystemInformation() \n " + e);
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_REQUESTID);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,  null, null);
		}

		logger.info("Exit DataAcquisitionPlanDaoImpl fetchSystemInformation");
		return systemDetails;
	}
	
	/**
	 * This method used to save or update data  into to project , project_system_details table.
	 * This method inserts data into govern table, creates dataclinicapprovalId.
	 */
	@Override
	public ProjectMaster save(ProjectMaster projectSystemInfoMaster) {

		logger.info("Enter DataAcquisitionPlanDaoImpl save ");
		List<SystemDetails> systemDetailsLst = null;
		Integer projectId = 0;
		Integer projectSystemId = 0;
		 List<String> errorList;
		try {
			
			
			/* 
			 * Step 1 : First check ,if project Id is present in the Request Object 
			 * 			If present update existing project table else insert into project table 
			 * Step 2 : 
			 */
			logger.info("projectSystemInfoMaster:::"+projectSystemInfoMaster.getProject_id());
			projectId = projectSystemInfoMaster.getProject_id();
			
			if(projectId!=null){
				updateProject(projectSystemInfoMaster);
			}else{
				projectId = createProject(projectSystemInfoMaster);
			}
			//set the generated / existing projectId back to the request object
			projectSystemInfoMaster.setProject_id(projectId);
			

			systemDetailsLst = projectSystemInfoMaster.getSystemDetails();
			if(systemDetailsLst!=null && systemDetailsLst.size()>0){
				for(int i=0;i<systemDetailsLst.size();i++){
					SystemDetails systemDetails = (SystemDetails) systemDetailsLst.get(i);
					
					logger.info("project_system_id::::::::" +systemDetails.getProject_system_id());
					
					projectSystemId = systemDetails.getProject_system_id();
					
					if(projectSystemId!=null){
						updateProjectSystem(systemDetails);
					}else{
						projectSystemId = createProjectSystem(systemDetails,projectId);
					}
					systemDetails.setProject_system_id(projectSystemId);
				}
			}
			
			if("Y".equalsIgnoreCase(projectSystemInfoMaster.getGovernIndicator())){
				createGovern(systemDetailsLst,projectId);
			}
			
		} catch (DataAccessException e) {
			
			logger.error("Error in creating saving Project Source Information, rolling back \n " + e);
			 errorList = new ArrayList<>();
	         errorList.add(ErrorMessageConstants.SAVE_FAILED_FOR_PROJECT_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList, null,e);
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl save ");
		return projectSystemInfoMaster;
	}
	
	public Integer createProject(ProjectMaster projectSystemInfoMaster){
		logger.info("Enter DataAcquisitionPlanDaoImpl createProject");
		Integer projId = 0;
		KeyHolder keyHolder = new GeneratedKeyHolder();
		List<String> errorList;
		try{
			int row = this.jdbcTemplate.update(new PreparedStatementCreator() {
			    @Override
			    public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			        PreparedStatement statement = con.prepareStatement(PROJECT_MASTER_SAVE_SQL, Statement.RETURN_GENERATED_KEYS);
			        statement.setString(1, projectSystemInfoMaster.getProject_name());
			        statement.setString(2, projectSystemInfoMaster.getDescription());
			        statement.setString(3, projectSystemInfoMaster.getPurpose());
			        statement.setInt(4, projectSystemInfoMaster.getClarity_code());
			        statement.setString(5, projectSystemInfoMaster.getKey_contacts());
			        statement.setInt(6, projectSystemInfoMaster.getEstimated_hours());
			        statement.setString(7, projectSystemInfoMaster.getStage());
			        statement.setInt(8, projectSystemInfoMaster.getUser_id());

			        return statement;
			    }
			}, keyHolder);

			logger.info("row:::::"+row);

			if (row > 0) {
				projId = keyHolder.getKey().intValue();
			}
			
			logger.info("projectId:::::"+projId);
			
		}catch (DataAccessException e) {
			logger.error("Error in creating Project, rolling back \n + e");
			errorList = new ArrayList<>();			
			errorList.add(ErrorMessageConstants.SAVE_FAILED_FOR_PROJECT_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,null, null);
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl createProject");
		return projId;
	}
	
	public void updateProject(ProjectMaster projectSystemInfoMaster){
		logger.info("Enter DataAcquisitionPlanDaoImpl updateProject");
		List<String> errorList;
		try{
			
			SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(projectSystemInfoMaster);
			this.namedParameterJdbcTemplate.update(UPDATE_PROJECT_MASTER_SQL, namedParameters);
		}catch (DataAccessException e) {
			logger.error("Error in Updating Project Master, rolling back \n " + e);
			errorList = new ArrayList<>();			
			errorList.add(ErrorMessageConstants.UPDATE_FAILED_FOR_PROJECT_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,null, null);
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl updateProject");
	}
	
	public Integer createProjectSystem(SystemDetails systemDetails, Integer projectId){
		logger.info("Enter DataAcquisitionPlanDaoImpl createProjectSystem");
		Integer projSysId = 0;
		KeyHolder keyHolder = new GeneratedKeyHolder();
		List<String> errorList;
	
		try{
			int row = this.jdbcTemplate.update(new PreparedStatementCreator() {
			    @Override
			    public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			        PreparedStatement statement = con.prepareStatement(PROJECT_SYSTEM_SAVE_SQL, Statement.RETURN_GENERATED_KEYS);
			        statement.setInt(1, systemDetails.getApp_inst_id());
			        statement.setInt(2, projectId);
			        statement.setString(3, systemDetails.getJustify());
			        statement.setInt(4, systemDetails.getData_retention());
			        statement.setString(5, systemDetails.getFrequency());
			        statement.setString(6, systemDetails.getApplication_name());
			        statement.setString(7, systemDetails.getIngestion_type());
			       

			        return statement;
			    }
			}, keyHolder);

			logger.info("row:::::"+row);

			if (row > 0) {
				projSysId = keyHolder.getKey().intValue();
			}
			
			logger.info("projectId:::::"+projSysId);
			
		}catch (DataAccessException e) {
			logger.error("Error in creating Project, rolling back \n " + e);
			errorList = new ArrayList<>();			
			errorList.add(ErrorMessageConstants.SAVE_FAILED_FOR_PROJECT__SYSTEM_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl createProjectSystem");
		return projSysId;
	}
	
	public void updateProjectSystem(SystemDetails systemDetails){
		logger.info("Enter DataAcquisitionPlanDaoImpl updateProjectSystem");
		List<String> errorList;
		try{
			
			SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(systemDetails);
			this.namedParameterJdbcTemplate.update(UPDATE_PROJECT_SYSTEM_DETAILS_SQL, namedParameters);
		}catch (DataAccessException e) {
			logger.error("Error in Updating Project System Details, rolling back \n " + e);
			errorList = new ArrayList<>();			
			errorList.add(ErrorMessageConstants.UPDATE_FAILED_FOR_PROJECT_SYSTEM_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl updateProjectSystem");
		
	}
	public void createGovern(List<SystemDetails> systemDetailsLst,Integer projectId){
		logger.info("Enter DataAcquisitionPlanDaoImpl createGovern");
		List<String> errorList;
		try{
			
			//insert into govern table
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			List<Govern> governList = new ArrayList<>();
			Govern governInfo = null;
			
			Integer data_clinic_approval_id = createDataClinicApprovalId();
			
			logger.info("data_clinic_approval_id::::::::"+data_clinic_approval_id);
			for(int i=0;i<systemDetailsLst.size();i++){
				SystemDetails systemDetails = (SystemDetails) systemDetailsLst.get(i);
				logger.info("app_inst_id:::::::"+systemDetails.getApp_inst_id());
				for(int j=0;j<GOVERN_COUNTER;j++ ){
					governInfo = new Govern();
					governInfo.setProject_id(projectId);
					governInfo.setApp_inst_id(systemDetails.getApp_inst_id());
					governInfo.setData_clinic_approval_id(data_clinic_approval_id);
					governInfo.setStatus(GOVERN_PENDING_STATUS);
					governInfo.setApprover_type(ApproverType.getStringValueFromInt(j));
					governInfo.setStamp_created(timestamp.toString());
					governInfo.setStamp_updated(timestamp.toString());
					governList.add(governInfo);
				}
			}
		
			int[] governCount =  bulkInsertIntoGovern(governList) ;
			if (!(governCount.length != 0)) {
				logger.error(
						"Error in creating Govern  Details , rolling back :::: methodName bulkInsertIntoGovern()");
				errorList = new ArrayList<>();			
				errorList.add(ErrorMessageConstants.SAVE_FAILED_FOR_GOVERN_INFO);
				throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,null, null);
			}
		}catch (DataAccessException e) {
			logger.error("Error in creating Govern, rolling back \n " + e);
			errorList = new ArrayList<>();			
			errorList.add(ErrorMessageConstants.SAVE_FAILED_FOR_GOVERN_INFO);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(),errorList,null, null);
		}
		logger.info("Exit DataAcquisitionPlanDaoImpl createGovern");
	}
	
	public int[] bulkInsertIntoProjectSystemDetails(List<SystemDetails> systemDetailsLst, Integer projectId) {
		logger.info("Enter DataAcquisitionPlanDaoImpl bulkInsertIntoProjectSystemDetails");

		//SqlParameterSource namedParameters =new MapSqlParameterSource("project_id", projectId);

		final String PROJECT_SYSTEM_SAVE_SQL = "INSERT INTO project_system_details (project_id,app_inst_id,"
				+ "justify,data_retention,frequency,application_name,ingestion_type)"
				+ " VALUES ("+projectId+",:app_inst_id,"
				+ ":justify,:data_retention,:frequency,:application_name,:ingestion_type)";
		
		
		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(systemDetailsLst.toArray());
		
		int[] insertCounts = this.namedParameterJdbcTemplate.batchUpdate(PROJECT_SYSTEM_SAVE_SQL, batch);
		logger.info("Exit DataAcquisitionPlanDaoImpl bulkInsertIntoProjectSystemDetails");
		return insertCounts;
	}
	
	public int[] bulkInsertIntoGovern(List<Govern> governInfo) {
		logger.info("Enter DataAcquisitionPlanDaoImpl bulkInsertIntoGovern");

		SqlParameterSource[] batch = SqlParameterSourceUtils.createBatch(governInfo.toArray());
		
		int[] insertCounts = this.namedParameterJdbcTemplate.batchUpdate(GOVERN_INSERT_SQL, batch);
		
		logger.info("Exit DataAcquisitionPlanDaoImpl bulkInsertIntoGovern");
		return insertCounts;
	}
	
	private Integer createDataClinicApprovalId() {
		logger.info("Enter DataAcquisitionIdentifyDaoImpl createDataClinicApprovalId");

		KeyHolder keyHolder = new GeneratedKeyHolder();

		Integer dataClinicApprovalId = 0;

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		int row = this.jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement statement = con.prepareStatement(GENERATE_DATA_CLINIC_APPROVAL_ID, Statement.RETURN_GENERATED_KEYS);
				statement.setString(1, timestamp.toString());

				return statement;
			}
		}, keyHolder);

		logger.info("row:::::" + row);

		if (row > 0) {
			dataClinicApprovalId = keyHolder.getKey().intValue();
		}
		logger.info("dataClinicApprovalId:::::: " + dataClinicApprovalId);
		logger.info("Exit DataAcquisitionIdentifyDaoImpl createDataClinicApprovalId");

		return dataClinicApprovalId;
	}
}
