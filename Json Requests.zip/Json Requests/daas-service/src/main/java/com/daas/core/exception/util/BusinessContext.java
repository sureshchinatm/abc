package com.daas.core.exception.util;

import java.util.HashMap;

/**
 * This class is used to store the parameters used in the context.
 * 
 * @author snatti
 */
public class BusinessContext extends HashMap<String, Object> {
    
    private static final long serialVersionUID = 1L;
}
