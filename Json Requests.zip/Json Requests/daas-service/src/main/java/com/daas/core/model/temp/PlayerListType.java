package com.daas.core.model.temp;

import java.util.ArrayList;
import java.util.List;

public class PlayerListType {
	 
    protected List<PlayerType> playerType;
    public List<PlayerType> getPlayerType() {
        if (playerType == null) {
            playerType = new ArrayList<PlayerType>();
        }
        return this.playerType;
    }
}