package com.daas.core.dao.define;

import java.util.List;

import com.daas.core.model.define.DbSchemaInfo;
import com.daas.core.model.define.DbSourceNameInfo;
import com.daas.core.model.define.Sources;

/**
 * This interface contains the abstract methods to get the Data Acquisition Define Relationship
 * related information to the database and retrieve the information from the
 * database.
 * 
 * @author snatti
 */
public interface DataAcquisitionDefineDao {
	
	 /**
     * Returns the Source Information corresponding to the
     * systemName.
     * 
     * @param systemId
     *          
     * @return List of Source Information  corresponding to systemId.
     */
	public List<DbSourceNameInfo> fetchSourceInformation(Integer systemId);
	
	 /**
     * Returns the Schema Information corresponding to the
     * system and source.
     * 
     * @param sourceName
     *          
     * @return List of Schema Information  corresponding to system and source.
     */
	public List<Sources> fetchSchemaInformation(Integer systemId,Integer sourceId,String frequency);
	

	 /**
     * Saves the Project and Source information to the database 
     * 
     * @param projectSourceInfo
     *            ProjectSourceInfo to be saved to the DB
     */
	public void save(DbSchemaInfo dbSchemaInfo);

}
