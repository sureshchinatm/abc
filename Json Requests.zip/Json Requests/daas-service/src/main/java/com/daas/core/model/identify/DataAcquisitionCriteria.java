package com.daas.core.model.identify;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DataAcquisitionCriteria implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2622797240133366421L;
	
	private List<String> dataGroups;
	private List<String> applicationNames;
	private List<String> lobs;
	private List<String> regions;
	
	public List<String> getDataGroups() {
		return dataGroups;
	}
	public void setDataGroups(List<String> dataGroups) {
		this.dataGroups = dataGroups;
	}
	public List<String> getApplicationNames() {
		return applicationNames;
	}
	public void setApplicationNames(List<String> applicationNames) {
		this.applicationNames = applicationNames;
	}
	public List<String> getLobs() {
		return lobs;
	}
	public void setLobs(List<String> lobs) {
		this.lobs = lobs;
	}
	public List<String> getRegions() {
		return regions;
	}
	public void setRegions(List<String> regions) {
		this.regions = regions;
	}
}
