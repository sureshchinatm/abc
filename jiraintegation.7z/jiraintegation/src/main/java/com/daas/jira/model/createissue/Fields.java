package com.daas.jira.model.createissue;

public class Fields {
	 private Project project;
	    private String summary;
	    private String description;
	    private Issuetype issuetype;
	    private Assignee assignee;
	    private Reporter reporter;
	    private Priority priority;
	    public void setProject(Project project) {
	         this.project = project;
	     }
	     public Project getProject() {
	         return project;
	     }

	    public void setSummary(String summary) {
	         this.summary = summary;
	     }
	     public String getSummary() {
	         return summary;
	     }

	    public void setDescription(String description) {
	         this.description = description;
	     }
	     public String getDescription() {
	         return description;
	     }

	    public void setIssuetype(Issuetype issuetype) {
	         this.issuetype = issuetype;
	     }
	     public Issuetype getIssuetype() {
	         return issuetype;
	     }

	    public void setAssignee(Assignee assignee) {
	         this.assignee = assignee;
	     }
	     public Assignee getAssignee() {
	         return assignee;
	     }

	    public void setReporter(Reporter reporter) {
	         this.reporter = reporter;
	     }
	     public Reporter getReporter() {
	         return reporter;
	     }

	    public void setPriority(Priority priority) {
	         this.priority = priority;
	     }
	     public Priority getPriority() {
	         return priority;
	     }
}
