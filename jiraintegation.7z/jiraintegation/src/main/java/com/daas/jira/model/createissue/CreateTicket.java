package com.daas.jira.model.createissue;

import org.springframework.beans.factory.annotation.Autowired;

public class CreateTicket {
	
	@Autowired
	private Fields fields;

	public Fields getFields() {
		return fields;
	}

	public void setFields(Fields fields) {
		this.fields = fields;
	}
	

}
