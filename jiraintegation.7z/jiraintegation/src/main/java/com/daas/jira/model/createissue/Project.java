package com.daas.jira.model.createissue;

public class Project {

	   private String key;
	    public void setKey(String key) {
	         this.key = key;
	     }
	     public String getKey() {
	         return key;
	     }

}
