package com.daas.jira.service;

import javax.ws.rs.Path;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.daas.jira.model.createissue.CreateOutputTicket;
import com.daas.jira.model.createissue.CreateTicket;





@Path("/jira/")
@Service
public class CreateJiraTicketServiceImpl implements CreateJiraTicketService{

	
	@Override
	public CreateOutputTicket fetchIssueId(CreateTicket createTicket) {

		System.out.println("entering into fetchIssue iD");
		String plainCreds = "sureshc69:Myjira@9";
		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);
		
		HttpEntity<CreateTicket> request = new HttpEntity<CreateTicket>(createTicket,headers);
		
		RestTemplate restTemplate = new RestTemplate();
		final String endPoint = "http://10.109.8.149:8088/rest/api/2/issue/";
				
		CreateOutputTicket response = null;
		
		
		
		ResponseEntity<CreateOutputTicket> responseEntity = restTemplate.postForEntity(endPoint, request, CreateOutputTicket.class);
	     
		response = responseEntity.getBody();
		
		
		return response;
	
	}

	@Override
	public String hello() {

		System.out.println("entering into JIRA TEST");
		return "JIRA TEST";
	}

}
