package com.daas.jira.config;

import java.util.Arrays;
import java.util.LinkedList;

import javax.ws.rs.Path;

import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.lifecycle.ResourceProvider;
import org.apache.cxf.jaxrs.spring.SpringResourceFactory;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;


import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

/**
 * This class is java based configuration of jaxrs services and auto discovery
 * 
 * @author snatti
 * 
 */
@Configuration
@ComponentScan("com.daas.jira.config")
@ImportResource("classpath:META-INF/cxf/cxf.xml")
public class CxfConfig {

	@Autowired
	private ApplicationContext ctx;
   /* @Autowired
    private DaasExceptionMapper daasExcepMapper;
    @Autowired
    private JsonMappingExceptionMapper jsonMappingExceMapper;
    @Autowired
    private GlobalExceptionMapper globalExceptionMapper;*/

	/**
	 * 
	 * @return SpringBus
	 */
	@Bean(destroyMethod = "shutdown")
	public SpringBus cxf() {
		return new SpringBus();
	}

	

    @Bean
    public ServletRegistrationBean cxfServletRegistrationBean(){
    	System.out.println("regsistration bean");
        ServletRegistrationBean registrationBean = new ServletRegistrationBean(new CXFServlet(), "/dataacquisition/*");
        registrationBean.setAsyncSupported(true);
        registrationBean.setLoadOnStartup(1);
        registrationBean.setName("CXFServlet");
        return registrationBean;
    }
	
	/**
	 * 
	 * @return JAXRSServerFactoryBean
	 */
	@Bean
	public Server jaxRsServer() {
		System.out.println("jaxrs server bean");
		LinkedList<ResourceProvider> resourceProviders = new LinkedList<>();
		for (String beanName : this.ctx.getBeanDefinitionNames()) {
			if (this.ctx.findAnnotationOnBean(beanName, Path.class) != null) {
				SpringResourceFactory factory = new SpringResourceFactory(beanName);
				factory.setApplicationContext(this.ctx);
				resourceProviders.add(factory);
			}
		}

		JAXRSServerFactoryBean factory = new JAXRSServerFactoryBean();
		factory.setBus(this.ctx.getBean(SpringBus.class));
		// factory.setInInterceptors();
		//factory.setProviders(Arrays.asList(this.jsonProvider()));
		 factory.setProviders(Arrays.asList(this.jsonProvider()));
		factory.setResourceProviders(resourceProviders);
		factory.setAddress("/");
		return factory.create();
	}

	/**
	 * The jsonProvider() will return JacksonJsonProvider which will be used for
	 * actual data binding of java pojo's into json format.
	 * 
	 * @return JacksonJsonProvider
	 */
	@Bean
	public JacksonJsonProvider jsonProvider() {
		System.out.println("creating request");
		return new JacksonJsonProvider();
	}
}
