package com.daas.jira;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.daas.jira.model.createissue.CreateTicket;
import com.daas.jira.service.CreateJiraTicketService;

@RunWith(SpringRunner.class)
// @SpringBootTest
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class JiraintegationApplicationTests {

	@Autowired
	private CreateJiraTicketService createJiraTicketService;

	@Autowired
	private RestTemplate restTemplate;

	/*@Test
	public void createClient() {
		ResponseEntity<Client> responseEntity = restTemplate.postForEntity("/clients", new CreateClientRequest("Foo"),
				Client.class);
		Client client = responseEntity.getBody();

		assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
		assertEquals("Foo", client.getName());
	}*/

	@Test
	public void testFetchIssueId() {
		CreateTicket createTicket = 
		createJiraTicketService.fetchIssueId(createTicket);
	}
	
}
