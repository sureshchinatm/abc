package com.daas.core.dao.mapper.login;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.login.User;

public class LoginExtractor implements ResultSetExtractor<User> {
	
	private Logger logger = LoggerFactory.getLogger(LoginExtractor.class);

	@Override
	public User extractData(ResultSet rs) throws SQLException, DataAccessException {
		User userDetails = null;
		try {
			while (rs.next()) {
				userDetails = new User();
				userDetails.setRoleName(rs.getString("role"));
				userDetails.setUser_id(Integer.parseInt(rs.getString("id")));
			}			

		}catch (DataAccessException e) {
			logger.error(
					"Error in fetching Source Type Details , rolling back::::::: method getUserDetails()");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
		return userDetails;
	}
}
