package com.daas.core.businesss.project;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.project.DataAcquisitionProjectDao;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.model.project.ProjectMaster;

/**
 * This class provides implementation for DataAcquisitionProjectBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */

@Service
public class DataAcquisitionProjectBusinessServiceImpl implements DataAcquisitionProjectBusinessService{

	 
    /**
     * Logger object to log all the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionProjectBusinessServiceImpl.class);
    
    /**
     * Autowired DataAcquisitionProjectDao to perform CRUD operations.
     */
    @Autowired
    private DataAcquisitionProjectDao dataAcquisitionProjectDao;
	
    /**
     * Returns the Project and System information from the database based on the projectId.
     * 
     * @param projectId
     *           
     * @return ProjectMaster projectSystemDetails matching the projectId.
     */
	@Override
	@Transactional(readOnly = true)
	public ProjectMaster getProjectInformation(Integer projectId) {
		logger.info("Enter DataAcquisitionProjectBusinessServiceImpl getProjectInformation");
		ProjectMaster projectSystemDetails = this.dataAcquisitionProjectDao.fetchProjectInformation(projectId);
		logger.info("Exit DataAcquisitionProjectBusinessServiceImpl getProjectInformation");
		return projectSystemDetails;
	}

	 /**
     * Returns the search information from the database based on the search criteria.
     * 
     * @param userId
     *           
     * @return List<ProjectMaster>  projectMaster  matching the user.
     */
	@Override
	@Transactional(readOnly = true)
	public List<ProjectMaster> getProjects(Integer userId) {
		logger.info("Enter DataAcquisitionProjectBusinessServiceImpl getProjects");
		List<ProjectMaster> projectsDetails = this.dataAcquisitionProjectDao.fetchProjects(userId);
		logger.info("Exit DataAcquisitionProjectBusinessServiceImpl getProjects");
		return projectsDetails;
	}

	 /**
     * Updates Project specific stage information.
     * 
     * @param projectMaster
     *           
     */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { 
            DaasSystemException.class }, isolation = Isolation.READ_COMMITTED)
	public void updateProjectStage(ProjectMaster projectMaster) {
		logger.info("Enter DataAcquisitionProjectBusinessServiceImpl updateProjectStage");
		this.dataAcquisitionProjectDao.update(projectMaster);
		logger.info("Exit DataAcquisitionProjectBusinessServiceImpl updateProjectStage");
	}
}
