package com.daas.core.businesss.prepare;

import java.util.List;

import com.daas.core.model.prepare.ScanDetails;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition prepare flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */
public interface DataAcquisitionPrepareBusinessService {
	
	 /**
     *  Returns Scanning Status Details Information from the database.
     * 
     * @param guId
     *          
     * @return  List of  ScanDetails that matches the
     *        		guId.
     */
	public List<ScanDetails> getScanInformation(Integer guId);

	 
}
