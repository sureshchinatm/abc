package com.daas.core.service.define;

import java.util.List;

import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.daas.core.businesss.define.DataAcquisitionDefineBusinessService;
import com.daas.core.model.define.AbResponseData;
import com.daas.core.model.define.DbMetadata;
import com.daas.core.model.define.DbSchemaInfo;
import com.daas.core.model.define.DbSourceNameInfo;
import com.daas.core.model.define.Sources;

/**
 * This class provides the implementation for DataAcquisitionDefineService methods to invoke
 * the corresponding business methods of DataAcquisitionDefineBusinessService interface.
 * 
 * @author snatti
 */

@Path("/define/")
@Service
public class DataAcquisitionDefineServiceImpl implements DataAcquisitionDefineService{
	
	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionDefineServiceImpl.class);
	

    /**
     * Autowired businessService implementation class to perform business
     * validations and to access DAO layer.
     */
	@Autowired
	DataAcquisitionDefineBusinessService dataAcquisitionDefineBusinessService;
		
	
	/**
	 *  Method to be fetch All Source Information for selected System
	 * @param systemId
	 * 
	 * @return List<DbSourceNameInfo>  with all the Sources related to the selected System.
	 */
	@Override
	public List<DbSourceNameInfo> getSourceInformation(Integer systemId) {
		logger.info("Enter DataAcquisitionDefineServiceImpl getSourceInformation");
		List<DbSourceNameInfo> dbSourceNameInfo = this.dataAcquisitionDefineBusinessService.getSourceInformation(systemId);
		logger.info("Exit DataAcquisitionDefineServiceImpl getSourceInformation");

		return dbSourceNameInfo;
	}
	
	 /**
     * Method to  save/submit the project information of a user.
     * 
     * @param projectSourceInfo
     *            ProjectSourceInfo to save the information to DB.
     */ 
	@Override
	public void saveSchemaInformation(DbSchemaInfo dbSchemaInfo) {
		logger.info("Enter DataAcquisitionDefineServiceImpl saveSchemaInformation");
		this.dataAcquisitionDefineBusinessService.saveSchemaInformation(dbSchemaInfo);
		logger.info("Exit DataAcquisitionDefineServiceImpl saveSchemaInformation");
	}


	@Override
	public AbResponseData getMetadata(DbMetadata dbMetadata) {
		
		RestTemplate restTemplate = new RestTemplate();
		final String endPoint = "http://ip-172-31-30-82.us-west-2.compute.internal/SourceSystem/RegisterNewSource/DB ";
				
		AbResponseData response = null;
		
		ResponseEntity<AbResponseData> responseEntity = restTemplate.postForEntity(endPoint, dbMetadata, AbResponseData.class);
	     
		response = responseEntity.getBody();
		
		
		return response;
	}

	/**
	 *  Method to get All Source related Schemas and Its Attribute Information
	 * @param systemId
	 * @param sourceId
	 * 
	 * @return  List of Sources  with all the Source related Schemas and Its Attribute Information.
	 */
	@Override
	public List<Sources> getSchemaInformation(Integer systemId,Integer sourceId) {
		logger.info("Enter DataAcquisitionDefineServiceImpl getSchemaInformation");
		List<Sources> sourceSchemaInfo = this.dataAcquisitionDefineBusinessService.getSchemaInformation(systemId,sourceId);
		logger.info("Exit DataAcquisitionDefineServiceImpl getSchemaInformation");

		return sourceSchemaInfo;
	}
}
