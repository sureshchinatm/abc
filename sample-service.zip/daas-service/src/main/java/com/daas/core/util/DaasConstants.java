package com.daas.core.util;

public class DaasConstants {
	
	public static final String USER_ROLE_REQUESTOR = "Requestor";
	public static final String USER_ROLE_APPROVER = "Approver";
	public static final String USER_ROLE_SOURCE_OWNER = "SourceOwner";
	public static final String USER_ROLE_ADMIN = "Admin";
	
	public static final Integer GOVERN_COUNTER =3;
	public static final String GOVERN_PENDING_STATUS = "Pending";
	public static final String GOVERN_APPROVED_STATUS = "Approved";
	public static final String GOVERN_REJECTED_STATUS = "Rejected";
	
	 /**
     * The below private constructor will avoid creating objects for this class
     * as all the members are static.
     */
	private DaasConstants(){
		// Empty private constructor used to avoid unnecessary creation of
        // objects
	}
}
