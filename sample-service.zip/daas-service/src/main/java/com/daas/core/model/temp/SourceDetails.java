package com.daas.core.model.temp;

import java.util.List;

public class SourceDetails {
	
	private String sourceName;
	private List<String> sourceValues;
	
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public List<String> getSourceValues() {
		return sourceValues;
	}
	public void setSourceValues(List<String> sourceValues) {
		this.sourceValues = sourceValues;
	}
}
