package com.daas.core.model.define;

import java.io.Serializable;

public class Scheduling implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8550919382359785119L;
	
	private String frequency;

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
}
