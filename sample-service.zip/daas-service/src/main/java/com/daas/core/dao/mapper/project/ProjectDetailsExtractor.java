package com.daas.core.dao.mapper.project;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.project.SystemDetails;

public class ProjectDetailsExtractor implements ResultSetExtractor<List<SystemDetails>> {

	private Logger logger = LoggerFactory.getLogger(ProjectMasterExtractor.class);

	@Override
	public List<SystemDetails> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<SystemDetails> systemDetailsLst = new ArrayList<SystemDetails>();
		SystemDetails systemDetails = null;
		try {
			while (rs.next()) {
				systemDetails = new SystemDetails();
				systemDetails.setApp_inst_id(Integer.parseInt(rs.getString("app_inst_id")));
			/*	systemDetails.setData_retention(Integer.parseInt(rs.getString("data_retention")));
				systemDetails.setFrequency(rs.getString("frequency"));
				systemDetails.setJustify(rs.getString("justify"));
				systemDetails.setSystem_name(rs.getString("system_name"));
				systemDetails.setApplication_name(rs.getString("application_name"));
				systemDetails.setIngestion_type(rs.getString("ingestion_type"));*/
				systemDetailsLst.add(systemDetails);
			}
		} catch (DataAccessException e) {
			logger.error(
					"Error in fetching Project Source Details , rolling back::::::: method fetchSystemInformation()");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
		return systemDetailsLst;
	}
}
