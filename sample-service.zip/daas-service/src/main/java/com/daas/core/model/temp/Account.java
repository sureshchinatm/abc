package com.daas.core.model.temp;

import java.io.Serializable;

public class Account implements Serializable{
		
	private static final long serialVersionUID = -7788619177798333712L;
	

		private Long accountNumber;
		private String accountType;
		private Double accountBalance;
		private String accountHolderName;
		
		public Long getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(Long accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public Double getAccountBalance() {
			return accountBalance;
		}
		public void setAccountBalance(Double accountBalance) {
			this.accountBalance = accountBalance;
		}
		public String getAccountHolderName() {
			return accountHolderName;
		}
		public void setAccountHolderName(String accountHolderName) {
			this.accountHolderName = accountHolderName;
		}
	
	

}
