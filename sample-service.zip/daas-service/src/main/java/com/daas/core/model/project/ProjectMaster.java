package com.daas.core.model.project;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5389264466946514120L;

	private Integer project_id;
	private String project_name;
	private String description;
	private String purpose;
	private Integer clarity_code;
	private String key_contacts;
	private Integer estimated_hours;
	private Integer user_id;
	private String stage;
	private String stamp_created;
	private String governIndicator;
	
	private List<SystemDetails> systemDetails;

	public Integer getProject_id() {
		return project_id;
	}

	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public Integer getClarity_code() {
		return clarity_code;
	}

	public void setClarity_code(Integer clarity_code) {
		this.clarity_code = clarity_code;
	}

	public String getKey_contacts() {
		return key_contacts;
	}

	public void setKey_contacts(String key_contacts) {
		this.key_contacts = key_contacts;
	}

	public Integer getEstimated_hours() {
		return estimated_hours;
	}

	public void setEstimated_hours(Integer estimated_hours) {
		this.estimated_hours = estimated_hours;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public List<SystemDetails> getSystemDetails() {
		return systemDetails;
	}

	public void setSystemDetails(List<SystemDetails> systemDetails) {
		this.systemDetails = systemDetails;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getStamp_created() {
		return stamp_created;
	}

	public void setStamp_created(String stamp_created) {
		this.stamp_created = stamp_created;
	}

	public String getGovernIndicator() {
		return governIndicator;
	}

	public void setGovernIndicator(String governIndicator) {
		this.governIndicator = governIndicator;
	}
}
