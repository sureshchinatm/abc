package com.daas.core.service.govern;

import java.util.List;

import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daas.core.businesss.govern.DataAcquisitionGovernBusinessService;
import com.daas.core.model.govern.Govern;
import com.daas.core.model.govern.GovernSourceDetails;

/**
 * This class provides the implementation for DataAcquisitionGovernService methods to invoke
 * the corresponding business methods of DataAcquisitionGovernBusinessService interface.
 * 
 * @author snatti
 */

@Path("/govern/")
@Service
public class DataAcquisitionGovernServiceImpl implements DataAcquisitionGovernService{
	
	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionGovernServiceImpl.class);
	

    /**
     * Autowired businessService implementation class to perform business
     * validations and to access DAO layer.
     */
	@Autowired
	DataAcquisitionGovernBusinessService dataAcquisitionGovernBusinessService;
	
	/**
	 *  Method to be fetch Govern Source Details for Approval Status
	 * @param 
	 * 
	 * @return List<GovernSourceDetails>  with all the Source Approval Details Information.
	 */
	@Override
	public List<GovernSourceDetails> getGovernSourceInformation() {
		logger.info("Enter DataAcquisitionGovernServiceImpl getGovernSourceInformation");
		List<GovernSourceDetails> governSourceInfo = this.dataAcquisitionGovernBusinessService.getGovernSourceInformation();
		logger.info("Exit DataAcquisitionGovernServiceImpl getGovernSourceInformation");

		return governSourceInfo;
	}
	
	
	/**
	 *  Method to be Approve/Reject Project status
	 *  
	 * @param governInfo
	 * 
	 * @return List of Govern status with all the status information for the selected projects.
	 */
	@Override
	public List<Govern> updateGovernStatus(List<Govern> governInfo){
		
		logger.info("Enter DataAcquisitionGovernServiceImpl updateGovernStatus");
		List<Govern> govern = this.dataAcquisitionGovernBusinessService.updateGovernStatus(governInfo);
		logger.info("Exit DataAcquisitionGovernServiceImpl updateGovernStatus");

		return govern;
		
	}
}
