package com.daas.core.businesss.login;


import com.daas.core.model.login.User;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition login flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */

public interface DataAcquisitionLoginBusinessService {

	 /**
     *  Returns User Information from the database.
     * 
     * @param User
     *          
     * @return  user details.
     */
	
	public User findUserDetails(User user);


}
