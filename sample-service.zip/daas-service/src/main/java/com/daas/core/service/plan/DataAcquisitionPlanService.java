package com.daas.core.service.plan;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.model.project.ProjectMaster;
import com.daas.core.model.project.SystemDetails;

/**
 * This interface is the service class for Data Acquisition Plan module which consumes the
 * JSON data from the rest call and returns the response in the form of JSON.
 * 
 * @author snatti
 */

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface DataAcquisitionPlanService {
	
	
	
	/**
	 *  Entry point method to fetch Submitted System Details
	 *  
	 * @param dataAcquisitionBatchRequestId
	 * 
	 * @return List<SystemDetails> with all the systems and its information. 
	 */
	@GET
	@Path("/getSystemInfo/{dataAcquisitionBatchRequestId}")
	public List<SystemDetails> getSystemInformation(@PathParam("dataAcquisitionBatchRequestId")Integer dataAcquisitionBatchRequestId);


	
	 /**
     * Entry point method to save/submit the project information of a user.
     * 
     * @param projectMasterInfo
     *            ProjectMaster to save the information to DB.
     */
	@POST
	@Path("/save")
	public ProjectMaster saveProjectInformation(@RequestBody ProjectMaster projectMasterInfo);
}
