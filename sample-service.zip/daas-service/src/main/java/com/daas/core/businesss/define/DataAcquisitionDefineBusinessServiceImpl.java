package com.daas.core.businesss.define;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.define.DataAcquisitionDefineDao;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.model.define.DbSchemaInfo;
import com.daas.core.model.define.DbSourceNameInfo;
import com.daas.core.model.define.Sources;

/**
 * This class provides implementation for DataAcquisitionDefineBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */

@Service
public class DataAcquisitionDefineBusinessServiceImpl implements DataAcquisitionDefineBusinessService{

	 
    /**
     * Logger object to log all the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionDefineBusinessServiceImpl.class);
    
    /**
     * Autowired DataAcquisitionPlanDao to perform CRUD operations.
     */
    @Autowired
    private DataAcquisitionDefineDao dataAcquisitionDefineDao;
	
   /**
     *  Method to fetch All Sources Related to the System.
     * 
     * @param systemId
     *           
     *  @return List of DbSourceNameInfo  with all the Sources related to the selected System.
     */
	@Override
	@Transactional(readOnly = true)
	public List<DbSourceNameInfo> getSourceInformation(Integer systemId){
		logger.info("Enter DataAcquisitionDefineBusinessServiceImpl getSourceInformation");
		List<DbSourceNameInfo>  dbSourceNameInfo = this.dataAcquisitionDefineDao.fetchSourceInformation(systemId);
		logger.info("Exit DataAcquisitionDefineBusinessServiceImpl getSourceInformation");

		return dbSourceNameInfo;
	}
	
	/**
    *  Method to get All Source related Schemas and Its Attribute Information.
    * 
    * @param systemId
    * @param sourceId
    *           
    *  @return  List of DbSchemaInfo  with all the Source related Schemas and Its Attribute Information.
    */
	@Override
	@Transactional(readOnly = true)
	public List<Sources> getSchemaInformation(Integer systemId,Integer sourceId) {
		logger.info("Enter DataAcquisitionDefineBusinessServiceImpl getSchemaInformation");
		List<Sources>  sourceSchemaInfo = this.dataAcquisitionDefineDao.fetchSchemaInformation(systemId,sourceId);
		logger.info("Exit DataAcquisitionDefineBusinessServiceImpl getSchemaInformation");

		return sourceSchemaInfo;
		
	}
	

	/**
     * Saves project and source information to the database.
     * 
     * @param projectSourceInfo 
     *            ProjectSourceInfo to save patient information to DB.
    */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { 
            DaasSystemException.class }, isolation = Isolation.READ_COMMITTED)
	public void saveSchemaInformation(DbSchemaInfo dbSchemaInfo) {
		logger.info("Enter DataAcquisitionDefineBusinessServiceImpl saveSchemaInformation");
		this.dataAcquisitionDefineDao.save(dbSchemaInfo);
		logger.info("Exit DataAcquisitionDefineBusinessServiceImpl saveSchemaInformation");
	}
}
