package com.daas.core.model.define;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Sources implements Serializable {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = -8970555409890256761L;
	
	private Integer parent_source_id;
	 private String source_schema_name;

	private SourceAttributeNameValue source_attribute_name_value;

	public Integer getParent_source_id() {
		return parent_source_id;
	}

	public void setParent_source_id(Integer parent_source_id) {
		this.parent_source_id = parent_source_id;
	}

	public String getSource_schema_name() {
		return source_schema_name;
	}

	public void setSource_schema_name(String source_schema_name) {
		this.source_schema_name = source_schema_name;
	}

	public SourceAttributeNameValue getSource_attribute_name_value() {
		return source_attribute_name_value;
	}

	public void setSource_attribute_name_value(SourceAttributeNameValue source_attribute_name_value) {
		this.source_attribute_name_value = source_attribute_name_value;
	}


}
