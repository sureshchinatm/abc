package com.daas.core.util;

public final class ErrorMessageConstants {

	
	 /**
     * The below private constructor will avoid creating objects for this class
     * as all the members are static.
     */
    private ErrorMessageConstants() {
        // Empty private constructor used to avoid unnecessary creation of
        // objects
    }
    public static final String PROJECT_MASTER_DETAILS_NOT_FOUND_FOR_PROJECTID = "Project Details Not Found For the submitted ProjectId";
    public static final String PROJECT_MASTER_DETAILS_NOT_FOUND_FOR_USERID = "Project Details Not Found For the submitted UserId";
    public static final String PROJECT_SYSTEM_DETAILS_NOT_FOUND_FOR_PROJECTID = "Project System Details Not Found For the submitted ProjectId";
    public static final String FETCH_FAILED_FOR_PROJECTID = "Error in fetching System Information for the projectId";
    public static final String UPDATE_FAILED_FOR_PROJECTID = "Error in Updating System Information for the projectId";
    public static final String FETCH_FAILED_FOR_USERID = "Error in fetching System Information for the UserId";
    public static final String SCAN_DETAILS_NOT_FOUND_FOR_GUID = "No Scan Details Found For the Submitted GuId";
    public static final String FETCH_FAILED_FOR_GUID = "Error in fetching Scan Details for the GuId";
    public static final String SYSTEM_DETAILS_NOT_FOUND_FOR_REQUESTID = "Systemdetails not found for the Request ID";
    public static final String FETCH_FAILED_FOR_REQUESTID = "Error in fetching System Information for the Request ID";
    public static final String SAVE_FAILED_FOR_PROJECT_INFO = "Error occured while creating the project with submitted Project Information";
    public static final String SAVE_FAILED_FOR_PROJECT__SYSTEM_INFO = "Error occured while creating the project system details with submitted Project Information";
    public static final String UPDATE_FAILED_FOR_PROJECT_INFO = "Error in Updating Project Information";
    public static final String UPDATE_FAILED_FOR_PROJECT_SYSTEM_INFO = "Error in Updating Project SystemInformation";
    public static final String SAVE_FAILED_FOR_GOVERN_INFO = "Error occured while creating the Govern  Details";
    public static final String INVALID_USER = "Invalid User Credentials";
    public static final String USER_ROLE_NOT_EXIST = "User Role Does Not Exist for the User";
    public static final String NO_DATA_FOUND = "No Data Exists";
    public static final String NO_DATA_FOUND_FOR_REQUEST = "No Data Exists with the submitted request";
    public static final String FETCH_FAILED_FOR_REQUEST = "Error in fetching information with given request";
    public static final String CREATE_FAILED_FOR_REQUEST = "Error in creating record with given request";
    public static final String SAVE_FAILED_FOR_REQUEST = "Error in saving record with given request";
    public static final String FETCH_FAILED_FOR_USER = "Error in fetching Request Details for the requestedUser";
    public static final String FETCH_FAILED_FOR_AQUISTIONID = "Error in fetching Acquisitiondetails for the given acquisitionId";
    public static final String UPDATE_FAILED_FOR_AQUISTIONID = "Error in updating record for the DataAcquisitionRequest";
    public static final String FETCH_FAILED_FOR_SOURCENAME = "Error in fetching Source Details for the sourceName";
    public static final String NO_GOVERN_DETAILS_WITH_APPROVAL = "No  Govern Source Details For Approval Found";
    public static final String FETCHING_FAILED_FOR_GOVERN = "Error in fetching System Information for govern";
    public static final String CREATE_FAILED_FOR_GOVERN = "Error in creating record with the given governInfo";
    public static final String GOVERN_STATUS_LIST_SIZE_ZERO = "GovernStatusList size is zero";
    public static final String NO_SOURCE_INFO_FOUND_WITH_SYSTEM_ID = "No Source Information Found For the Selected SystemId";
    public static final String FETCH_FAILED_FOR_SOURCE_DETAILS_WITH_SYSTEM_ID = "Error in fetching Source Type Details for the given system Id";
    public static final String NO_SCHEMA_INFO_FOUND_WITH_SOURCE_ID = "No Schema Information Found For the Selected Source";
    public static final String FETCH_FAILED_FOR_SOURCE_DETAILS_WITH_SOURCE_ID = "Error in fetching Source Type Details for the given systemId and sourceId";
    public static final String CREATE_FAILED_FOR_SOURCE_INFO = "Error in creating Project Source Information";
    
}
