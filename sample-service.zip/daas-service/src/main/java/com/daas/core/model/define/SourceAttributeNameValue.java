package com.daas.core.model.define;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceAttributeNameValue implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6851412274012364530L;
	
	 private String db_type;
	 private String db_server;
	 private String db_name;
	 private String db_schema;
	 private String db_user;
	 private String db_version;
	public String getDb_type() {
		return db_type;
	}
	public void setDb_type(String db_type) {
		this.db_type = db_type;
	}
	public String getDb_server() {
		return db_server;
	}
	public void setDb_server(String db_server) {
		this.db_server = db_server;
	}
	public String getDb_name() {
		return db_name;
	}
	public void setDb_name(String db_name) {
		this.db_name = db_name;
	}
	public String getDb_schema() {
		return db_schema;
	}
	public void setDb_schema(String db_schema) {
		this.db_schema = db_schema;
	}
	public String getDb_user() {
		return db_user;
	}
	public void setDb_user(String db_user) {
		this.db_user = db_user;
	}
	public String getDb_version() {
		return db_version;
	}
	public void setDb_version(String db_version) {
		this.db_version = db_version;
	}
	
	 
	 

}
