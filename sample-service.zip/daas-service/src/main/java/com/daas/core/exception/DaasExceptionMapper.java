package com.daas.core.exception;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.daas.core.exception.config.DaasBaseException;
import com.daas.core.exception.dto.ErrorDTO;
import com.daas.core.util.LoggerConstants;

/**
 * This is will be used to map the Daas customized exceptions and logs the Error
 * messages using the Error DTO object
 * 
 * @author snatti
 */
@Provider
public class DaasExceptionMapper implements ExceptionMapper<DaasBaseException> {
    
	private Logger logger=LoggerFactory.getLogger(DaasExceptionMapper.class);
                    
    /**
     * This method is used to handle Pharmacy Customized exception and it forms
     * an Error DTO depending on the Exception message passed.
     * 
     * @return {@code Response} Returns the Response which the Exception Error
     *         Message DTO
     */
   /* @Override
    public Response toResponse(DaasBaseException pharmcyBaseEx) {
        logger.error("PharmacyBaseException:", pharmcyBaseEx);
        Response.Status status = Response.Status.INTERNAL_SERVER_ERROR;
        ErrorDTO errorDTO = pharmcyBaseEx.getErrorDTO();
        errorDTO.setLoggedInUser(errorDTO.getLoggedInUser());
        errorDTO.setErrorDescription(errorDTO.getErrorCode());
        logger.debug("Error Code {}", pharmcyBaseEx.getErrorDTO().getErrorCode());
        return Response.status(status).entity(pharmcyBaseEx.getErrorDTO()).type(MediaType.APPLICATION_JSON).build();
    }  */
	
	   @Override
	    public Response toResponse(DaasBaseException pharmcyBaseEx) {
	    	logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, pharmcyBaseEx);
	    	 Response.Status status = Response.Status.INTERNAL_SERVER_ERROR;

	         ErrorDTO errorDTO = pharmcyBaseEx.getErrorDTO();
	         errorDTO.setLoggedInUser(errorDTO.getLoggedInUser());
	         errorDTO.setErrorDescription(errorDTO.getErrorCode());
			   System.out.println("333333333:::::"+errorDTO.getErrorCode().toString());

	         logger.debug("Error Code {}", pharmcyBaseEx.getErrorDTO().getErrorCode());
	         
	         if(!StringUtils.isEmpty(pharmcyBaseEx.getException())) {
				   System.out.println("444444444444"+pharmcyBaseEx.getException().getMessage());

		       errorDTO.getErrorCodeList().add(pharmcyBaseEx.getException().getMessage());
		         }
			   System.out.println("5555555555");

	        Throwable exceptionCauseMessage = pharmcyBaseEx.getCause();
	        if (exceptionCauseMessage != null && exceptionCauseMessage.getMessage() != null) {
				   System.out.println("66666666666");

	            errorDTO.getErrorCodeList().add(exceptionCauseMessage.getMessage());
	        }
	        logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, errorDTO.getErrorCode());
	        return Response.status(status).entity(errorDTO).type(MediaType.APPLICATION_JSON).build();
	    }
}
