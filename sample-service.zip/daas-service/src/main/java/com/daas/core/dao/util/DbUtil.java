package com.daas.core.dao.util;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.GET_USER_ROLE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.util.ErrorConstants;

public class DbUtil {
	
	private Logger logger = LoggerFactory.getLogger(DbUtil.class);
	
	
	public String getUserRole(JdbcTemplate jdbcTemplate,Integer userId) {
	
		Object[] inputs = new Object[] { userId };
		String rolename = jdbcTemplate.queryForObject(GET_USER_ROLE, inputs, String.class);
		logger.debug("rolename:::::::::::" + rolename);
		if (rolename != null) {
			return rolename;
		} else {
			throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), rolename,
					new Exception("User Role Does Not Exist"));
		}
	}

}
