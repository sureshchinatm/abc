package com.daas.core.service.identify;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.model.identify.DataAcquisitionCriteria;
import com.daas.core.model.identify.DataAcquisitionInfo;
import com.daas.core.model.identify.DataAcquisitionRequest;
import com.daas.core.model.temp.SourceDetails;
import com.daas.core.model.temp.User;



/**
 * This interface is the service class for Data Acquisition  Identify module which consumes the
 * JSON data from the rest call and returns the response in the form of JSON.
 * 
 * @author snatti
 */

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface DataAcquisitionIdentifyService {
	
	/**
	 * This is the method to be used to validate user login and return
	 * drop down information from EIM extract 
	 */
	@GET
	@Path("/getSearchInfo")
	public DataAcquisitionCriteria getSearchInformation();
	
	/**
	 *  Entry point method to be search based on the filter criteria 
	 * @param dataAcquisitionInfo
	 * 
	 * @return List of  DataAcquisitionInfo with all the grid data information.
	 */
	@POST
	@Path("/search")
	public List<DataAcquisitionInfo> search(@RequestBody DataAcquisitionInfo dataAcquisitionInfo);
	
	
	/**
     * Entry point method to save/submit the data acquisition request information.
     * 
     * @param dataAcquisitionRequestInfo
     *            list of DataAcquisitionRequest to save the information to DB.
     *    
     *@return  generated dataAcquisitionBatchRequestId
     */
	@POST
	@Path("/save")
	public Integer saveAcquisitionRequest(@RequestBody List<DataAcquisitionRequest> dataAcquisitionRequestInfo);
	
	//  ****************************************************************************************************************************************************//
	/**
	 * This is the method to be used to create a record in the Data Acquisition
	 * Request table.
	 */
	@POST
	@Path("/create")
	public void create(@RequestBody DataAcquisitionRequest request);

	/**
	 * This is the method to be used to track the request of the user a
	 * and return the user specific request information
	 */

	@GET
	@Path("/trackrequest/{requestedUser}/{requestType}")
	public List<DataAcquisitionRequest> trackRequest(@PathParam("requestedUser") String param1,
			@PathParam("requestType") String param2);
	
	/**
	 * This is the method to be used to get the request details of the user 
	 * based on the acquisitionReqId
	 */
	@GET
	@Path("/fetch/{acquisitionReqId}")
	public List<DataAcquisitionRequest> getRequestDetails(@PathParam("acquisitionReqId") Integer acquisitionReqId);
	

	/**
	 * This is the method to be used to create a record in the Data Acquisition
	 * Request table.
	 */
	@POST
	@Path("/updateBulk")
	public void updateBulk(@RequestBody List<DataAcquisitionRequest> request);
	
	/**
	 * This is the method to be used to create a record in the Data Acquisition
	 * Request table.
	 */
	@POST
	@Path("/update")
	public void update(@RequestBody DataAcquisitionRequest request);
	
	
	
	/**
	 * This is the method to be used to get the source details 
	 * based on the source name
	 */
	@GET
	@Path("/source/fetch/{sourcename}")
	public SourceDetails getSourceDetails(@PathParam("sourcename") String sourcename);
	
	
	
	
	
	/*      bulk update testtttttttttt  for employee tables  */
	
	/*  *//** 
		  * This is the method to be used to create
		  * a record in the Employee table.
		  *//*
		@POST
	    @Path("/employee/create")
		public void create(@RequestBody List<Employee> employee);
	 
	 
	 
	 *//** 
		  * This is the method to be used to update
		  * a record into the Employee table.
		  *//*
		@POST
	    @Path("/employee/update")
		public void update(@RequestBody List<Employee> employee);
		*/
	

}
