package com.daas.core.service.project;

import java.util.List;

import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daas.core.businesss.project.DataAcquisitionProjectBusinessService;
import com.daas.core.model.project.ProjectMaster;

/**
 * This class provides the implementation for DataAcquisitionProjectService methods to invoke
 * the corresponding business methods of DataAcquisitionProjectBusinessService interface.
 * 
 * @author snatti
 */

@Path("/project/")
@Service
public class DataAcquisitionProjectServiceImpl implements DataAcquisitionProjectService{
	
	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionProjectServiceImpl.class);
	

    /**
     * Autowired businessService implementation class to perform business
     * validations and to access DAO layer.
     */
	@Autowired
	DataAcquisitionProjectBusinessService dataAcquisitionProjectBusinessService;
	
	/**
	 *  Method to  fetch Project and System details 
	 * @param projectId
	 * 
	 * @return ProjectMaster with all the Project and System information.
	 */
	@Override
	public ProjectMaster getProjectInformation(Integer projectId) {
		logger.info("Enter DataAcquisitionProjectServiceImpl getProjectInformation");
		ProjectMaster projectSystemDetails = this.dataAcquisitionProjectBusinessService.getProjectInformation(projectId);
		logger.info("Exit DataAcquisitionProjectServiceImpl getProjectInformation");

		return projectSystemDetails;
	}
	
	/**
	 * Method to be fetch all the Projects of user
	 * 
	 * @param userId
	 * 
	 * @return List of ProjectMaster with all the Projects grid data information.
	 */
	@Override
	public List<ProjectMaster> getProjects(Integer userId) {
		logger.info("Enter DataAcquisitionProjectServiceImpl getProjects");
		List<ProjectMaster> projectsDetails = this.dataAcquisitionProjectBusinessService.getProjects(userId);
		logger.info("Exit DataAcquisitionProjectServiceImpl getProjects");
		return projectsDetails;
	}

	/**
	 * Method to update Project stage information
	 * 
	 * @param projectMaster
	 * 
	 */
	@Override
	public void updateProjectStage(ProjectMaster projectMaster) {
		logger.info("Enter DataAcquisitionProjectServiceImpl updateProjectStage");
		this.dataAcquisitionProjectBusinessService.updateProjectStage(projectMaster);
		logger.info("Exit DataAcquisitionProjectServiceImpl updateProjectStage");
	}
}
