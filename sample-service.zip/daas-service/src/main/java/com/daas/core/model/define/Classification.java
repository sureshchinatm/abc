package com.daas.core.model.define;

import java.io.Serializable;

public class Classification implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5300619114538156420L;

	private String line_of_business;
	private String application;
	private String region;

	public String getLine_of_business() {
		return line_of_business;
	}

	public void setLine_of_business(String line_of_business) {
		this.line_of_business = line_of_business;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

}
