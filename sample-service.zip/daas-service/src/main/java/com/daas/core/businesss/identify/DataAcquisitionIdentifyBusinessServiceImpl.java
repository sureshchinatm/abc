package com.daas.core.businesss.identify;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.identify.DataAcquisitionIdentifyDao;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.model.identify.DataAcquisitionCriteria;
import com.daas.core.model.identify.DataAcquisitionInfo;
import com.daas.core.model.identify.DataAcquisitionRequest;

/**
 * This class provides implementation for DataAcquisitionIdentifyBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */
@Service
public class DataAcquisitionIdentifyBusinessServiceImpl implements DataAcquisitionIdentifyBusinessService {

	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger = LoggerFactory.getLogger(DataAcquisitionIdentifyBusinessServiceImpl.class);

	 /**
     * Autowired DataAcquisitionDao to perform CRUD operations.
     */
	@Autowired
	private DataAcquisitionIdentifyDao daqDao;

	@Override
	@Transactional(readOnly = true)
	public DataAcquisitionCriteria getSearchInformation() {
		logger.info("Enter DataAcquisitionIdentifyBusinessService getSearchInformation");
		DataAcquisitionCriteria dataAcquisitionCriteria = this.daqDao.fetchSearchInformation();
		logger.info("Exit DataAcquisitionIdentifyBusinessService getSearchInformation");
		return dataAcquisitionCriteria;
	}
	
	 /**
     * Returns the search information from the database based on the search criteria.
     * 
     * @param dataAcquisitionInfoRequest
     *           
     * @return List<DataAcquisitionInfo>  dataAcquisitionInfo  matching the search criteria.
     */
	@Override
	@Transactional(readOnly = true)
	public List<DataAcquisitionInfo> search(DataAcquisitionInfo dataAcquisitionInfoRequest) {
		logger.info("Enter DataAcquisitionIdentifyBusinessService search");
		List<DataAcquisitionInfo> dataAcquisitionInfo = this.daqDao.getSearchCriteria(dataAcquisitionInfoRequest);
		logger.info("Exit DataAcquisitionIdentifyBusinessService search");
		return dataAcquisitionInfo;
	}
	
	/**
     * Saves Data Acquisition Request information to the database.
     * 
     * @param dataAcquisitionRequestInfo 
     *            List<DataAcquisitionRequest> to save acquisition request information to DB.
     *            
     *return  dataAcquisitionBatchRequestId      
    */
	@Override
	@Transactional ( propagation = Propagation.REQUIRES_NEW)
	public Integer saveAcquisitionRequest(List<DataAcquisitionRequest> dataAcquisitionRequestInfo) {
		logger.info("Enter DataAcquisitionIdentifyBusinessService saveAcquisitionRequest");
		Integer dataAcquisitionBatchRequestId = this.daqDao.save(dataAcquisitionRequestInfo);
		logger.info("Exit DataAcquisitionIdentifyBusinessService saveAcquisitionRequest");
		return dataAcquisitionBatchRequestId;
	}
	
	
	//***************************************************************************************************************************************************//
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { 
            DaasSystemException.class }, isolation = Isolation.READ_COMMITTED)
	public void create(DataAcquisitionRequest dataAcquisitionRequest) {
		logger.info("Enter DataAcquisitionBusinessServiceImpl login");
		this.daqDao.createDataAcquisitionRequest(dataAcquisitionRequest);
		logger.info("Exit DataAcquisitionBusinessServiceImpl login");
	}

	@Override
	@Transactional(readOnly = true)
	public List<DataAcquisitionRequest> trackRequest(String requestedUser, String requestType) {
		List<DataAcquisitionRequest> dataAcquisitionRequest = this.daqDao.getRequestedUserDetails(requestedUser,requestType);
		return dataAcquisitionRequest;
	}


	@Override
	@Transactional(readOnly = true)
	public List<DataAcquisitionRequest> getRequestDetails(Integer acquisitionReqId) {
		List<DataAcquisitionRequest> dataAcquisitionRequest = this.daqDao.getAcquisitionRequestDetails(acquisitionReqId);
		return dataAcquisitionRequest;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { 
            DaasSystemException.class }, isolation = Isolation.READ_COMMITTED)
	public void updateBulk(List<DataAcquisitionRequest> dataAcquisitionRequest) {
		this.daqDao.updateBulk(dataAcquisitionRequest);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { 
            DaasSystemException.class }, isolation = Isolation.READ_COMMITTED)
	public void update(DataAcquisitionRequest request) {
		this.daqDao.update(request);
		
	}
}
