package com.daas.core.dao.mapper.define;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;

public class SourceDetailsExtractor implements ResultSetExtractor<Map> {
	
	private Logger logger = LoggerFactory.getLogger(SourceDetailsExtractor.class);

	@Override
	public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
		 Map<String,String> mapRet= new HashMap<String,String>();	
		 int count =0;
		try {
			while (rs.next()) {
	            mapRet.put(rs.getString("source_label"),rs.getString("source_value"));
	            count++;
			}
			logger.info("count:::::::"+count);
			logger.info("mapRet Size:::::::"+mapRet.size());

		}catch (DataAccessException e) {
			logger.error(
					"Error in fetching Source Type Details , rolling back::::::: method fetchSourceInfo()");
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), e, null);
		}
		return mapRet;
	}
}
