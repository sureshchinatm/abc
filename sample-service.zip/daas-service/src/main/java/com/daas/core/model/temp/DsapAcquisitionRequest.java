package com.daas.core.model.temp;

import java.util.List;

public class DsapAcquisitionRequest {
	
	private Integer dsap_approval_id;
	private List<String> dsap_rule_policies;
	
	public Integer getDsap_approval_id() {
		return dsap_approval_id;
	}
	public void setDsap_approval_id(Integer dsap_approval_id) {
		this.dsap_approval_id = dsap_approval_id;
	}
	public List<String> getDsap_rule_policies() {
		return dsap_rule_policies;
	}
	public void setDsap_rule_policies(List<String> dsap_rule_policies) {
		this.dsap_rule_policies = dsap_rule_policies;
	}
	@Override
	public String toString() {
		return "DsapAcquisitionRequest [dsap_approval_id=" + dsap_approval_id + ", dsap_rule_policies="
				+ dsap_rule_policies + "]";
	}
	

	
}
