package com.daas.core.model.define;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DbSchemaInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8305332843700633606L;
	
	private Integer project_id;
	private Integer app_inst_id;
	
	private List<Sources> Sources;

	public Integer getProject_id() {
		return project_id;
	}

	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}

	public Integer getApp_inst_id() {
		return app_inst_id;
	}

	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}

	public List<Sources> getSources() {
		return Sources;
	}

	public void setSources(List<Sources> sources) {
		Sources = sources;
	}
}
