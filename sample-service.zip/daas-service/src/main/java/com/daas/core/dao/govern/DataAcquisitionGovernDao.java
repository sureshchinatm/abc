package com.daas.core.dao.govern;

import java.util.List;

import com.daas.core.model.govern.Govern;
import com.daas.core.model.govern.GovernSourceDetails;

/**
 * This interface contains the abstract methods to get the Data Acquisition Prepare Relationship
 * related information to the database and retrieve the information from the
 * database.
 * 
 * @author snatti
 */
public interface DataAcquisitionGovernDao {
	

    /**
     * Returns the Govern Source Details for approval
     * 
     * 
     * @param 
     *          
     * @return List of GovernSourceDetails.
     */
	public List<GovernSourceDetails>  fetchGovernSourceInformation();
	
	

    /**
     * Returns the Approved/Rejected Project status from the database.
     * 
     * 
     * @param governInfo
     *          
     * @return Status list of Projects.
     * 
     */
	public List<Govern> update(List<Govern> governInfo);
}
