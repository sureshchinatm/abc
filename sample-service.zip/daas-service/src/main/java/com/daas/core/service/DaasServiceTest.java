package com.daas.core.service;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.daas.core.model.temp.Account;
import com.daas.core.model.temp.Employee;
import com.daas.core.model.temp.JsonModel;
import com.daas.core.model.temp.PlayerListType;
import com.daas.core.model.temp.PlayerType;

public interface DaasServiceTest {
	

	// test service
	@GET
	@Path("/getmsg")
	@Produces(value = MediaType.TEXT_HTML)
	public String getMessage();

	@POST
    @Path("/accounts/{id}/")
    public Account getAccount( @PathParam("id") Integer accountId);

       
	@POST
	@Path("/accounts/getall")
    public List<Account> getAllAccounts();
		
	@POST
	@Path("/test/getdata")
    public String getJsondata(@RequestBody JsonModel jsonModel);
	
	@POST
    @Path("/player/addplayer")
    public String createOrSaveNewPLayerInfo(@RequestBody PlayerType playerType);
	
	@GET
	@Path("/player/getplayer/{id}")
	public PlayerType getPlayerInfo(@PathParam("id") Integer playerId);
	
	@POST
    @Path("/player/getallplayer")
    public PlayerListType getAllPlayerInfo();
	
	

	 /** 
	  * This is the method to be used to create
	  * a record in the Employee table.
	  */
	@POST
    @Path("/employee/create")
	public void create(@RequestBody Employee employee);
	
	/*@POST
    @Path("/employee/jsoncreate")
	public void jsonCreate(@RequestBody String employee);*/
	
	
	 /** 
	  * This is the method to be used to list down
	  * a record from the Employee table corresponding
	  * to a passed Employee id.
	  */

	@POST
    @Path("/employee/{id}")
    public Employee getEmployee(@PathParam("id") Integer employeeId);
	
	 /** 
	  * This is the method to be used to list down
	  * all the records from the Employee table.
	  */
	@POST
    @Path("/employee/getallemployee")
	 public List<Employee> listEmployees();
	 /** 
	  * This is the method to be used to delete
	  * a record from the Employee table corresponding
	  * to a passed Employee id.
	  */
	@POST
    @Path("/employee/delete/{id}")
	public void delete(@PathParam("id") Integer employeeId);
	 /** 
	  * This is the method to be used to update
	  * a record into the Employee table.
	  */
	@POST
    @Path("/employee/update")
	public void update(@RequestBody Employee employee);


}
