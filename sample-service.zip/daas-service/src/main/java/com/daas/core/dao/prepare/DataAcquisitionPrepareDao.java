package com.daas.core.dao.prepare;

import java.util.List;

import com.daas.core.model.prepare.ScanDetails;

/**
 * This interface contains the abstract methods to get the Data Acquisition Prepare Relationship
 * related information to the database and retrieve the information from the
 * database.
 * 
 * @author snatti
 */
public interface DataAcquisitionPrepareDao {
	

    /**
     * Returns the Scanning Status Information corresponding to the
     * guId.
     * 
     * @param guId
     *          
     * @return List of Scanning Status Information  corresponding to guId.
     */
	public List<ScanDetails>  fetchScanInformation(Integer guId);
	
	
}
