package com.daas.core.dao.prepare;

import static com.daas.core.dao.query.constants.DataAcquisitionQueryConstants.SCAN_DETAILS_SQL;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.daas.core.exception.config.DaasBusinessException;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.model.prepare.ScanDetails;
import com.daas.core.util.ErrorMessageConstants;


/**
 * This class provides the implementation methods for DataAcquisitionPrepareDao.
 * 
 * @author snatti
 */

@Repository
public class DataAcquisitionPrepareDaoImpl implements DataAcquisitionPrepareDao{
	
	private Logger logger = LoggerFactory.getLogger(DataAcquisitionPrepareDaoImpl.class);

		@Autowired
		JdbcTemplate jdbcTemplate;
		@Autowired
		NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	 /**
     * This method used to fetch scanning status information from scan_details table.
     */
	@Override
	public List<ScanDetails> fetchScanInformation(Integer guId) {
		logger.info("Enter DataAcquisitionPrepareDaoImpl fetchSystemInformation");
		List<ScanDetails> scanDetails = null;
		List<String> errorList;
		try {
			
			SqlParameterSource namedParameters =new MapSqlParameterSource("guid", guId);
			scanDetails = this.namedParameterJdbcTemplate.query(SCAN_DETAILS_SQL,namedParameters,
					new BeanPropertyRowMapper<ScanDetails>(ScanDetails.class));

			if (scanDetails == null || scanDetails.isEmpty()) {

				errorList = new ArrayList<>();
				errorList.add(ErrorMessageConstants.SCAN_DETAILS_NOT_FOUND_FOR_GUID);
				throw new DaasBusinessException(ErrorConstants.SYS_VALIDATION_ERROR.toString(), errorList,null,null);
			}
		} catch (DataAccessException e) {
			errorList = new ArrayList<>();
			errorList.add(ErrorMessageConstants.FETCH_FAILED_FOR_GUID);
			logger.error(
					"Error in fetching Scan Details , rolling back::::::: method fetchSystemInformation()  \n " + e);
			throw new DaasSystemException(ErrorConstants.SYS_DATAACCESS_ERROR.toString(), errorList,null, null);
		}

		logger.info("Exit DataAcquisitionPrepareDaoImpl fetchSystemInformation");
		return scanDetails;
	}
}
