package com.daas.core.model.identify;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DataAcquisition{

	private Integer app_inst_id;
	private String app_inst_name;
	private String app_inst_short_name;
	private String app_inst_description;
	private String application_type;
	private String app_inst_status;
	private String app_inst_strategic_status;
	private String app_inst_reviewer_email;
	private String app_inst_reviewer_name;
	private String app_inst_lvl_4_bus_org;
	private String app_inst_lvl_4_bus_org_owner;
	private String app_inst_lvl_5_bus_org;
	private String app_inst_lvl_4_it_dir;
	private String app_inst_lvl_4_it_dir_owner;
	private String app_inst_lvl_5_it_dir;
	private String app_inst_lvl_5_it_dir_owner;
	private String app_inst_dev_manager_primary;
	private String app_inst_dev_manager_secondary;
	private Integer application_id;
	private String application_name;
	private String app_it_owner = null;
	private String app_bus_owner = null;
	private String app_inst_pri_data_centre;
	private String app_inst_pri_data_centre_type;
	private String app_inst_sec_data_centre;
	private String app_inst_supporting_region;
	private String app_inst_supporting_country;
	private String app_inst_dev_region;
	private String app_inst_dev_country;
	private String rolename;
	
	
	public Integer getApp_inst_id() {
		return app_inst_id;
	}

	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}

	public String getApp_inst_name() {
		return app_inst_name;
	}

	public void setApp_inst_name(String app_inst_name) {
		this.app_inst_name = app_inst_name;
	}

	public String getApp_inst_short_name() {
		return app_inst_short_name;
	}

	public void setApp_inst_short_name(String app_inst_short_name) {
		this.app_inst_short_name = app_inst_short_name;
	}

	public String getApp_inst_description() {
		return app_inst_description;
	}

	public void setApp_inst_description(String app_inst_description) {
		this.app_inst_description = app_inst_description;
	}

	public String getApplication_type() {
		return application_type;
	}

	public void setApplication_type(String application_type) {
		this.application_type = application_type;
	}

	public String getApp_inst_status() {
		return app_inst_status;
	}

	public void setApp_inst_status(String app_inst_status) {
		this.app_inst_status = app_inst_status;
	}

	public String getApp_inst_strategic_status() {
		return app_inst_strategic_status;
	}

	public void setApp_inst_strategic_status(String app_inst_strategic_status) {
		this.app_inst_strategic_status = app_inst_strategic_status;
	}

	public String getApp_inst_reviewer_email() {
		return app_inst_reviewer_email;
	}

	public void setApp_inst_reviewer_email(String app_inst_reviewer_email) {
		this.app_inst_reviewer_email = app_inst_reviewer_email;
	}

	public String getApp_inst_reviewer_name() {
		return app_inst_reviewer_name;
	}

	public void setApp_inst_reviewer_name(String app_inst_reviewer_name) {
		this.app_inst_reviewer_name = app_inst_reviewer_name;
	}

	public String getApp_inst_lvl_4_bus_org() {
		return app_inst_lvl_4_bus_org;
	}

	public void setApp_inst_lvl_4_bus_org(String app_inst_lvl_4_bus_org) {
		this.app_inst_lvl_4_bus_org = app_inst_lvl_4_bus_org;
	}

	public String getApp_inst_lvl_4_bus_org_owner() {
		return app_inst_lvl_4_bus_org_owner;
	}

	public void setApp_inst_lvl_4_bus_org_owner(String app_inst_lvl_4_bus_org_owner) {
		this.app_inst_lvl_4_bus_org_owner = app_inst_lvl_4_bus_org_owner;
	}

	public String getApp_inst_lvl_5_bus_org() {
		return app_inst_lvl_5_bus_org;
	}

	public void setApp_inst_lvl_5_bus_org(String app_inst_lvl_5_bus_org) {
		this.app_inst_lvl_5_bus_org = app_inst_lvl_5_bus_org;
	}

	public String getApp_inst_lvl_4_it_dir() {
		return app_inst_lvl_4_it_dir;
	}

	public void setApp_inst_lvl_4_it_dir(String app_inst_lvl_4_it_dir) {
		this.app_inst_lvl_4_it_dir = app_inst_lvl_4_it_dir;
	}

	public String getApp_inst_lvl_4_it_dir_owner() {
		return app_inst_lvl_4_it_dir_owner;
	}

	public void setApp_inst_lvl_4_it_dir_owner(String app_inst_lvl_4_it_dir_owner) {
		this.app_inst_lvl_4_it_dir_owner = app_inst_lvl_4_it_dir_owner;
	}

	public String getApp_inst_lvl_5_it_dir() {
		return app_inst_lvl_5_it_dir;
	}

	public void setApp_inst_lvl_5_it_dir(String app_inst_lvl_5_it_dir) {
		this.app_inst_lvl_5_it_dir = app_inst_lvl_5_it_dir;
	}

	public String getApp_inst_lvl_5_it_dir_owner() {
		return app_inst_lvl_5_it_dir_owner;
	}

	public void setApp_inst_lvl_5_it_dir_owner(String app_inst_lvl_5_it_dir_owner) {
		this.app_inst_lvl_5_it_dir_owner = app_inst_lvl_5_it_dir_owner;
	}

	public String getApp_inst_dev_manager_primary() {
		return app_inst_dev_manager_primary;
	}

	public void setApp_inst_dev_manager_primary(String app_inst_dev_manager_primary) {
		this.app_inst_dev_manager_primary = app_inst_dev_manager_primary;
	}

	public String getApp_inst_dev_manager_secondary() {
		return app_inst_dev_manager_secondary;
	}

	public void setApp_inst_dev_manager_secondary(String app_inst_dev_manager_secondary) {
		this.app_inst_dev_manager_secondary = app_inst_dev_manager_secondary;
	}

	public Integer getApplication_id() {
		return application_id;
	}

	public void setApplication_id(Integer application_id) {
		this.application_id = application_id;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}

	public String getApp_it_owner() {
		return app_it_owner;
	}

	public void setApp_it_owner(String app_it_owner) {
		this.app_it_owner = app_it_owner;
	}

	public String getApp_bus_owner() {
		return app_bus_owner;
	}

	public void setApp_bus_owner(String app_bus_owner) {
		this.app_bus_owner = app_bus_owner;
	}

	public String getApp_inst_pri_data_centre() {
		return app_inst_pri_data_centre;
	}

	public void setApp_inst_pri_data_centre(String app_inst_pri_data_centre) {
		this.app_inst_pri_data_centre = app_inst_pri_data_centre;
	}

	public String getApp_inst_pri_data_centre_type() {
		return app_inst_pri_data_centre_type;
	}

	public void setApp_inst_pri_data_centre_type(String app_inst_pri_data_centre_type) {
		this.app_inst_pri_data_centre_type = app_inst_pri_data_centre_type;
	}

	public String getApp_inst_sec_data_centre() {
		return app_inst_sec_data_centre;
	}

	public void setApp_inst_sec_data_centre(String app_inst_sec_data_centre) {
		this.app_inst_sec_data_centre = app_inst_sec_data_centre;
	}

	public String getApp_inst_supporting_region() {
		return app_inst_supporting_region;
	}

	public void setApp_inst_supporting_region(String app_inst_supporting_region) {
		this.app_inst_supporting_region = app_inst_supporting_region;
	}

	public String getApp_inst_supporting_country() {
		return app_inst_supporting_country;
	}

	public void setApp_inst_supporting_country(String app_inst_supporting_country) {
		this.app_inst_supporting_country = app_inst_supporting_country;
	}

	public String getApp_inst_dev_region() {
		return app_inst_dev_region;
	}

	public void setApp_inst_dev_region(String app_inst_dev_region) {
		this.app_inst_dev_region = app_inst_dev_region;
	}

	public String getApp_inst_dev_country() {
		return app_inst_dev_country;
	}

	public void setApp_inst_dev_country(String app_inst_dev_country) {
		this.app_inst_dev_country = app_inst_dev_country;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	@Override
	public String toString() {
		return "DataAcquisition [app_inst_id=" + app_inst_id + ", app_inst_name=" + app_inst_name
				+ ", app_inst_short_name=" + app_inst_short_name + ", app_inst_description=" + app_inst_description
				+ ", application_type=" + application_type + ", app_inst_status=" + app_inst_status
				+ ", app_inst_strategic_status=" + app_inst_strategic_status + ", app_inst_reviewer_email="
				+ app_inst_reviewer_email + ", app_inst_reviewer_name=" + app_inst_reviewer_name
				+ ", app_inst_lvl_4_bus_org=" + app_inst_lvl_4_bus_org + ", app_inst_lvl_4_bus_org_owner="
				+ app_inst_lvl_4_bus_org_owner + ", app_inst_lvl_5_bus_org=" + app_inst_lvl_5_bus_org
				+ ", app_inst_lvl_4_it_dir=" + app_inst_lvl_4_it_dir + ", app_inst_lvl_4_it_dir_owner="
				+ app_inst_lvl_4_it_dir_owner + ", app_inst_lvl_5_it_dir=" + app_inst_lvl_5_it_dir
				+ ", app_inst_lvl_5_it_dir_owner=" + app_inst_lvl_5_it_dir_owner + ", app_inst_dev_manager_primary="
				+ app_inst_dev_manager_primary + ", app_inst_dev_manager_secondary=" + app_inst_dev_manager_secondary
				+ ", application_id=" + application_id + ", application_name=" + application_name + ", app_it_owner="
				+ app_it_owner + ", app_bus_owner=" + app_bus_owner + ", app_inst_pri_data_centre="
				+ app_inst_pri_data_centre + ", app_inst_pri_data_centre_type=" + app_inst_pri_data_centre_type
				+ ", app_inst_sec_data_centre=" + app_inst_sec_data_centre + ", app_inst_supporting_region="
				+ app_inst_supporting_region + ", app_inst_supporting_country=" + app_inst_supporting_country
				+ ", app_inst_dev_region=" + app_inst_dev_region + ", app_inst_dev_country=" + app_inst_dev_country
				+ ", rolename=" + rolename + "]";
	}
}
