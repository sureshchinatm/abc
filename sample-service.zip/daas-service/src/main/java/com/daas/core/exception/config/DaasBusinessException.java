package com.daas.core.exception.config;

import java.util.List;

import com.daas.core.exception.util.BusinessContext;

/**
 * Store BIZ_0001 to BIZ_1000 
 * 
 */
/**
 * @ Author snatti This class will be used to handle custom DaasBusiness
 * Exceptions.
 */
public class DaasBusinessException extends DaasBaseException {
    
    /**	 */
    private static final long serialVersionUID = 1L;
    
    /**
     * This is used to pass link BusinessContext and errors codes list.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param businessContext
     *            - context that contains parameters
     * @param errorCodeList
     *            - list of errors
     * @param loggedInUser
     *            -user loggedin
     * @param exception
     *            - original exception
     */
   /* public DaasBusinessException(String errorCode, BusinessContext businessContext,
                    List<String> errorCodeList,
                    String loggedInUser, Exception exception) {
        super(errorCode, businessContext, errorCodeList, loggedInUser, exception);
        
    }*/
    
    /**
     * This is used to pass error code list along with other required
     * parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param errorCodeList
     *            - list of errors
     * @param loggedInUser
     *            -user loggedin
     * @param exception
     *            - original exception
     */
    public DaasBusinessException(String errorCode, List<String> errorCodeList,
                    String loggedInUser,
                    Exception exception) {
        super(errorCode, errorCodeList, loggedInUser, exception);
        
    }
    
    /**
     * This is used to pass errorCode, loggedInUser and exception.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param loggedInUser
     *            -user loggedin
     * @param exception
     *            - original exception
     */
    public DaasBusinessException(String errorCode, String loggedInUser, Exception exception) {
        super(errorCode, loggedInUser, exception);
    	System.out.println("Inisde DaasBusinessException COnstructor::::::::"+loggedInUser);
    }
    
    /**
     * Constructs a new PharmacyBusinessException by specifying errorCode,
     * {@link BusinessContext} and exception with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param exception
     *            - original exception
     * @param businessContext
     *            - context that contains parameters
     */
    public DaasBusinessException(String errorCode, Exception exception, BusinessContext businessContext){
        super(errorCode, exception, businessContext);
    }
    
}
