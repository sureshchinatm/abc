package com.daas.core.exception.util;

/**
 * Used to store the Exception Error codes
 * @author snatti
 *
 */
public enum ErrorCodes {
	/*
	 * system exception constants
	 */
	SYS_0001,
	SYS_0002,
	SYS_0003,
	SYS_0004,
	SYS_0005,
	SYS_0006,
	SYS_0007,
	SYS_0008,
	SYS_0009,
	SYS_0010,
	SYS_0011,
	SYS_0012,
	SYS_0013,
	SYS_0014,
	SYS_0015,
	SYS_0016,
	SYS_0017,
	SYS_0018,
	SYS_0019,
	SYS_0020,
	SYS_0021,
	SYS_0022,



	/**
	 * Transaction Manager
	 */
	SYS_0025,
	SYS_0026,
	SYS_0027,
	SYS_0028,
	SYS_0029,
	SYS_0030,

	/*
	 *External Exception Constants.
	 */
	EXT_0001,
	EXT_0002,

	/*
	 * Business Exception Constants.
	 */
	BIZ_0001,
	BIZ_0002,
	BIZ_0003,
	BIZ_0004,
	BIZ_0005,
	BIZ_0006,
	BIZ_0007,
	BIZ_0008,
	BIZ_0009,

	ErrorCodes(){

	}
}
