package com.daas.core.model.prepare;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ScanDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8744934174567396403L;

	private Integer guid;
	private String system_name;
	private Integer app_inst_id;
	private String application_name;
	private String scan_status;

	public Integer getGuid() {
		return guid;
	}

	public void setGuid(Integer guid) {
		this.guid = guid;
	}

	public String getSystem_name() {
		return system_name;
	}

	public void setSystem_name(String system_name) {
		this.system_name = system_name;
	}

	public Integer getApp_inst_id() {
		return app_inst_id;
	}

	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}

	public String getScan_status() {
		return scan_status;
	}

	public void setScan_status(String scan_status) {
		this.scan_status = scan_status;
	}

}
