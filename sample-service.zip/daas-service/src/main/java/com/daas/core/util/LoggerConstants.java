package com.daas.core.util;



/**
 * The LoggerConstants consists of all the constants that will be used in all
 * the logger statements across the Application
 * 
 * @author snatti
 *         
 */
public final class LoggerConstants {
    
    // Error Messages
    public static final String COMMON_LOG_MSG_0001 = "method execution started";
    public static final String COMMON_LOG_MSG_0002 = "method execution Completed";
    public static final String COMMON_LOG_ERROR_MSG = "Exception occurred";
        
    /**
     * The below private constructor will avoid creating objects for this class
     * as all the members are static.
     */
    private LoggerConstants() {
        // Empty private constructor used to avoid unnecessary creation of
        // objects
    }
    
}
