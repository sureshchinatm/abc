package com.daas.core.exception.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.daas.core.exception.dto.ErrorDTO;
import com.daas.core.exception.util.BusinessContext;
import com.daas.core.exception.util.ExceptionUtils;

/**
 * This class is base exception for all custom exceptions.
 * 
 * @author snatti
 */
public class DaasBaseException extends RuntimeException {
    
  

	private static final long serialVersionUID = 1L;
    
    private final ErrorDTO errorDTO;
    private final Exception exception;
    
   
    /**
     * Constructs a new DaasBaseException by specifying errorCode,
     * {@link BusinessContext}, errorCodeList,loggedInUser and originalException
     * and constructs errorDTO with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param businessContext
     *            - context that contains parameters
     * @param errorCodeList
     *            - list of errors
     * @param loggedInUser
     *            -user loggedin
     * @param originalException
     *            - original exception
     */
   /* public DaasBaseException(String errorCode, BusinessContext businessContext,
            List<String> errorCodeList,
            String loggedInUser, Exception originalException) {
			this.exception = originalException;
			// create Error DTO
			this.errorDTO = new ErrorDTO(errorCode, businessContext, errorCodeList,
			                ExceptionUtils.getCurrentTimeStamp(),
			                loggedInUser);
			                
    }*/
    
    /**
     * Constructs a new DaasBaseException by specifying errorCode,
     * loggedInUser and originalException and constructs
     * errorDTO with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param errorCodeList
     *            - list of errors
     * @param loggedInUser
     *            -user loggedin
     * @param originalException
     *            - original exception
     */
    public DaasBaseException(String errorCode, List<String> errorCodeList, String loggedInUser,
                    Exception originalException) {
        this.exception = originalException;
        // create Error DTO
        this.errorDTO = new ErrorDTO(errorCode, errorCodeList, ExceptionUtils.getCurrentTimeStamp(),
                        loggedInUser);
    }
    
    /**
     * Constructs a new DaasBaseException by specifying
     * errorCode,loggedInUser and originalException and constructs errorDTO with
     * given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param loggedInUser
     *            -user loggedin
     * @param originalException
     *            - original exception
     */
    
    public DaasBaseException(String errorCode, String loggedInUser,
                    Exception originalException) {
    	System.out.println("APPLE::::::::"+errorCode+","+loggedInUser+","+originalException.getMessage());
        this.exception = originalException;
        // create Error DTO
        
        this.errorDTO = new ErrorDTO(errorCode, new ArrayList<>(), ExceptionUtils.getCurrentTimeStamp(),
                        loggedInUser);
    }
    
    /**
     * Constructs a new DaasBaseException by specifying errorCode,
     * and originalException and constructs errorDTO
     * with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param originalException
     *            - original exception           
     * @param businessContext
     *            - context that contains parameters
     */
/*//    public DaasBaseException(String errorCode, Exception originalException) {
//        this.exception = originalException;
//        // create Error DTO
//        this.errorDTO = new ErrorDTO(errorCode,  ExceptionUtils.getCurrentTimeStamp());
//    }
*/    
    public DaasBaseException(String errorCode, Exception originalException, BusinessContext businessContext) {
        this.exception = originalException;
        // create Error DTO
        this.errorDTO = new ErrorDTO(errorCode, businessContext, ExceptionUtils.getCurrentTimeStamp());
    }
    public ErrorDTO getErrorDTO() {
        return this.errorDTO;
    }
    
    public Exception getException() {
        return this.exception;
    }
    
}
