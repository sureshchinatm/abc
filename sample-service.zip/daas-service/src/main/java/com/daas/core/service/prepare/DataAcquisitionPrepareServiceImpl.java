package com.daas.core.service.prepare;

import java.util.List;

import javax.ws.rs.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.daas.core.businesss.prepare.DataAcquisitionPrepareBusinessService;
import com.daas.core.model.prepare.ScanDetails;

/**
 * This class provides the implementation for DataAcquisitionPrepareService methods to invoke
 * the corresponding business methods of DataAcquisitionPrepareBusinessService interface.
 * 
 * @author snatti
 */

@Path("/prepare/")
@Service
public class DataAcquisitionPrepareServiceImpl implements DataAcquisitionPrepareService{
	
	/**
     * Logger object to log the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionPrepareServiceImpl.class);
	

    /**
     * Autowired businessService implementation class to perform business
     * validations and to access DAO layer.
     */
	@Autowired
	DataAcquisitionPrepareBusinessService dataAcquisitionPrepareBusinessService;
	
	/**
	 *  Method to be fetch submitted Scanning Status Details
	 * @param guId
	 * 
	 * @return List<ScanDetails> with all the Scanning Status information.
	 */
	@Override
	public List<ScanDetails> getScanInformation(Integer guId) {
		logger.info("Enter DataAcquisitionPrepareServiceImpl getScanInformation");
		List<ScanDetails> scanDetails = this.dataAcquisitionPrepareBusinessService.getScanInformation(guId);
		logger.info("Exit DataAcquisitionPrepareServiceImpl getScanInformation");

		return scanDetails;
	}
}
