package com.daas.core.businesss.govern;

import java.util.List;

import com.daas.core.model.govern.Govern;
import com.daas.core.model.govern.GovernSourceDetails;

/**
 * This interface contains the abstract methods to perform the business rule
 * validations and operations on the data acquisition govern flow and the methods to invoke
 * the data access layer methods to perform the CRUD operations on the database.
 *
 * @author snatti
 */
public interface DataAcquisitionGovernBusinessService {
	
	 /**
     *  Returns Govern Source Details for approval from the database.
     * 
     * @param 
     *          
     * @return  List of  GovernSourceDetails 
     *        		
     */
	public List<GovernSourceDetails> getGovernSourceInformation();


	 /**
    *  Returns Approved/Rejected Project status from the database.
    * 
    * @param governInfo
    *          
    * @return List of Govern status with all the status information for the selected projects.
    *        		
    */
	public List<Govern> updateGovernStatus(List<Govern> governInfo);
}
