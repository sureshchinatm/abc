package com.daas.core.businesss.govern;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.daas.core.dao.govern.DataAcquisitionGovernDao;
import com.daas.core.exception.config.DaasSystemException;
import com.daas.core.model.govern.Govern;
import com.daas.core.model.govern.GovernSourceDetails;

/**
 * This class provides implementation for DataAcquisitionGovernBusinessService methods to perform
 * the business rule validations and operations on the user information and the
 * methods to invoke the data access layer methods to perform the CRUD
 * operations on the database.
 *
 * @author snatti
 */

@Service
public class DataAcquisitionGovernBusinessServiceImpl implements DataAcquisitionGovernBusinessService{

	 
    /**
     * Logger object to log all the activities performed in this class.
     */
	private Logger logger=LoggerFactory.getLogger(DataAcquisitionGovernBusinessServiceImpl.class);
    
    /**
     * Autowired DataAcquisitionGovernDao to perform CRUD operations.
     */
    @Autowired
    private DataAcquisitionGovernDao dataAcquisitionGovernDao;
	
    /**
     * Returns Govern Source Details for approval from the database
     * 
     * @param 
     *           
     * @return List of  Govern Source Details.
     */
	@Override
	@Transactional(readOnly = true)
	public List<GovernSourceDetails> getGovernSourceInformation() {
		logger.info("Enter DataAcquisitionGovernBusinessServiceImpl getGovernSourceInformation");
		List<GovernSourceDetails> governSourceInfo = this.dataAcquisitionGovernDao.fetchGovernSourceInformation();
		logger.info("Exit DataAcquisitionGovernBusinessServiceImpl getGovernSourceInformation");
		return governSourceInfo;
	}

	

	 /**
    *  Returns Govern Source Details for approval from the database.
    * 
    * @param governInfo
    *          
    * @return  Status list of Projects 
    *        		
    */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { 
            DaasSystemException.class }, isolation = Isolation.READ_COMMITTED)
	public List<Govern> updateGovernStatus(List<Govern> governInfo){

		logger.info("Enter DataAcquisitionGovernBusinessServiceImpl updateGovernStatus");
		List<Govern> govern = this.dataAcquisitionGovernDao.update(governInfo);
		logger.info("Exit DataAcquisitionGovernBusinessServiceImpl updateGovernStatus");

		return govern;
		
	}
}
