package com.daas.core.exception.config;

import java.util.List;

import com.daas.core.exception.util.BusinessContext;

/**
 * This will be to defined customized daas system exception. Any dao layer
 * exception need to be wrapped as system exception with appropriate error
 * information.
 * 
 * @author snatti
 */

public class DaasSystemException extends DaasBaseException {
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Constructs a new DaasSystemException by specifying errorCode,
     * {@link BusinessContext}, errorCodeList,loggedInUser and originalException
     * and constructs errorDTO with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param businessContext
     *            - context that contains parameters
     * @param errorCodeList
     *            - list of errors
     * @param loggedInUser
     *            -user loggedin
     * @param exception
     *            - original exception
     */
  /*  public DaasSystemException(String errorCode, BusinessContext businessContext,
                    List<String> errorCodeList,
                    String loggedInUser, Exception exception) {
        super(errorCode, businessContext, errorCodeList, loggedInUser, exception);
        
    }*/
    
    /**
     * Constructs a new DaasSystemException by specifying errorCode,
     * errorCodeList,loggedInUser and originalException and constructs errorDTO
     * with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param errorCodeList
     *            - list of errors
     * @param loggedInUser
     *            -user loggedin
     * @param exception
     *            - original exception
     */
    public DaasSystemException(String errorCode, List<String> errorCodeList,
                    String loggedInUser,
                    Exception exception) {
        super(errorCode, errorCodeList, loggedInUser, exception);
        
    }
    
    /**
     * Constructs a new DaasSystemException by specifying
     * errorCode,loggedInUser and originalException and constructs errorDTO with
     * given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception
     * @param loggedInUser
     *            -user loggedin
     * @param exception
     *            - original exception
     */
    public DaasSystemException(String errorCode, String loggedInUser, Exception exception) {
        super(errorCode, loggedInUser, exception);
        
    }
    
    /**
     * Constructs a new DaasSystemException by specifying errorCode,
     * {@link BusinessContext} and exception with given parameters.
     * 
     * @param errorCode
     *            -error code corresponding to a particular exception.
     * @param exception
     *            - original exception.
     * @param businessContext
     *            - context that contains parameters.
     */
    public DaasSystemException(String errorCode, Exception exception, BusinessContext businessContext){
        super(errorCode, exception, businessContext);
    }
    
}
