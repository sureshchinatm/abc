package com.daas.core.exception.util;

import java.util.HashSet;
import java.util.Set;

/**
 * Used to store the Exception Error codes
 * 
 * @author snatti
 *         
 */
public enum ErrorConstants {
    
    SYS_RUNTIME_ERROR(ErrorCodes.SYS_0001), SYS_JSON_MAPPING_ERROR(
                    ErrorCodes.SYS_0002), SYS_DATAACCESS_ERROR(
                                    ErrorCodes.SYS_0003), SYS_SQLEXCEPTION_ERROR(
                                                    ErrorCodes.SYS_0004), SYS_NUMFORMAT_ERROR(
                                                                    ErrorCodes.SYS_0005), SYS_VALIDATION_ERROR(
                                                                                    ErrorCodes.SYS_0006), SYS_CONSTRAINT_VIOLATION_ERROR(
                                                                                                    ErrorCodes.SYS_0007), SYS_WEBAPP_ERROR(
                                                                                                                    ErrorCodes.SYS_0008), SYS_FILE_ACCESS_ERROR(
                                                                                                                                    ErrorCodes.SYS_0009), SYS_JWT_TOKEN_SERVICES_ERROR(
                                                                                                                                                    ErrorCodes.SYS_0010), SYS_GET_KEY_FROM_KEYSTORE_ERROR(
                                                                                                                                                                    ErrorCodes.SYS_0011), SYS_EXTERNAL_CONN_ERROR(
                                                                                                                                                                                    ErrorCodes.SYS_0012), SYS_ILLEGAL_ACCESS_ERROR(
                                                                                                                                                                                                    ErrorCodes.SYS_0013), SYS_INVOCATION_TARGET_ERROR(
                                                                                                                                                                                                                    ErrorCodes.SYS_0014), SYS_NOSUCH_METHOD_ERROR(
                                                                                                                                                                                                                                    ErrorCodes.SYS_0015), SYS_NO_DATA_FOUND(
                                                                                                                                                                                                                                                    ErrorCodes.SYS_0016), SYS_TRANSC_REQD_ERROR(
                                                                                                                                                                                                                                                                    ErrorCodes.SYS_0017), SYS_ILLGAL_ARG_ERROR(
                                                                                                                                                                                                                                                                                    ErrorCodes.SYS_0018), SYS_QUERY_TIMEOUT_ERROR(
                                                                                                                                                                                                                                                                                                    ErrorCodes.SYS_0019), SYS_ILLGAL_STATE_ERROR(
                                                                                                                                                                                                                                                                                                                    ErrorCodes.SYS_0020), SYS_PERSISTENCE_ERROR(
                                                                                                                                                                                                                                                                                                                                    ErrorCodes.SYS_0021), SYS_ENTITY_EXISTS_ERROR(
                                                                                                                                                                                                                                                                                                                                                    ErrorCodes.SYS_0022),
                                                                                                                                                                                                                                                                                                                                                    
   
    
    /**
     * Transaction Manager
     */
    SYS_SYSTEM_EXCEPTION_ERROR(ErrorCodes.SYS_0025), SYS_PROP_VETO_ERROR(
                    ErrorCodes.SYS_0026), SYS_NAMING_EXCEPTION_ERROR(
                                    ErrorCodes.SYS_0027), SYS_ES_SERVLET_ERROR(
                                                    ErrorCodes.SYS_0028), SYS_ES_TRANSPORT_CLIENT_ERROR(
                                                                    ErrorCodes.SYS_0029), SYS_ES_SAVE_ERROR(
                                                                                    ErrorCodes.SYS_0030),
                                                                                    
    /**
     * External Exception Constants.
     */
    EXT_CONNTIMEOUT_ERROR(ErrorCodes.EXT_0001), EXT_UNKNOWNHOST_ERROR(ErrorCodes.EXT_0002),
    
    /**
     * Business Exception Constants.
     */
    BIZ_NOPRODUCTLICENSEINFO_ERROR(ErrorCodes.BIZ_0001), BIZ_NOMODULELICENSEINFO(
                    ErrorCodes.BIZ_0002), BIZ_LEVEL_NOTDEFINED_ERROR(
                                    ErrorCodes.BIZ_0003), BIZ_INVALID_QUERRY_ERROR(
                                                    ErrorCodes.BIZ_0004), BIZ_FILE_ACCESS_ERROR(
                                                                    ErrorCodes.BIZ_0005), BIZ_INVALID_CONFIG_CATEGORY_ERROR(
                                                                                    ErrorCodes.BIZ_0006), BIZ_INVALID_ATTRIBUTE_NAME_ERROR(
                                                                                                    ErrorCodes.BIZ_0007);


    
    private ErrorCodes pair;
    
    static {
        Set<ErrorCodes> usedEnums = new HashSet<>();
        for (ErrorConstants moe : ErrorConstants.values()) {
            if (!usedEnums.add(moe.pair)) {
                throw new IllegalArgumentException(moe.pair + " is already used!");
            }
        }
    }
    
    private ErrorConstants(ErrorCodes pair) {
        this.pair = pair;
    }
    
    public ErrorCodes getCode() {
        return this.pair;
    }
}
