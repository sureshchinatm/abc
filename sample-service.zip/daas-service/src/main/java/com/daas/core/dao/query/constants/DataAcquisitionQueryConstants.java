package com.daas.core.dao.query.constants;

/**
 * The DataAcquisitionQueryConstants consists of all the sql query constants that will be used in all
 * the Persistence Layer of the Data Acquisition Application Flow
 * 
 * @author snatti
 *         
 */
public final class DataAcquisitionQueryConstants{
	
	
		
	//***  Queries related to fetch on Identify screen ***//
	public static final String DATA_GROUP_SQL = "select distinct data_group from data_acquisition_master_test order by data_group ASC";
	public static final String APPLICATION_NAME_SQL ="select distinct application_name from data_acquisition_master_test order by application_name ASC";
	public static final String LOB_SQL ="select distinct app_inst_lvl_4_bus_org from data_acquisition_master_test order by app_inst_lvl_4_bus_org ASC";
	public static final String REGION_SQL ="select distinct app_inst_dev_country from data_acquisition_master_test order by app_inst_dev_country ASC";

	//***  Queries related to search on Identify screen ***//
	
	
	//***  Queries related to Submit/Save on Identify screen ***//
	
	/*public static final String  BATCH_INSERT = "INSERT INTO data_acquisition_request (data_acquisition_batch_request_id,status, app_inst_id, application_name,data_group,app_inst_name,"
			+ "app_inst_reviewer_name, app_inst_lvl_4_bus_org,app_inst_lvl_4_bus_org_owner, app_inst_dev_country)"
			+ " VALUES ("+batchId+",:status,:app_inst_id,:application_name,:data_group,:app_inst_name,"
			+":app_inst_reviewer_name,:app_inst_lvl_4_bus_org,:app_inst_lvl_4_bus_org_owner,:app_inst_dev_country)";
	*/
	
	//*** Query to generate batchId for Submit on Identify screen and map it to data_acquisition_request table for the submitted requests ***//
	public static final String GENERATE_BATCH_ID = "INSERT INTO batch(batch_created_dt) VALUES (?)";
	
	//*** Query to generate dataclinicapprovalId when creating project ***//
	public static final String GENERATE_DATA_CLINIC_APPROVAL_ID = "INSERT INTO data_clinic_approval_batch(batch_created_dt) VALUES (?)";

	
	//***  Queries related to fetch of System Details on Plan screen ***//
	public static final String SYSTEM_DETAILS_SQL ="select app_inst_id,app_inst_name,application_name "
			+ "from data_acquisition_request where data_acquisition_batch_request_id =:dataAcquisitionBatchRequestId";
	
	//*** Queries to Submit/Save Project and System Information on Plan screen ***//
	
//	public static final String PROJECT_MASTER_SAVE_SQL = "INSERT INTO project_master(project_name,description,purpose,clarity_code,key_contacts,estimated_hours,username) VALUES (?,?,?,?,?,?,?)";

	public static final String PROJECT_MASTER_SAVE_SQL = "INSERT INTO project_master(project_name,description,purpose,clarity_code,key_contacts,estimated_hours,stage,user_id)"
			+ " VALUES (?,?,?,?,?,?,?,?)";
	public static final String PROJECT_SYSTEM_SAVE_SQL = "INSERT INTO project_system_details (app_inst_id,project_id,"
			+ "justify,data_retention,frequency,application_name,ingestion_type)"
			+ " VALUES (?,?,?,?,?,?,?)";
			
	
	//*** Queries to fetch Project and System Information ***//
	
	public static final String PROJECT_MASTER_FETCH_SQL ="select * from project_master where project_id=:project_id";
	
	public static final String USER_PROJECT_MASTER_FETCH_SQL ="select * from project_master where user_id=:user_id";

	public static final String PROJECT_SYSTEMS_FETCH_SQL ="select b.app_inst_id,b.system_name from project_system_details a,"
			+ " system_master b where a.project_id =:project_id and b.app_inst_id"
			+ " in (select a.app_inst_id from project_system_details where project_id =:project_id)";
	
	//*** Query to UPDATE Project Stage ***//
	public static final String PROJECT_STAGE_UPDATE_SQL = "UPDATE project_master SET stage=:stage  where project_id=:project_id";
	
	//*** Query to Fetch user specific Projects ***//
	public static final String GET_PROJECT_ID_FOR_USER= "select * from project_master where user_id=?"; 
	
	//*** Query to UPDATE Project Master ***//
	public static final String UPDATE_PROJECT_MASTER_SQL="update project_master SET project_name=:project_name,"
			+ " description=:description, purpose=:purpose,clarity_code=:clarity_code,key_contacts=:key_contacts,"
			+ " estimated_hours=:estimated_hours,user_id=:user_id,stage=:stage,stamp_created=:stamp_created"
			+ " where project_id=:project_id";
	
	//*** Query to UPDATE Project System Details ***//
	public static final String UPDATE_PROJECT_SYSTEM_DETAILS_SQL= "update project_system_details SET  app_inst_id=:app_inst_id, justify=:justify, "
			+ " data_retention=:data_retention, frequency=:frequency,application_name=:application_name,ingestion_type=:ingestion_type"
			+ " where project_system_id =:project_system_id";
	
	//*** Query to fetch Source Information ***//	
	
	public static final String SOURCE_NAME_SQL = "select distinct b.source_name , b.source_id from source_schema_details a,source_type b "
			+ "where a.parent_source_id=b.source_id and a.app_inst_id =:app_inst_id";
	
	//*** Query to fetch Schema and Attribute Information ***//	
	
	public static final String SCHEMA_ATTRIBUTE_SQL = "SELECT source_schema_name,source_attribute_name_value FROM source_schema_details "
			+ "where app_inst_id =:app_inst_id and parent_source_id =:parent_source_id";
	
	//*** Query to fetch Scan Status Details ***//
	public static final String SCAN_DETAILS_SQL="select * from scan_details where guid=:guid";
	
	//*** Query to insert data into Govern Table at the time of creating project ***/
	public static final String GOVERN_INSERT_SQL="INSERT INTO govern (project_id,app_inst_id,data_clinic_approval_id,status,approver_type,stamp_created,stamp_updated)"
			+ " VALUES (:project_id,:app_inst_id,:data_clinic_approval_id,:status,:approver_type,:stamp_created,:stamp_updated)";
	
	//*** Query to fetch user role ***//
	public static final String GET_USER_ROLE = "select r.role from roles r , users u , user_role ur where r.id = ur.role_id  and ur.user_id = u.id and u.id =?";
	
	//*** Query to fetch Govern Source Details ***//
	public static final String GET_GOVERN_SOURCE_DETAILS_SQL= " select distinct b.project_id, a.app_inst_name , a.data_group ,a.app_inst_id,a.application_name,"
			+ " a.app_inst_lvl_4_bus_org_owner,a.app_inst_lvl_4_bus_org,a.app_inst_dev_country,d.status,d.data_clinic_approval_id"
			+ " from data_acquisition_master_test a,project_master b, project_system_details c ,"
			+ " (SELECT PROJECT_ID,CASE WHEN COUNT(DISTINCT STATUS)> 1 THEN 'PENDING' ELSE 'APPROVED' END AS STATUS,data_clinic_approval_id"
			+ " FROM GOVERN GROUP BY PROJECT_ID) D"
			+ " where c.project_id = b.project_id and c.app_inst_id = a.app_inst_id "
			+ " AND d.project_id=b.project_id";
	
	//*** Query to fetch Approved/Rejected status for govern ***//
	//public static final String GET_GOVERN_STATUS_SQL =" select count(*) from govern where project_id=? and status='Approved'";
	public static final String GET_GOVERN_STATUS_SQL =" select count(*) from govern where project_id=? and app_inst_id=? and status='Approved'";

	
   /* select distinct b.project_id, a.app_inst_name , a.data_group ,a.app_inst_id,a.application_name,
			a.app_inst_lvl_4_bus_org_owner,a.app_inst_lvl_4_bus_org,a.app_inst_dev_country,d.status,d.data_clinic_approval_id     
			from data_acquisition_master_test a,project_master b, project_system_details c ,
    (SELECT PROJECT_ID,CASE WHEN COUNT(DISTINCT STATUS)> 1 THEN 'PENDING' ELSE 'APPROVED' END AS STATUS,data_clinic_approval_id
    FROM GOVERN GROUP BY PROJECT_ID) D      
			where c.project_id = b.project_id and c.app_inst_id = a.app_inst_id 
    AND d.project_id=b.project_id
    */
	
	 /**
     * The below private constructor will avoid creating objects for this class
     * as all the members are static.
     */
	private DataAcquisitionQueryConstants(){
		// Empty private constructor used to avoid unnecessary creation of
        // objects
	}
}
