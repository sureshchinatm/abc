package com.daas.core.model.identify;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DataAcquisitionRequest implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 2234042165007736506L;
	
	private String status;
	private String data_group;
	private Integer app_inst_id;
	private String app_inst_name;
	private String app_inst_reviewer_name;
	private String app_inst_lvl_4_bus_org;
	private String app_inst_lvl_4_bus_org_owner;
	private String application_name;
	private String app_inst_dev_country;
	private String stamp_created;
	private String stamp_updated;
	
	private Integer data_acquisition_batch_request_id;
	
	
	
	public Integer getData_acquisition_batch_request_id() {
		return data_acquisition_batch_request_id;
	}
	public void setData_acquisition_batch_request_id(Integer data_acquisition_batch_request_id) {
		this.data_acquisition_batch_request_id = data_acquisition_batch_request_id;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getData_group() {
		return data_group;
	}
	public void setData_group(String data_group) {
		this.data_group = data_group;
	}
	public Integer getApp_inst_id() {
		return app_inst_id;
	}
	public void setApp_inst_id(Integer app_inst_id) {
		this.app_inst_id = app_inst_id;
	}
	public String getApp_inst_name() {
		return app_inst_name;
	}
	public void setApp_inst_name(String app_inst_name) {
		this.app_inst_name = app_inst_name;
	}
	public String getApp_inst_reviewer_name() {
		return app_inst_reviewer_name;
	}
	public void setApp_inst_reviewer_name(String app_inst_reviewer_name) {
		this.app_inst_reviewer_name = app_inst_reviewer_name;
	}
	public String getApp_inst_lvl_4_bus_org() {
		return app_inst_lvl_4_bus_org;
	}
	public void setApp_inst_lvl_4_bus_org(String app_inst_lvl_4_bus_org) {
		this.app_inst_lvl_4_bus_org = app_inst_lvl_4_bus_org;
	}
	public String getApp_inst_lvl_4_bus_org_owner() {
		return app_inst_lvl_4_bus_org_owner;
	}
	public void setApp_inst_lvl_4_bus_org_owner(String app_inst_lvl_4_bus_org_owner) {
		this.app_inst_lvl_4_bus_org_owner = app_inst_lvl_4_bus_org_owner;
	}
	public String getApplication_name() {
		return application_name;
	}
	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	public String getApp_inst_dev_country() {
		return app_inst_dev_country;
	}
	public void setApp_inst_dev_country(String app_inst_dev_country) {
		this.app_inst_dev_country = app_inst_dev_country;
	}
	public String getStamp_created() {
		return stamp_created;
	}
	public void setStamp_created(String stamp_created) {
		this.stamp_created = stamp_created;
	}
	public String getStamp_updated() {
		return stamp_updated;
	}
	public void setStamp_updated(String stamp_updated) {
		this.stamp_updated = stamp_updated;
	}
	
}
