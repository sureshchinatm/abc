package com.daas.core.exception;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.daas.core.exception.dto.ErrorDTO;
import com.daas.core.exception.util.ErrorConstants;
import com.daas.core.util.LoggerConstants;
import com.fasterxml.jackson.databind.JsonMappingException;


/**
 * This is used to catch json mapping exceptions raised at runtime and log the
 * Error messages using the Error DTO object
 * 
 * @author snatti
 */
@Provider
public class JsonMappingExceptionMapper implements ExceptionMapper<JsonMappingException> {
    
	private Logger logger=LoggerFactory.getLogger(JsonMappingExceptionMapper.class);
                    
    /**
     * This method is used to handle JsonMappingException and it forms an Error
     * DTO depending on the Exception message passed.
     * 
     * @return {@code Response} Returns the Response which the Exception Error
     *         Message DTO
     */
    @Override
    public Response toResponse(JsonMappingException jsonmape) {
    	logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, jsonmape);
        ErrorDTO errorMessage = new ErrorDTO(
                        ErrorConstants.SYS_JSON_MAPPING_ERROR.getCode().toString());
        errorMessage.getErrorCodeList().add(jsonmape.getMessage());
        Throwable exceptionCauseMessage = jsonmape.getCause();
        if (exceptionCauseMessage != null && exceptionCauseMessage.getMessage() != null) {
            errorMessage.getErrorCodeList().add(exceptionCauseMessage.getMessage());
        }
        logger.error(LoggerConstants.COMMON_LOG_ERROR_MSG, errorMessage.getErrorCode());
        return Response.status(Response.Status.BAD_REQUEST).entity(errorMessage).type(MediaType.APPLICATION_JSON).build();
    }
}
