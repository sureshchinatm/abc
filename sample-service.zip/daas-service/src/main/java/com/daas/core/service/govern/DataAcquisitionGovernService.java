package com.daas.core.service.govern;



import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.daas.core.model.govern.Govern;
import com.daas.core.model.govern.GovernSourceDetails;

/**
 * This interface is the service class for  Govern module which
 * consumes the JSON data from the rest call and returns the response in the
 * form of JSON.
 * 
 * @author snatti
 */

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface DataAcquisitionGovernService {

	/**
	 * Entry point method to fetch Govern Source Details for Approval Status
	 * 
	 * @param - to be added later after checking with business for now we are fetching all information
	 * 
	 * @return List<GovernSourceDetails> with all the Source Approval Details Information.
	 */
	@GET
	@Path("/getGovernSourceInfo/")
	public List<GovernSourceDetails> getGovernSourceInformation();

	
	/**
	 * Entry point method to Approve/Reject Source Details
	 * 
	 * @param governStatusInfo
	 * 
	 * @return List of Govern status with all the status information for the selected projects.
	 */
	@POST
	@Path("/updateStatus/")
	public List<Govern> updateGovernStatus(List<Govern> governStatusInfo);
}
